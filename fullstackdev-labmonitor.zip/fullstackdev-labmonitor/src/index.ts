import { openapi } from '@elysiajs/openapi';
import { staticPlugin } from '@elysiajs/static';
import { Elysia } from "elysia";
import { readFileSync } from "fs";
import { join } from "path";
import api from "./api";
import { SERVER_HOST, SERVER_PORT } from "./server_config";

const indexHtml = readFileSync(join(import.meta.dir, "public/index.html"), "utf-8");



const app = new Elysia({
})
  .use(openapi({
    exclude: {
      staticFile: true,
      paths: ["/*", "/*/*"]
    }
  }))
  .use(api)
  .use(staticPlugin({
    prefix: "/labmonitor",
    assets: join(import.meta.dir, "../modules/labmonitor/ui/public"),
  }))
  .use(staticPlugin({
    prefix: "/*",
    assets: join(import.meta.dir, "public"),
  }))
  .listen({
    port: SERVER_PORT,
    hostname: SERVER_HOST,
  });

console.log(
  `🦊 Elysia is running at http://${app.server?.hostname}:${app.server?.port}`
);