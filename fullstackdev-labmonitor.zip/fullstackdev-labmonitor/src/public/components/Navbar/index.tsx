import { Button, Navbar, NavbarBrand, NavbarContent } from "@heroui/react";
import { HealthStatus } from "../HealthStatus";
import UserDropdown from "../UserDropdown";
import { FiGrid, FiMenu } from "react-icons/fi";
import { useSidebar } from "../../providers/SidebarProvider";
import { useNavigate } from "react-router";
import { useAppModuleStore } from "../../stores/useAppModuleStore";

export function NavbarComponent() {
    const { isOpen, toggle } = useSidebar();
    const navigate = useNavigate();
    const { moduleMenus, setModuleKey } = useAppModuleStore();

    return (
        <Navbar isBordered maxWidth="full" className="bg-white border-b border-gray-200">
            <NavbarContent justify="start">
                <NavbarBrand className="gap-4">
                    <div
                        className="flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-opacity"
                    >

                        <Button isIconOnly onPress={toggle} className="p-2 rounded-xl bg-primary-600 text-white shadow-sm shadow-primary-200">
                            <FiMenu size={20} />
                        </Button>


                        <h1 className="text-xl font-black text-slate-800 tracking-tighter">ZZBY</h1>
                    </div>

                    <div className="h-6 w-px bg-gray-200 mx-2 hidden sm:block" />
                    {/* 
                    <Dropdown placement="bottom-start" className="min-w-[240px]">
                        <DropdownTrigger>
                            <Button
                                variant="light"
                                className="h-9 px-3 gap-2 text-slate-600 font-bold hover:bg-slate-50 border-none"
                                endContent={<FiChevronDown size={14} className="text-slate-400" />}
                            >
                                <span className="text-xs uppercase tracking-wider">Applications</span>
                            </Button>
                        </DropdownTrigger>
                        <DropdownMenu
                            className="p-2"
                            onAction={(key) => {
                                const mod = moduleMenus.find(m => m.key === key);
                                if (mod) {
                                    const targetPath = mod.children?.[0]?.route || mod.route || "/backoffice";
                                    setModuleKey(mod.key);
                                    navigate(targetPath);
                                }
                            }}
                        >
                            {moduleMenus.map((mod) => (
                                <DropdownItem
                                    key={mod.key}
                                    startContent={
                                        <div className="p-2 rounded-lg bg-slate-50 text-primary-500">
                                            <mod.icon size={18} />
                                        </div>
                                    }
                                    description={mod.description}
                                    className="py-3"
                                    textValue={mod.name}
                                >
                                    <span className="font-bold text-slate-700">{mod.name}</span>
                                </DropdownItem>
                            ))}
                        </DropdownMenu>
                    </Dropdown> */}
                </NavbarBrand>
            </NavbarContent>
            <NavbarContent justify="end">
                <HealthStatus />
                <UserDropdown />
            </NavbarContent>
        </Navbar >
    )
}
