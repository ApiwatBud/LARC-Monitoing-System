import React from "react";
import { useHealthCheck } from "../providers/HealthCheckProvider";
import { Chip } from "@heroui/react";

export const HealthStatus: React.FC = () => {
    const { isOnline, isLoading } = useHealthCheck();

    return (
        <div className="flex items-center gap-2">
            <Chip
                color={isLoading ? "warning" : (isOnline ? "success" : "danger")}
                variant="dot"
                size="sm"
                className="border-none bg-transparent"
            >
                {isLoading ? "Checking Status..." : (isOnline ? "Server Online" : "Server Offline")}
            </Chip>
        </div>
    );
};
