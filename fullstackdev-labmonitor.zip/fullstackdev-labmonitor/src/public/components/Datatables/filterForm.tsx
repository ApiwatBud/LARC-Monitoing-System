import { DateRangePicker, Input, NumberInput, Select, SelectItem } from "@heroui/react"
import { getLocalTimeZone, parseAbsolute, toCalendarDate } from "@internationalized/date"
import { TFilterOperator, TFilterOperatorList } from "../../../common/types"

export interface FilterTextInputProps {
    formObj: any
    name: string,
    label: string,
    mutate: () => void,
    options?: { label: string, value: string }[]
}

export type FilterFormWidgets = "text" | "dateRange" | "select" | "numberCompound"

export type FilterFormDefs = {
    widget: FilterFormWidgets
    label: string
    name: string
    options?: { label: string, value: string }[]
}

export const filterForMapping: Record<FilterFormWidgets, (props: FilterTextInputProps) => React.ReactNode> = {
    text: FilterTextInput,
    dateRange: FilterDateRangeInput,
    select: FilterSelectInput,
    numberCompound: FilterNumberCompoundInput
}

export function FilterNumberCompoundInput({ formObj, name, label, mutate }: FilterTextInputProps) {

    return (
        <formObj.Field name={name}
            children={(field: any) => {
                console.log("field", field)
                return (
                    <div className="flex flex-row gap-0">

                        <Select aria-label="operator"
                            label="OP"
                            size="sm"
                            className="w-1/4 min-w-[5rem]"
                            radius="none"
                            classNames={{
                                trigger: "rounded-l-md rounded-r-none border-r-0 shadow-none",
                                selectorIcon: "hidden"
                            }}
                            selectorIcon={<span />}

                            selectedKeys={field.state.value.operator ? [field.state.value.operator] : []}
                            onSelectionChange={(keys) => {
                                // HeroUI returns a Set of keys; we extract the first one
                                const selectedValue = Array.from(keys)[0] as string;
                                field.handleChange({ ...field.state.value, operator: selectedValue });
                                mutate()

                            }}
                        >
                            {TFilterOperatorList.map((operator) => (
                                <SelectItem key={operator} aria-label={operator}>
                                    {operator}
                                </SelectItem>
                            ))}
                        </Select>

                        <NumberInput
                            classNames={{
                                inputWrapper: "rounded-r-md rounded-l-none shadow-none"
                            }}
                            radius="none"

                            label={label}
                            size="sm"
                            value={field.state.value.value as number}
                            onValueChange={(e) => {
                                formObj.setFieldValue(name, { ...field.state.value, value: e })
                                mutate()
                            }}
                        />
                    </div>
                )
            }}
        />

    )
}

export function FilterSelectInput({ formObj, name, label, mutate, options }: FilterTextInputProps) {
    return (
        <formObj.Field name={name}
            children={(field: any) => {
                return (
                    <Select
                        label={label}
                        size="sm"
                        selectedKeys={field.state.value ? [field.state.value] : []}
                        onChange={(e) => {
                            formObj.setFieldValue(name, e.target.value)
                            mutate()
                        }}
                    >
                        {(options || []).map((opt) => (
                            <SelectItem key={opt.value}>
                                {opt.label}
                            </SelectItem>
                        ))}
                    </Select>
                )
            }}
        />
    )
}

export function FilterTextInput({ formObj, name, label, mutate }: FilterTextInputProps) {
    return (<formObj.Field name={name}
        children={(field: any) => {
            return <Input
                label={label}
                size="sm"
                type="text"
                value={field.state.value as string}
                onChange={(e) => {
                    formObj.setFieldValue(name, e.target.value)
                    mutate()
                }}
            />
        }
        }
    />)
}


export function FilterDateRangeInput({ formObj, name, label, mutate }: FilterTextInputProps) {

    const cvtDateRangeToArray = (dateRange: any) => {
        if (!dateRange) return [];
        return [
            dateRange.start.toDate(getLocalTimeZone()).toISOString(),
            dateRange.end.toDate(getLocalTimeZone()).toISOString(),
        ]
    };

    const cvtArrayISOStringToDateRange = (dateRange: string[]): any => {
        if (!dateRange || dateRange.length < 2 || !dateRange[0] || !dateRange[1]) {
            return null;
        }
        try {
            return {
                start: toCalendarDate(parseAbsolute(dateRange[0], getLocalTimeZone())),
                end: toCalendarDate(parseAbsolute(dateRange[1], getLocalTimeZone())),
            }
        } catch (e) {
            console.error('Failed to parse date range:', e);
            return null;
        }
    }

    return (
        <formObj.Field
            name={name}
            children={(field: any) => {
                return (
                    <DateRangePicker
                        size='sm'
                        hideTimeZone
                        aria-label={label}
                        label={label}
                        value={field.state.value && Array.isArray(field.state.value) ? cvtArrayISOStringToDateRange(field.state.value) : null}
                        onChange={(value) => {
                            formObj.setFieldValue(name, cvtDateRangeToArray(value))
                            mutate()
                        }}

                        onBlur={() => {
                            // mutate();
                        }}
                    />
                );
            }}
        />
    )
}

