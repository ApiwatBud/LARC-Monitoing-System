import {
    Table,
    TableHeader,
    TableColumn,
    TableBody,
    TableRow,
    TableCell,
    Spinner,
    Pagination,
    Button,
    addToast,
    PressEvent
} from "@heroui/react"
import { flexRender, Table as TanstackTable } from "@tanstack/react-table"
import { FaSort, FaSortDown, FaSortUp } from "react-icons/fa"
import { generatePath, useNavigate } from "react-router"
import { BaseEntity, JustEntity } from "../../../common/domains/baseEntity"
import { filterForMapping, FilterFormDefs } from "./filterForm"
import { TPaginateQuery, TPaginateQueryForm, TPaginateResult } from "../../../common/types"
import { useGenericDataTable } from "./useGenericDataTable"
import { useEffect } from "react"

export interface ZZBYDatatableProps<T extends object> {
    table: TanstackTable<T>,
    isFetching: boolean,
    handleSort: (columnId: string) => void,
    viewRoute?: string
}

export type EntityColumn<T> = {
    key: keyof T
    header: string
    cell: (info: any) => React.ReactNode
    meta?: {
        isTitle?: boolean
    }
}

export interface IGenericDataTableProps<T extends object> {
    colDefs: EntityColumn<T>[]
    defaultFilter: TPaginateQueryForm<T>
    queryFn: (body: TPaginateQuery<T>) => Promise<{ data: TPaginateResult<T> | null } & any>,
    queryKey: string[]
    filterFormDefs: FilterFormDefs[],
    exportFn?: (filter: TPaginateQueryForm<T>) => void,
    viewRoute?: string
}

export const GenericDataTable = <T extends JustEntity>({
    colDefs,
    defaultFilter,
    queryFn,
    queryKey,
    filterFormDefs,
    viewRoute,
    exportFn
}: IGenericDataTableProps<T>) => {
    const {
        table,
        filterForm,
        isFetching,
        debouncedMutate,
        handleSort,
        query
    } = useGenericDataTable<T>({
        colDefs,
        defaultFilter,
        queryFn,
        queryKey
    })

    useEffect(() => {
        if (query.data?.status && query.data?.status != 200) {
            addToast({
                title: 'Error',
                description: query.data?.error.value,
                color: 'danger'
            })
        }
    }, [])
    return (
        <div className="w-full">
            <div className="overflow-hidden border border-gray-200 rounded-xl bg-white shadow-sm">
                {/* Filter Form Section */}
                <div className="p-3 border-b border-gray-100">
                    <form
                        className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3'
                        onSubmit={(e) => e.preventDefault()}
                    >
                        {filterFormDefs && filterFormDefs.map((def, index) => {
                            const Widget = filterForMapping[def.widget]
                            if (def.widget === "numberCompound") {
                                return (<div key={`${def.widget}-${def.name}-${index}`}>
                                    <Widget
                                        formObj={filterForm}
                                        name={`filter.${def.name}`}
                                        label={def.label}
                                        mutate={debouncedMutate}
                                        options={def.options}
                                    />
                                </div>)
                            }
                            return (
                                <div key={`${def.widget}-${def.name}-${index}`}>
                                    <Widget
                                        formObj={filterForm}
                                        name={`filter.${def.name}.value`}
                                        label={def.label}
                                        mutate={debouncedMutate}
                                        options={def.options}
                                    />
                                </div>
                            )
                        })}
                    </form>

                    <div className="flex flex-row gap-1 mt-3">
                        <Button
                            color="default"
                            size="sm"
                            variant="flat"
                            onPress={(e: PressEvent) => {
                                filterForm.reset()
                                debouncedMutate()
                            }}
                        >
                            Reset Filters
                        </Button>
                        {exportFn && (
                            <Button color="default"
                                size="sm"
                                variant="flat"
                                onPress={(e: PressEvent) => exportFn(filterForm.state.values)}>
                                Export Excel
                            </Button>
                        )}
                    </div>
                </div>

                {/* Data Table Section */}
                <ZZBYDatatable
                    handleSort={handleSort}
                    table={table}
                    isFetching={isFetching}
                    viewRoute={viewRoute}
                />
            </div>

            {/* Pagination Section */}
            <div className="mt-6 flex items-center justify-between px-2">
                <p className="text-sm text-gray-500">
                    Showing <span className="font-medium">{table.getRowModel().rows.length}</span> results
                </p>
                <Pagination
                    total={table.getPageCount()}
                    page={table.getState().pagination.pageIndex + 1}
                    onChange={(page) => table.setPageIndex(page - 1)}
                    showControls
                    color="primary"
                    variant="flat"
                    size="sm"
                />
            </div>
        </div>
    )
}

export function ZZBYDatatable<T extends object>({
    table,
    isFetching,
    handleSort,
    viewRoute
}: ZZBYDatatableProps<T>) {
    const navigate = useNavigate()

    return (
        <Table
            aria-label="Records Table"
            isHeaderSticky
            shadow="none"
            radius="none"
            classNames={{
                wrapper: "max-h-[700px] p-0 shadow-none",
                th: "bg-default-50 text-default-600 text-tiny font-bold uppercase h-12 border-b border-divider",
                td: "py-3 px-6 text-small border-b border-divider group-last:border-b-0",
                tr: "transition-colors group hover:bg-default-50/50",
            }}
        >
            <TableHeader>
                {table.getHeaderGroups().flatMap(headerGroup =>
                    headerGroup.headers.map(header => (
                        <TableColumn
                            key={header.id}
                            className={header.column.getCanSort() ? 'cursor-pointer select-none group/col' : ''}
                            onClick={() => header.column.getCanSort() && handleSort(header.column.id)}
                        >
                            <div className="flex items-center gap-2 group-hover/col:text-gray-900 transition-colors">
                                {header.isPlaceholder
                                    ? null
                                    : flexRender(
                                        header.column.columnDef.header,
                                        header.getContext()
                                    )}

                                {header.column.getCanSort() && (
                                    <span className="text-default-400">
                                        {{
                                            asc: <FaSortUp className="w-3 h-3 text-primary" />,
                                            desc: <FaSortDown className="w-3 h-3 text-primary" />,
                                        }[header.column.getIsSorted() as string] ?? (
                                                <FaSort className="w-3 h-3 opacity-0 group-hover/col:opacity-40 transition-opacity" />
                                            )}
                                    </span>
                                )}
                            </div>
                        </TableColumn>
                    ))
                )}
            </TableHeader>
            <TableBody
                items={table.getRowModel().rows}
                isLoading={isFetching}
                loadingContent={
                    <div className="flex flex-col items-center justify-center gap-3 py-10">
                        <Spinner size="lg" color="primary" />
                        <p className="text-small font-medium text-default-500 animate-pulse">
                            Fetching records...
                        </p>
                    </div>
                }
                emptyContent={!isFetching ? "No records found matching your filters." : " "}
            >
                {(row) => (
                    <TableRow key={row.id}>
                        {row.getVisibleCells().map(cell => (
                            <TableCell
                                key={cell.id}
                                className={cell.column.columnDef.meta?.isTitle ? "cursor-pointer font-medium" : ""}
                                onClick={() => {
                                    if (cell.column.columnDef.meta?.isTitle && viewRoute) {
                                        navigate(generatePath(viewRoute, { ...row.original }))
                                    }
                                }}
                            >
                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                            </TableCell>
                        ))}
                    </TableRow>
                )}
            </TableBody>
        </Table>
    )
}
