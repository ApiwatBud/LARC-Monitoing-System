import { addToast, DropdownItem } from "@heroui/react"
import { useNavigate } from "react-router"

export interface DeleteDropdownItemProps {
    entityName: string
    id: string
    backRoute: string
    deleteFn: () => Promise<{ status: number, error?: any }>
}
export function DeleteDropdownItem({ entityName, id, backRoute, deleteFn }: DeleteDropdownItemProps) {

    const navigate = useNavigate()
    return (
        <DropdownItem
            key="delete"
            className="text-danger"
            color="danger"
            onPress={async () => {
                if (confirm(`Are you sure you want to delete this ${entityName}?`)) {
                    const response = await deleteFn();

                    if (response.status === 200) {
                        addToast({
                            title: "Success",
                            description: `${entityName} deleted successfully`,
                            color: "success",
                        })
                        navigate(backRoute);
                    } else if (response.status === 422) {
                        addToast({
                            title: "Error : Deletion Failed",
                            description: response.error?.value?.message || "Invalid request",
                            color: "danger",
                        })
                    } else {
                        addToast({
                            title: "Error",
                            description: `Failed to delete ${entityName}`,
                            color: "danger",
                        })
                    }
                }
            }}
        >
            Delete
        </DropdownItem>
    )
}