import { useForm } from "@tanstack/react-form"
import { useQuery } from "@tanstack/react-query"
import { createColumnHelper, getCoreRowModel, useReactTable } from "@tanstack/react-table"
import { useMemo, useCallback, useState } from "react"
import { BaseEntity, JustEntity } from "../../../common/domains/baseEntity"
import { TFilterOperator, TPaginateQuery, TPaginateQueryForm, TPaginateResult } from "../../../common/types"
import { debounce } from "../../../common/utils/debounce"
import { EntityColumn } from "./zzbyDatatable"
import { addToast } from "@heroui/react"
import { transformFilterFormToQuery } from "../../utils/filterUtils"

export interface UseGenericDataTableProps<T extends object> {
    colDefs: EntityColumn<T>[]
    defaultFilter: TPaginateQueryForm<T>
    queryFn: (body: TPaginateQuery<T>) => Promise<{ data: TPaginateResult<T> | null } & any>
    queryKey: string[]
}

export function useGenericDataTable<T extends JustEntity>({
    colDefs,
    defaultFilter,
    queryFn,
    queryKey
}: UseGenericDataTableProps<T>) {

    // 1. Columns definition - Memoized
    const columns = useMemo(() => {
        const columnHelper = createColumnHelper<T>()
        return colDefs.map(col =>
            columnHelper.accessor(col.key as any, {
                header: col.header,
                cell: col.cell,
                meta: {
                    isTitle: col.meta?.isTitle
                }
            })
        )
    }, [colDefs])

    // 2. Filter Form
    const filterForm = useForm({
        defaultValues: defaultFilter,
    })

    // 3. Debounced Filter State for Query
    const [debouncedParams, setDebouncedParams] = useState(defaultFilter);

    const debouncedMutate = useMemo(
        () => debounce(() => {
            setDebouncedParams(filterForm.state.values);
        }, 500),
        [filterForm]
    )

    // 4. Data Query
    const query = useQuery({
        queryKey: [...queryKey, debouncedParams],
        queryFn: async () => {
            const filterReq = transformFilterFormToQuery(debouncedParams)
            let response = await queryFn(filterReq)
            return response
        },
    })

    // 5. Sorting Handler
    const handleSort = useCallback((columnId: string) => {
        const currentSort = [...(filterForm.state.values.sort || [])] as { key: string, order: 'asc' | 'desc' }[]
        const existingIndex = currentSort.findIndex((s) => s.key === columnId)

        let newSort: { key: string, order: 'asc' | 'desc' }[] = []
        if (existingIndex === -1) {
            newSort = [{ key: columnId, order: 'asc' }]
        } else if (currentSort[existingIndex].order === 'asc') {
            newSort = [{ key: columnId, order: 'desc' }]
        } else {
            newSort = []
        }

        (filterForm as any).setFieldValue('sort', newSort as any);
        setDebouncedParams({ ...filterForm.state.values, sort: newSort } as any);
    }, [filterForm])

    // 6. Table Instance
    const table = useReactTable({
        data: (query.data?.data?.data as T[]) || [],
        columns: columns,
        pageCount: query.data?.data?.totalPages ?? -1,
        manualPagination: true,
        manualSorting: true,
        state: {
            pagination: {
                pageIndex: filterForm.state.values.page - 1,
                pageSize: filterForm.state.values.limit,
            },
            sorting: filterForm.state.values.sort.map((s: any) => ({
                id: s.key as string,
                desc: s.order === 'desc'
            })),
        },
        onPaginationChange: (updater: any) => {
            const nextState = typeof updater === 'function'
                ? updater({
                    pageIndex: filterForm.state.values.page - 1,
                    pageSize: filterForm.state.values.limit,
                })
                : updater;

            (filterForm as any).setFieldValue('page', nextState.pageIndex + 1);
            (filterForm as any).setFieldValue('limit', nextState.pageSize);
            setDebouncedParams({
                ...filterForm.state.values,
                page: nextState.pageIndex + 1,
                limit: nextState.pageSize
            });
        },
        getCoreRowModel: getCoreRowModel(),
    })

    return {
        table,
        filterForm,
        query,
        debouncedMutate,
        handleSort,
        isFetching: query.isFetching
    }
}
