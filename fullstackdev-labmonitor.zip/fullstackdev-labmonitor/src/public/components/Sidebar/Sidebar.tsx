import { Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Tooltip } from "@heroui/react";
import { AnimatePresence, motion, Variants } from "framer-motion";
import { useEffect, useState } from "react";
import {
    FiChevronDown,
    FiChevronRight
} from "react-icons/fi";
import { useLocation, useNavigate } from "react-router";
import { filterVisibleMenus } from "../../common/menu";
import { moduleMenus } from "../../config/moduleMenus";
import { useCurrentUser } from "../../providers/CurrentUserProvider";
import { useSidebar } from "../../providers/SidebarProvider";
import { useAppModuleStore } from "../../stores/useAppModuleStore";
import { ModuleMenu } from "../../../modules/config/domains/entities/menu.entity";

const sidebarVariants: Variants = {
    open: {
        width: "240px",
        transition: {
            type: "tween",
            duration: 0.3,
            ease: "easeInOut"
        },
    },
    closed: {
        width: "64px",
        transition: {
            type: "tween",
            duration: 0.3,
            ease: "easeInOut"
        },
    },
};

const itemVariants: Variants = {
    open: {
        opacity: 1,
        width: "auto",
        display: "flex",
        transition: {
            type: "tween",
            duration: 0.3,
            delay: 0.1
        }
    },
    closed: {
        opacity: 0,
        width: 0,
        transition: {
            duration: 0.2
        },
        transitionEnd: {
            display: "none"
        }
    }
};

const subMenuVariants: Variants = {
    open: {
        height: "auto",
        opacity: 1,
        transition: {
            height: {
                duration: 0.3,
                ease: "easeOut"
            },
            opacity: {
                duration: 0.2,
                delay: 0.1
            }
        }
    },
    closed: {
        height: 0,
        opacity: 0,
        transition: {
            height: {
                duration: 0.3,
                ease: "easeIn"
            },
            opacity: {
                duration: 0.2
            }
        }
    }
};

function SidebarItem({ item, isOpen, level = 0 }: { item: ModuleMenu, isOpen: boolean, level?: number }) {
    const navigate = useNavigate();
    const location = useLocation();
    const [isCollapsed, setIsCollapsed] = useState(true);

    const hasChildren = item.children && item.children.length > 0;
    const isActive = item.route ? location.pathname === item.route : false;
    // Check if any child is active
    const isChildActive = hasChildren && item.children?.some(child => child.route === location.pathname);

    // Auto expand if child is active
    useEffect(() => {
        if (isChildActive) {
            setIsCollapsed(false);
        }
    }, [isChildActive]);

    const handleClick = () => {
        if (isActive) return;
        if (hasChildren) {
            setIsCollapsed(!isCollapsed);
        } else if (item.route) {
            navigate(item.route);
        }
    };

    return (
        <li className="flex flex-col w-full list-none">
            <Tooltip
                content={item.name}
                placement="right"
                isDisabled={isOpen}
                closeDelay={0}
            >
                <div
                    onClick={handleClick}
                    className={`
                        flex items-center rounded-lg transition-colors duration-200 mx-2 mb-1
                        ${isOpen ? "px-3 py-2 justify-start" : "p-2 justify-center"}
                        ${isActive ? "bg-primary text-white cursor-default" : "text-gray-700 hover:bg-gray-100 cursor-pointer"}
                        ${isChildActive && !isActive ? "bg-gray-50 text-primary font-medium" : ""}
                    `}
                    style={{ marginLeft: isOpen ? `${8 + level * 12}px` : "8px" }}
                >
                    <item.icon size={20} className="flex-shrink-0" />
                    <AnimatePresence mode="wait">
                        {isOpen && (
                            <motion.div
                                variants={itemVariants}
                                initial="closed"
                                animate="open"
                                exit="closed"
                                className="flex-1 flex flex-row items-center justify-between ml-3 overflow-hidden text-sm"
                            >
                                <span className="font-medium truncate">{item.name}</span>
                                {hasChildren && (
                                    <motion.div
                                        animate={{ rotate: isCollapsed ? 0 : 90 }}
                                        transition={{ duration: 0.2 }}
                                        className=""
                                    >
                                        <FiChevronRight size={14} className={`${isActive ? "text-white" : "text-gray-400"}`} />
                                    </motion.div>
                                )}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </Tooltip>

            {/* Sub Menu Items */}
            <AnimatePresence>
                {hasChildren && isOpen && !isCollapsed && (
                    <motion.ul
                        variants={subMenuVariants}
                        initial="closed"
                        animate="open"
                        exit="closed"
                        className="flex flex-col gap-0 p-0 overflow-hidden list-none"
                    >
                        {item.children?.map(child => (
                            <SidebarItem
                                key={child.key}
                                item={child}
                                isOpen={isOpen}
                                level={level + 1}
                            />
                        ))}
                    </motion.ul>
                )}
            </AnimatePresence>
        </li>
    );
}



export default function Sidebar() {
    const { isOpen, toggle } = useSidebar();
    const navigate = useNavigate();
    const { currentModuleKey, setModuleKey } = useAppModuleStore();
    const { permissions, roles, modules } = useCurrentUser();

    // Filter menus based on user permissions, roles, and enabled modules
    const filteredModuleMenus = filterVisibleMenus(
        moduleMenus,
        permissions || [],
        roles || [],
        modules || []
    );

    const activeModule = filteredModuleMenus.find(m => m.key === currentModuleKey) || filteredModuleMenus[0];
    const currentItems = activeModule?.children || [];

    return (
        <motion.aside
            initial="closed"
            animate={isOpen ? "open" : "closed"}
            variants={sidebarVariants}
            className="flex flex-col flex-shrink-0 h-screen overflow-hidden whitespace-nowrap bg-white text-gray-800 border-r border-gray-200"
        >
            {/* Module Switcher Dropdown */}
            <div className={`flex items-center h-14 mx-2 ${isOpen ? "px-2 justify-start" : "justify-center"}`}>
                <Dropdown placement="bottom-start">
                    <DropdownTrigger>
                        <div className={`flex items-center cursor-pointer rounded-lg hover:bg-gray-100 transition-colors ${isOpen ? "w-full p-2" : "justify-center p-2"}`}>
                            <div className="text-blue-600 flex-shrink-0">
                                {
                                    (() => {
                                        const Icon = activeModule?.icon;
                                        return Icon ? <Icon size={20} /> : null;
                                    })()
                                }
                            </div>
                            <AnimatePresence>
                                {isOpen && (
                                    <motion.div
                                        initial={{ opacity: 0, width: 0 }}
                                        animate={{ opacity: 1, width: "auto" }}
                                        exit={{ opacity: 0, width: 0 }}
                                        className="flex items-center flex-1 ml-3 overflow-hidden"
                                    >
                                        <span className="font-bold text-lg whitespace-nowrap flex-1 text-left">
                                            {activeModule?.name || "Select Module"}
                                        </span>
                                        <div className="text-gray-400">
                                            <FiChevronDown size={16} />
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </DropdownTrigger>

                    <DropdownMenu
                        aria-label="Module Actions"
                        onAction={(key) => {
                            const mod = filteredModuleMenus.find(m => m.key === key);
                            if (mod) {
                                const targetPath = mod.children?.[0]?.route || mod.route || "/backoffice";
                                setModuleKey(mod.key);
                                navigate(targetPath);
                            }
                        }}
                        selectedKeys={new Set([currentModuleKey])}
                        selectionMode="single"
                        items={filteredModuleMenus}
                    >
                        {(module: ModuleMenu) => (
                            <DropdownItem key={module.key} startContent={<module.icon size={20} />}>
                                {module.name}
                            </DropdownItem>
                        )}
                    </DropdownMenu>
                </Dropdown>
            </div>

            <div className="flex flex-col flex-1 py-3 px-1 overflow-y-auto no-scrollbar">
                <nav className="w-full">
                    <ul className="flex flex-col gap-0 p-0 list-none">
                        {currentItems.map((item) => (
                            <SidebarItem key={item.key} item={item} isOpen={isOpen} />
                        ))}
                    </ul>
                </nav>
            </div>
        </motion.aside>
    );
}