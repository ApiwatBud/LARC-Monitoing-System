import { Alert, Button, Card, CardBody, CardHeader, Divider, Input } from "@heroui/react";
import { useForm } from "@tanstack/react-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { client } from "../../../client";
import { setElysiaErrors } from "../../utils";
import { loginDto } from "../../../modules/core/applications/dtos/auth.dto";
import { useNavigate } from "react-router";
import { useState } from "react";



import { useHealthCheck } from "../../providers/HealthCheckProvider";
import { FiGrid } from "react-icons/fi";

export default function LoginForm() {
    const { isOnline, isLoading: isHealthLoading, error: healthError } = useHealthCheck();
    const queryClient = useQueryClient()
    const navigate = useNavigate()

    const [formError, setFormError] = useState<string | null>(null)

    const socialProviders = useQuery({
        queryKey: ['social-providers-public'],
        queryFn: async () => {
            const res = await client.api.auth.social.providers.get();
            if (res.error) throw res.error;
            return res.data;
        },
        enabled: isOnline
    })


    const loginMutation = useMutation({
        mutationFn: async (credentials: z.infer<typeof loginDto>) => {
            if (!isOnline) {
                setFormError("Server is currently unreachable.")
                return;
            }
            const res = await client.api.login.post(credentials)
            if (res.status === 200) {
                return res.data
            }

            if (res.status === 422) {
                setElysiaErrors(form, res.error)
                return;
            }

            if (res.status === 401) {
                setFormError(res.error?.value.message ?? "Unknown Error")
                return false;
            }

            setFormError(res.error?.value.message ?? "Unknown Error")
            throw new Error(res.error?.value.message)
        },
        onSuccess: (data) => {
            if (data) {
                navigate('/')
            }
        },
        onError: (error) => {
            console.error(error)
        }
    })

    const form = useForm({
        defaultValues: {
            email: "",
            password: "",
        },
        validators: {
            // onSubmit: loginDto,
        },
        onSubmit: async ({ value }) => {
            setFormError(null)
            if (!isOnline) {
                setFormError("Cannot connect to server. Please check your connection.")
                return;
            }
            await loginMutation.mutateAsync(value)
        },
    })

    return (
        <div className="flex flex-col items-center gap-8 w-full max-w-[440px] px-4">
            <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-primary-600 text-white shadow-lg shadow-primary-200">
                    <FiGrid size={28} />
                </div>
                <h1 className="text-3xl font-black text-slate-800 tracking-tighter">ZZBY</h1>
            </div>

            <Card className="w-full shadow-2xl shadow-slate-200/50 border-none p-2 md:p-4">
                <CardHeader className="flex flex-col items-start px-6 pt-6 pb-2">
                    <h2 className="text-xl font-bold text-slate-800">Welcome Back</h2>
                    <p className="text-sm text-slate-500 mt-1">Please enter your details to sign in.</p>
                </CardHeader>
                <CardBody className="px-6 py-4">
                    <form onSubmit={(e) => {
                        e.preventDefault()
                        form.handleSubmit(e)
                    }} className="flex flex-col gap-5">
                        {!isOnline && !isHealthLoading && (
                            <Alert color="danger" title="Server Offline" variant="flat">
                                <div className="flex flex-col gap-1">
                                    <span>Cannot connect to the server. Please ensure the backend is running.</span>
                                    {healthError && (
                                        <span className="text-xs opacity-80 font-mono">
                                            {healthError.message || "Connection Refused"}
                                        </span>
                                    )}
                                </div>
                            </Alert>
                        )}
                        {formError && (
                            <Alert color="danger" variant="flat">
                                {formError}
                            </Alert>
                        )}
                        <form.Field name="email"
                            children={(field) => (
                                <Input
                                    label="Email or Username"
                                    type="text"
                                    variant="bordered"
                                    labelPlacement="outside"
                                    placeholder="Enter your email or username"
                                    value={field.state.value}
                                    isInvalid={field.state.meta.errors.length > 0}
                                    disabled={!isOnline && !isHealthLoading}
                                    errorMessage={field.state.meta.errors.length > 0
                                        ? field.state.meta.errors.map((error: any) => error?.message).join("<br/>")
                                        : undefined
                                    }
                                    onChange={(e) => field.handleChange(e.target.value)}
                                    classNames={{
                                        label: "text-slate-700 font-semibold",
                                        inputWrapper: "border-slate-200 hover:border-primary focus-within:!border-primary transition-colors",
                                    }}
                                />
                            )}
                        />
                        <form.Field name="password"
                            children={(field) => (
                                <Input
                                    label="Password"
                                    type="password"
                                    variant="bordered"
                                    labelPlacement="outside"
                                    placeholder="Enter your password"
                                    value={field.state.value}
                                    isInvalid={field.state.meta.errors.length > 0}
                                    disabled={!isOnline && !isHealthLoading}
                                    errorMessage={field.state.meta.errors.length > 0
                                        ? field.state.meta.errors.map((error: any) => error?.message).join("<br/>")
                                        : undefined
                                    }
                                    onChange={(e) => field.handleChange(e.target.value)}
                                    classNames={{
                                        label: "text-slate-700 font-semibold",
                                        inputWrapper: "border-slate-200 hover:border-primary focus-within:!border-primary transition-colors",
                                    }}
                                />
                            )}
                        />

                        <Button
                            type="submit"
                            color="primary"
                            size="lg"
                            className="font-bold shadow-lg shadow-primary-200 mt-2"
                            isDisabled={(!isOnline && !isHealthLoading) || loginMutation.isPending}
                            isLoading={loginMutation.isPending || isHealthLoading}
                        >
                            {isHealthLoading ? "Checking Server..." : (isOnline ? "Sign In" : "Server Offline")}
                        </Button>
                    </form>

                    {socialProviders.data && socialProviders.data.length > 0 && (
                        <div className="flex flex-col gap-6 mt-8 mb-4">
                            <div className="flex items-center gap-4">
                                <Divider className="flex-1 bg-slate-100" />
                                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Or continue with</span>
                                <Divider className="flex-1 bg-slate-100" />
                            </div>
                            <div className="grid grid-cols-1 gap-3">
                                {socialProviders.data.map((provider: any) => (
                                    <Button
                                        key={provider.provider}
                                        variant="flat"
                                        size="lg"
                                        className="font-semibold bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all"
                                        onPress={() => window.location.href = `/api/auth/social/${provider.provider}/login`}
                                        isDisabled={!isOnline}
                                        startContent={
                                            provider.provider === 'google' ? <i className="fa-brands fa-google text-red-500"></i> :
                                                provider.provider === 'line' ? <i className="fa-brands fa-line text-green-500"></i> :
                                                    provider.provider === 'microsoft' ? <i className="fa-brands fa-microsoft text-blue-500"></i> :
                                                        <FiGrid />
                                        }
                                    >
                                        {provider.name}
                                    </Button>
                                ))}
                            </div>
                        </div>
                    )}
                </CardBody>
            </Card >
            <p className="text-xs text-slate-400 mt-2">
                &copy; {new Date().getFullYear()} ZZBY. All rights reserved.
            </p>
        </div>
    )
}