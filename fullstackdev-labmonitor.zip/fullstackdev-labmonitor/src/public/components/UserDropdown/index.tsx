import { Dropdown, DropdownItem, DropdownMenu, DropdownSection, DropdownTrigger, User } from "@heroui/react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { client } from "../../../client";
import { useNavigate } from "react-router";
import { useEffect } from "react";

export default function UserDropdown() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const { data: me, isLoading } = useQuery({
        queryKey: ['me'],
        queryFn: async () => {
            const res = await client.api.me.post();
            if (res.status === 200) {
                return res.data;
            }
            return null;
        }
    });

    const logoutMutation = useMutation({
        mutationFn: async () => {
            const res = await client.api.logout.post();
            return res;
        },
        onSuccess: () => {
            queryClient.setQueryData(['me'], null);
            navigate('/login');
        }
    });

    useEffect(() => {
        if (!isLoading && !me?.user) {
            navigate('/login');
        }
    }, [isLoading, me, navigate]);

    return (
        <Dropdown placement="bottom-end">
            <DropdownTrigger>
                <User
                    as="button"
                    className="transition-transform"
                    description={me?.user?.email}
                    name={me?.user?.username}
                />
            </DropdownTrigger>
            <DropdownMenu aria-label="User Actions" variant="flat">
                <DropdownSection showDivider>
                    <DropdownItem key="profile" className="h-14 gap-2 text-default-600">
                        <p className="font-semibold">Signed in as</p>
                        <p className="font-semibold">{me?.user?.email}</p>
                    </DropdownItem>
                </DropdownSection>
                <DropdownItem key="edit-profile" onPress={() => navigate(`/backoffice/profile`)}>
                    Edit Profile
                </DropdownItem>
                <DropdownItem key="apps" onPress={() => navigate(`/backoffice`)}>
                    Apps
                </DropdownItem>
                <DropdownItem key="logout" color="danger" className="text-danger" onPress={() => logoutMutation.mutate()}>
                    Log Out
                </DropdownItem>
            </DropdownMenu>
        </Dropdown>
    );
}
