import { addToast, Autocomplete, AutocompleteItem, Checkbox, CheckboxGroup, DatePicker, Input, Select, SelectItem, Spinner, Textarea } from "@heroui/react";
import { parseAbsoluteToLocal } from "@internationalized/date";
import { useAsyncList } from "@react-stately/data";
import { useForm } from "@tanstack/react-form";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { client } from "../../../client";


export interface ZZBYFormInputProps {
    form: any
    name: string
    label: string
    placeholder?: string
    type?: string
    isReadOnly?: boolean

    queryFn?: (search?: string) => Promise<any> | ((params: any) => Promise<any>)
    mapFn?: (data: any) => { label: string, value: string }
    valueMapFn?: (data: any) => string
    sortFn?: (a: any, b: any) => number
    afterSelectFn?: (data: any) => void
    queryFnParams?: any
    enabled?: boolean
}


const getMessage = (field: any) => {
    const error = field.state.meta.errors?.[0]
    if (typeof error === 'object' && error !== null) {
        return (error as any).message
    }
    return error?.toString() ?? ''
}

const getIsInvalid = (field: any) => {
    return field.state.meta.isTouched && !!field.state.meta.errors.length
}


export function ZZBYFormFieldInput({ form, name, label, placeholder, type = 'text', isReadOnly = false }: ZZBYFormInputProps) {

    return (
        <form.Field
            name={name}
            children={(field: any) => {
                const value = field.state.value;
                const safeValue = (typeof value === 'string' || typeof value === 'number') ? String(value) : '';

                return (
                    <Input
                        isReadOnly={isReadOnly}
                        label={label}
                        placeholder={placeholder}
                        value={safeValue}
                        onBlur={field.handleBlur}
                        onChange={(e) => {
                            const val = e.target.value;
                            if (type === 'number') {
                                field.handleChange(val === '' ? null : Number(val));
                            } else {
                                field.handleChange(val);
                            }
                        }}
                        type={type}
                        isInvalid={getIsInvalid(field)}
                        errorMessage={getMessage(field)} />
                );
            }}
        />
    )
}

export function ZZBYFormFieldDatePicker({ form, name, label, isReadOnly = false }: ZZBYFormInputProps) {
    return (
        <form.Field
            name={name}
            children={(field: any) => {

                return (
                    <DatePicker
                        hideTimeZone
                        showMonthAndYearPickers
                        name={name}
                        label={label}
                        isReadOnly={isReadOnly}
                        value={(() => {
                            if (!field.state.value) return undefined;
                            try {
                                let val = String(field.state.value);
                                val = new Date(val).toISOString();
                                return parseAbsoluteToLocal(val) as any;
                            } catch (e) {
                                console.error("Error parsing date:", field.state.value, e);
                                return undefined;
                            }
                        })()}
                        onChange={(e: any) => {
                            if (e) {
                                field.handleChange(e.toDate().toISOString());
                            } else {
                                field.handleChange(null);
                            }
                        }}
                    />
                );
            }}
        />
    )
}


export function ZZBYFormFieldTextarea({ form, name, label, placeholder, isReadOnly = false }: ZZBYFormInputProps) {
    return (
        <form.Field
            name={name}
            children={(field: any) => {
                return (
                    <Textarea
                        isReadOnly={isReadOnly}
                        label={label}
                        placeholder={placeholder}
                        value={field.state.value}
                        onBlur={field.handleBlur}
                        onChange={(e) => field.handleChange(e.target.value)}
                        isInvalid={getIsInvalid(field)}
                        errorMessage={getMessage(field)}
                    />
                );
            }}
        />
    )
}

export function ZZBYJsonTextarea({ form, name, label, placeholder, isReadOnly = false }: ZZBYFormInputProps) {
    return (
        <form.Field
            name={name}
            children={(field: any) => {
                return (
                    <Textarea
                        variant="bordered"
                        minRows={6}
                        maxRows={20}
                        classNames={{
                            input: "font-mono text-sm"
                        }}
                        isReadOnly={isReadOnly}
                        label={label}
                        placeholder={placeholder}
                        value={field.state.value}
                        onBlur={field.handleBlur}
                        onValueChange={(value) => field.handleChange(value)}
                        isInvalid={getIsInvalid(field)}
                        errorMessage={getMessage(field)}
                    />
                );
            }}
        />
    )
}

export function ZZBYFieldSelect({ form, name, label, placeholder, options, isReadOnly = false }: ZZBYFormInputProps & { options: { label: string, value: string }[] }) {
    return (
        <form.Field
            name={name}
            children={(field: any) => {
                return (
                    <Select
                        isDisabled={isReadOnly}
                        label={label}
                        placeholder={placeholder}
                        selectedKeys={
                            field.state.value !== undefined && field.state.value !== null
                                ? [String(field.state.value)]
                                : []
                        }
                        onChange={(e) => field.handleChange(e.target.value)}
                        isInvalid={getIsInvalid(field)}
                        errorMessage={getMessage(field)}
                    >
                        {options.map((option) => (
                            <SelectItem key={option.value}>
                                {option.label}
                            </SelectItem>
                        ))}
                    </Select>
                );
            }}
        />
    )
}

export function ZZBYFieldAsyncSelect({ form, name, label, placeholder, isReadOnly = false, queryFn, mapFn, sortFn, queryFnParams, enabled = true, afterSelectFn }: ZZBYFormInputProps) {
    if (!queryFn || !mapFn) {
        return null
    }
    console.log(queryFnParams)
    const query = useQuery({
        queryKey: [`${name}_options`, queryFnParams],
        queryFn: async () => {
            const res = await (queryFn as any)(queryFnParams);
            return res;
        },
        enabled: enabled
    })

    useEffect(() => {

    }, [queryFnParams])

    const result = query.data as any;
    let dataArr: any[] = [];

    if (Array.isArray(result)) {
        dataArr = result;
    } else if (result && typeof result === 'object') {
        if (Array.isArray(result.data)) {
            dataArr = result.data;
        } else if (result.data && Array.isArray(result.data.data)) {
            dataArr = result.data.data;
        }
    }

    const options = dataArr.map(mapFn)

    if (sortFn) {
        options.sort(sortFn)
    }

    return (
        <form.Field
            name={name}
            children={(field: any) => {
                return (
                    <Select
                        isDisabled={isReadOnly}
                        isLoading={query.isLoading && enabled}
                        label={label}
                        placeholder={placeholder || "Select an option"}
                        selectedKeys={
                            field.state.value !== undefined && field.state.value !== null
                                ? [String(field.state.value)]
                                : []
                        }
                        onChange={(e) => {
                            field.handleChange(e.target.value)
                            if (afterSelectFn) afterSelectFn(dataArr.find((item: any) => mapFn(item).value === e.target.value))
                        }}
                        isInvalid={getIsInvalid(field)}
                        errorMessage={getMessage(field)}
                    >
                        {options.map((option: any) => (
                            <SelectItem key={option.value}>
                                {option.label}
                            </SelectItem>
                        ))}
                    </Select>
                );
            }}
        />
    )
}


export function ZZBYFieldAutocomplete({ form, name, label, placeholder, options, isReadOnly = false, queryFn, mapFn, afterSelectFn, queryFnParams }: ZZBYFormInputProps & { options?: { label: string, value: string }[] }) {

    const list = useAsyncList<any>({
        async load({ filterText }) {
            if (options) {
                return { items: options };
            }
            if (!queryFn || !mapFn) return { items: [] };

            const response = await (queryFn as any)(queryFnParams || filterText);
            const responseData = (response as any)?.data;
            const dataArr = Array.isArray(responseData) ? responseData : (Array.isArray(responseData?.data) ? responseData.data : []);
            return {
                items: dataArr
            };
        },
    });

    const mapItem = (item: any) => {
        if (mapFn) {
            return mapFn(item)
        }
        return { label: item.name, value: item.name }
    }

    return (
        <form.Field
            name={name}
            children={(field: any) => {

                return (
                    <Autocomplete
                        isDisabled={isReadOnly}
                        label={label}
                        placeholder={placeholder}
                        isLoading={list.isLoading}
                        items={list.items.map(mapItem)}
                        inputValue={list.filterText}
                        onInputChange={(val) => {
                            list.setFilterText(val);
                            field.handleChange(val);
                        }}

                        selectedKey={field.state.value ? String(field.state.value) : ""}
                        onSelectionChange={(key) => {
                            if (key) {
                                console.log(key);
                                field.handleChange(key);
                                list.setFilterText(String(key));
                            }
                        }}

                        isInvalid={field.state.meta.isTouched && !!field.state.meta.errors.length}
                        errorMessage={field.state.meta.errors.join(', ')}
                        allowsCustomValue={true}
                    >
                        {(item: any) => (
                            <AutocompleteItem key={item.value}>
                                {item.label}
                            </AutocompleteItem>
                        )}
                    </Autocomplete>
                );
            }}
        />
    )
}

export function ZZBYFieldCheckBoxGroup({ form, name, label, isReadOnly = false, queryFn, mapFn, sortFn }: ZZBYFormInputProps) {
    if (!queryFn || !mapFn) {
        return null
    }
    const query = useQuery({
        queryKey: [`${name}_options`],
        queryFn: async () => {
            const res = await queryFn();
            return res;
        },
    })

    if (query.isLoading) {
        return <Spinner />
    }

    const data = (query.data as any)?.data || []
    const options = Array.isArray(data) ? data.map(mapFn) : []
    if (sortFn) {
        options.sort(sortFn)
    }

    return (
        <form.Field name={name}>
            {(field: any) => {
                const value = field.state.value;
                const selectedIds = Array.isArray(value)
                    ? value.map(id => {
                        if (id === null || id === undefined) return "";
                        if (typeof id === 'object') return "";
                        return String(id);
                    })
                    : [];

                return (
                    <CheckboxGroup
                        label={label}
                        isReadOnly={isReadOnly}
                        value={selectedIds}
                        onValueChange={(values) => {
                            field.handleChange(values.map(v => Number(v)));
                        }}
                        isInvalid={getIsInvalid(field)}
                        errorMessage={getMessage(field)}
                    >
                        {options.map((option: any, index: number) => (
                            <Checkbox key={`${option.value}-${index}`} value={option.value}>
                                {option.label}
                            </Checkbox>
                        ))}
                    </CheckboxGroup>
                );
            }}
        </form.Field>
    )
}

interface ZZBYRoleCheckboxInputProps {
    form: any;
    name: string;
}

export function ZZBYRoleCheckboxInput({ form, name }: ZZBYRoleCheckboxInputProps) {

    return (
        <ZZBYFieldCheckBoxGroup
            form={form}
            name={name}
            label="Select Roles"
            queryFn={() => client.api.roles.get()}
            sortFn={(a: any, b: any) => a.value - b.value} //sort by id
            mapFn={
                (item: any) => {
                    const label = item?.name ?? item?.label ?? (item != null ? String(item) : '');
                    const value = String(item?.id ?? item?.value ?? (item != null ? String(item) : ''));
                    return { label, value };
                }
            }
        />
    )
}



export type FormGeneratorProps<T> = {
    mode: "CREATE" | "EDIT"
    defaultValues: T;
    validators?: any;
    apiSubmit?: (value: T) => Promise<any>
    entityName: string,
    queryKey: any,
    queryClient: ReturnType<typeof useQueryClient>;
    redirectEdit?: (id: string) => void;
    primaryKey?: string;
}

export type ZZBYFormGeneratorWrapperProps<T> = {
    mode: "CREATE" | "EDIT"
    defaultValues: T;
    validators?: any;
    apiSubmit?: (value: T) => Promise<any>
    entityName: string,
    queryKey: any,
    redirectEdit?: (id: string) => void;
    primaryKey?: string;
}


export const formGenerator = <T,>({
    mode,
    defaultValues,
    validators,
    apiSubmit,
    entityName,
    queryKey,
    queryClient,
    redirectEdit,
    primaryKey = 'id',
}: FormGeneratorProps<T>) => {

    let form = useForm({
        defaultValues,
        onSubmit: async ({ value }) => {
            if (apiSubmit) {
                let response = await apiSubmit(value)
                if (response.status === 200) {
                    addToast({
                        title: "Success",
                        description: `${entityName} saved successfully`,
                        color: "success",
                    })

                    if (mode === "CREATE" && redirectEdit) {
                        redirectEdit(response.data[primaryKey])
                    }
                    await queryClient.invalidateQueries(queryKey)

                } else if (response.status === 422) {
                    addToast({
                        title: "Error : Invalid Data",
                        description: `${response.error.value.message}`,
                        color: "danger",
                    })
                    let allerrors = response.error.value.all
                    allerrors.forEach((error: any) => {
                        error.path.forEach((path: any) => {
                            form.setFieldMeta(path, (prev) => ({
                                ...prev,
                                isTouched: true,
                                errorMap: {
                                    onSubmit: error.message,
                                },
                            }));
                        })
                    })
                }
                else {
                    addToast({
                        title: "Error : Please contact administrator",
                        description: `${entityName} save failed`,
                        color: "danger",
                    })
                }
            }
        },
        validators: validators,
    })
    return form
}

export type ZZBYFormWrapperProps<T> = {
    children: (form: any) => React.ReactNode,
    formProps: ZZBYFormGeneratorWrapperProps<T>
}
export function ZZBYFormWrapper<T>({ children, formProps }: ZZBYFormWrapperProps<T>) {


    const queryClient = useQueryClient()
    const form = formGenerator({ ...formProps, queryClient: queryClient })
    return (
        <>
            {children(form)}
        </>
    )
}
