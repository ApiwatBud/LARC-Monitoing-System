import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { moduleMenus } from '../config/moduleMenus'
import { ModuleMenu } from '../../modules/config/domains/entities/menu.entity'

interface AppModuleState {
    currentModuleKey: string
    setModuleKey: (key: string) => void
    moduleMenus: ModuleMenu[]
}

export const useAppModuleStore = create<AppModuleState>()(
    persist(
        (set) => ({
            currentModuleKey: 'system', // default module
            setModuleKey: (key) => set({ currentModuleKey: key }),
            moduleMenus: moduleMenus
        }),
        {
            name: 'app-module-storage',
            partialize: (state) => ({ currentModuleKey: state.currentModuleKey }),
        }
    )
)
