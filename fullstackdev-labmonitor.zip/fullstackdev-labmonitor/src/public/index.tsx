import { HeroUIProvider } from "@heroui/react";
import ReactDOM from "react-dom/client";
import { App } from "./root";

const root = document.getElementById("root");

ReactDOM.createRoot(root!).render(<App />);
