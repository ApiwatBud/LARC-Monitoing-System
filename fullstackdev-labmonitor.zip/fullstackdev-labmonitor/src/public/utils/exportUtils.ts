import { addToast } from "@heroui/react";

/**
 * Handles the response from an Excel export API call and triggers a browser download.
 * @param response The response object from Elysia/Eden client
 * @param fallbackName Fallback filename if not provided in headers
 */
export async function downloadExcelResponse(response: any, fallbackName: string = 'export.xlsx') {
    const { data: resp, headers } = response;

    if (resp && resp instanceof ArrayBuffer) {
        const disposition = new Headers(headers).get("Content-Disposition");

        let filename = fallbackName;
        if (disposition && disposition.includes("filename=")) {
            // Extract filename and handle potential quotes
            const match = disposition.match(/filename="?([^"]+)"?/);
            if (match && match[1]) {
                filename = match[1];
            }
        }

        const blob = new Blob([resp], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();

        // Cleanup
        setTimeout(() => URL.revokeObjectURL(url), 100);
    } else {
        console.error("Export failed", resp);
        addToast({
            title: "Export Failed",
            description: "An error occurred while generating the export. Please try again.",
            color: "danger"
        });
    }
}
