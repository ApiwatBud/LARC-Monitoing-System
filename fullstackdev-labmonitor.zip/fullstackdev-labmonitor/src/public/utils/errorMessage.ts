export const getErrorMessage = (error: any): string => {
    if (!error) return ''
    if (typeof error === 'string') return error
    if (Array.isArray(error)) return error.map(getErrorMessage).join(', ')
    if (typeof error === 'object' && 'message' in error) return error.message
    return 'Invalid input'
}