import { TFilterOperator, TPaginateQuery, TPaginateQueryForm } from "../../common/types";

/**
 * Transforms a TPaginateQueryForm (from React Form) into a TPaginateQuery (for API requests).
 * Filters out empty or null filter values.
 */
export function transformFilterFormToQuery<T extends object>(
    formValues: TPaginateQueryForm<T>
): TPaginateQuery<T> {
    const filterArray = Object.values(formValues.filter)
        .map((v) => {
            // Simplified check for empty/null values
            const isEmpty =
                v.value === '' ||
                v.value === null ||
                v.value === undefined ||
                (Array.isArray(v.value) && v.value.length === 0);

            return isEmpty ? null : (v as { key: keyof T, operator: TFilterOperator, value: any });
        })
        .filter((v): v is { key: keyof T, operator: TFilterOperator, value: any } => v !== null);

    return {
        page: formValues.page,
        limit: formValues.limit,
        sort: formValues.sort,
        withAudit: formValues.withAudit,
        filter: filterArray,
    };
}
