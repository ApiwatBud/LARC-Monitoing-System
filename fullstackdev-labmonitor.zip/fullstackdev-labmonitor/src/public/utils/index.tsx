export const setElysiaErrors = (form: any, elysiaError: any) => {

    const errorValue = elysiaError.value
    console.log(errorValue)
    if (errorValue.type === 'validation' && Array.isArray(errorValue.errors)) {
        errorValue.errors.forEach((err: any) => {
            // Elysia path is an array: ["email"]
            const fieldName = err.path[0];
            console.log('fieldName', err, fieldName)

            form.setFieldMeta(fieldName, (prev: any) => ({
                ...prev,
                errorMap: {
                    ...prev.errorMap,
                    // You can pass a single string or an array of strings
                    onSubmit: {
                        message: err.message
                    }
                },
            }));
        });
    }
};