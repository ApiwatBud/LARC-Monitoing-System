import { useEffect } from "react"
import { client } from "../../client"
import { useNavigate } from "react-router"
import { useAppModuleStore } from "../stores/useAppModuleStore"
import { moduleMenus } from "../config/moduleMenus"

export default function Home() {

    const navigate = useNavigate()
    const { currentModuleKey } = useAppModuleStore()

    useEffect(() => {
        const res = client.api.me.post()
        res.then((r: any) => {
            if (r.status === 200) {
                const module = moduleMenus.find(m => m.key === currentModuleKey) || moduleMenus[0]
                const route = module.children?.[0]?.route || '/backoffice'
                navigate(route)
            } else {
                navigate('/login')
            }
        })
    }, [])


    return (
        <div>
            <h1>Home</h1>
        </div>
    )
}