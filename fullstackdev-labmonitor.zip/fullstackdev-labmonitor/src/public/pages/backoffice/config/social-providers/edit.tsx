import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Switch, Tab, Tabs } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router";
import { client, fetcher } from "../../../../../client";
import { SocialProviderCreateDto, SocialProviderUpdateDto } from "../../../../../modules/config/applications/dtos/social_provider.dto";
import { ZZBYFieldSelect, ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../components/ZZBYForm";
import { DeleteDropdownItem } from "../../../../components/Datatables/deleteDropdownItem";
import { PageContainer } from "../../../../components/PageContainer";
import { SocialProviderEntity } from "../../../../../modules/config/domains/entities/social_provider.entity";

export interface SocialProviderFormProps {
    form: any;
    mode: "CREATE" | "EDIT";
}

export function SocialProviderForm({ form, mode }: SocialProviderFormProps) {
    return (
        <Tabs className="pt-3">
            <Tab key={'basic'} title="Basic Information" >
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <Card>
                            <CardHeader>
                                Provider Details
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFieldSelect
                                    name="provider"
                                    form={form}
                                    label="Provider Key"
                                    placeholder="Select provider"
                                    options={[
                                        { label: "Google", value: "google" },
                                        { label: "Line", value: "line" },
                                        { label: "Office365", value: "microsoft" },
                                    ]}
                                />

                                <ZZBYFormFieldInput
                                    name="name"
                                    form={form}
                                    label="Display Name"
                                    placeholder="e.g. Google Login"
                                />

                                <ZZBYFormFieldInput
                                    name="clientId"
                                    form={form}
                                    label="Client ID"
                                    placeholder="OAuth Client ID"
                                />

                                <ZZBYFormFieldInput
                                    name="clientSecret"
                                    form={form}
                                    label="Client Secret"
                                    placeholder="OAuth Client Secret"
                                    type="password"
                                />
                            </CardBody>
                        </Card>

                        <Card>
                            <CardHeader>
                                Configuration
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFormFieldInput
                                    name="scopes"
                                    form={form}
                                    label="Scopes"
                                    placeholder="email, profile, openid"
                                />

                                <ZZBYFormFieldInput
                                    name="redirectUri"
                                    form={form}
                                    label="Redirect URI (Optional)"
                                    placeholder="Override default callback URL"
                                />

                                <div className="flex items-center gap-2 mt-2">
                                    <form.Field
                                        name="isActive"
                                        children={(field: any) => (
                                            <Switch
                                                isSelected={field.state.value}
                                                onValueChange={field.handleChange}
                                            >
                                                Is Active
                                            </Switch>
                                        )}
                                    />
                                </div>
                            </CardBody>
                        </Card>
                    </div>
                </div>
            </Tab>
        </Tabs>
    );
}

export default function SocialProviderEdit() {
    const routeParams = useParams();
    const navigate = useNavigate();

    const id = routeParams.id as string;
    const mode: "EDIT" | "CREATE" = id ? "EDIT" : "CREATE";

    let formProps: ZZBYFormGeneratorWrapperProps<any>;
    let queryKey = mode === "EDIT" ? ['social-provider', id] : ['social-providers'];
    let entityName = "Social Provider";

    // Prepare default values
    const getDefaultValues = (userData?: SocialProviderEntity) => ({
        provider: userData?.provider ?? '',
        name: userData?.name ?? '',
        clientId: userData?.clientId ?? '',
        clientSecret: userData?.clientSecret ?? '',
        scopes: userData?.scopes?.join(', ') ?? 'email, profile',
        isActive: userData?.isActive ?? true,
        redirectUri: userData?.redirectUri ?? '',
    });

    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: async () => {
            if (mode === "EDIT") {
                const res = await client.api.config["social-providers"]({ id }).get();
                if (res.error) throw res.error;
                return res.data;
            }
            return null;
        },
        enabled: mode === "EDIT" && !!id
    });

    if (mode === "EDIT") {
        if (itemQuery.isLoading) {
            return <div className="p-3">Loading...</div>;
        }

        if (itemQuery.error) {
            throw itemQuery.error;
        }

        if (!itemQuery.data) {
            return (
                <div className="p-3">
                    <div className="mb-4">Provider not found</div>
                    <Button color="primary" onPress={() => window.history.back()}>
                        Back
                    </Button>
                </div>
            );
        }

        const providerData = itemQuery.data as SocialProviderEntity;

        formProps = {
            mode: mode,
            defaultValues: getDefaultValues(providerData),
            validators: {
                // We don't strictly use the DTO validators here because of 'scopes' transformation
                // But we can validate the other fields if needed. For now, rely on form validation.
            },
            apiSubmit: async (value: any) => {
                const payload = {
                    ...value,
                    scopes: value.scopes.split(',').map((s: string) => s.trim()).filter(Boolean),
                    id: parseInt(id)
                };
                const res = await fetcher("/api/config/social-providers/:id", {
                    method: "PUT",
                    body: payload,
                    params: { id: id! },
                });
                return {
                    status: res.status,
                    data: res.data,
                    error: res.error
                }
            },
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (newId: string) => navigate(`/backoffice/system/config/social-providers/${newId}`)
        };

    } else {
        formProps = {
            mode: mode,
            defaultValues: getDefaultValues(),
            validators: {
                // Relaxed validation on frontend for scopes string -> array
            },
            apiSubmit: async (value: any) => {
                const payload = {
                    ...value,
                    scopes: value.scopes.split(',').map((s: string) => s.trim()).filter(Boolean)
                };
                const res = await fetcher("/api/config/social-providers", {
                    method: "POST",
                    body: payload,
                });
                return {
                    status: res.status,
                    data: res.data,
                    error: res.error
                }
            },
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (newId: string) => navigate(`/backoffice/system/config/social-providers/${newId}`, { replace: true })
        };
    }

    const backRoute = '/backoffice/system/config/social-providers';

    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{mode === "CREATE" ? "Create Provider" : `Edit Provider: ${(itemQuery.data as SocialProviderEntity)?.provider}`} </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/system/config/social-providers">Social Providers</BreadcrumbItem>
                                {
                                    mode === "CREATE"
                                        ? <BreadcrumbItem>Create</BreadcrumbItem>
                                        : <BreadcrumbItem>Edit</BreadcrumbItem>
                                }
                            </Breadcrumbs>
                        </div>

                        <div className="flex flex-row gap-3">
                            {(
                                <Dropdown>
                                    <DropdownTrigger>
                                        <Button isIconOnly>
                                            <span className="text-lg font-bold">...</span>
                                        </Button>
                                    </DropdownTrigger>
                                    <DropdownMenu aria-label="Actions">
                                        {mode === "EDIT" ? DeleteDropdownItem({
                                            entityName: entityName,
                                            id: id,
                                            backRoute: backRoute,
                                            deleteFn: () => fetcher("/api/config/social-providers/:id", {
                                                method: "DELETE",
                                                params: { id: id! },
                                            })
                                        }) : null}

                                        <DropdownItem
                                            key="cancel"
                                            onPress={() => navigate(backRoute)}
                                        >
                                            Cancel
                                        </DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            )}

                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save
                            </Button>
                        </div>

                    </div>
                    <SocialProviderForm form={form} mode={mode} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    );
}
