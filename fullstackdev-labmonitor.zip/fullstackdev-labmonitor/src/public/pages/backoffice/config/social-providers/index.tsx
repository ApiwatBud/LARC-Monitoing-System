import { BreadcrumbItem, Breadcrumbs, Button, Chip, Tooltip } from "@heroui/react";
import { useNavigate } from "react-router";
import { client } from "../../../../../client";
import { PageContainer } from "../../../../components/PageContainer";
import { SocialProviderEntity } from "../../../../../modules/config/domains/entities/social_provider.entity";
import { EntityColumn, GenericDataTable } from "../../../../components/Datatables/zzbyDatatable";
import { FilterFormDefs } from "../../../../components/Datatables/filterForm";
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from "../../../../../common/types";

export default function SocialProviderIndex() {
    const navigate = useNavigate();

    const providerColDefs: EntityColumn<SocialProviderEntity>[] = [
        {
            key: "provider",
            header: "Provider",
            meta: { isTitle: true },
            cell: (info) => <span className="font-bold text-sm capitalize">{info.getValue()}</span>,
        },
        {
            key: "name",
            header: "Name",
            cell: (info) => <span className="text-sm">{info.getValue()}</span>,
        },
        {
            key: "clientId",
            header: "Client ID",
            cell: (info) => <span className="text-sm text-default-400 font-mono">{info.getValue()}</span>,
        },
        {
            key: "isActive",
            header: "Status",
            cell: (info) => (
                <Chip className="capitalize" color={info.getValue() ? "success" : "danger"} size="sm" variant="flat">
                    {info.getValue() ? "Active" : "Inactive"}
                </Chip>
            ),
        },
    ];

    const defaultFilter: TPaginateQueryForm<SocialProviderEntity> = {
        page: 1,
        limit: 20,
        withAudit: true,
        filter: {
            keyword: {
                key: 'provider|name' as keyof SocialProviderEntity,
                operator: 'ilike' as TFilterOperator,
                value: ''
            },
        },
        sort: [{ key: 'id', order: 'asc' as TSortOrder }]
    };

    const filterForm: FilterFormDefs[] = [
        {
            widget: 'text',
            label: 'Search Provider',
            name: 'keyword'
        }
    ];

    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Social Providers</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/system/config/social-providers">Social Providers</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <Button color="primary" onPress={() => navigate('/backoffice/system/config/social-providers/create')}>
                    Add Provider
                </Button>
            </div>

            <GenericDataTable<SocialProviderEntity>
                queryKey={['social-providers']}
                queryFn={client.api.config["social-providers"].filter.post}
                viewRoute="/backoffice/system/config/social-providers/:id"
                colDefs={providerColDefs}
                defaultFilter={defaultFilter}
                filterFormDefs={filterForm}
            />
        </PageContainer>
    );
}
