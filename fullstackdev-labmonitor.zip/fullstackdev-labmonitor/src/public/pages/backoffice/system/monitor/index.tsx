import { BreadcrumbItem, Breadcrumbs, Card, CardBody, CardHeader, Progress, Spinner } from '@heroui/react'
import { useQuery } from '@tanstack/react-query'
import { client } from '../../../../../client'
import { FiCpu, FiHardDrive, FiServer, FiActivity, FiClock } from 'react-icons/fi'
import { motion } from 'framer-motion'
import { PageContainer } from '../../../../components/PageContainer'

export default function SystemMonitorIndex() {
    const { data: status, isLoading, isError } = useQuery({
        queryKey: ['system-status'],
        queryFn: async () => {
            const res = await client.api.system.status.get();
            if (res.error) throw new Error(res.error.value as string);
            return res.data;
        },
        refetchInterval: 5000 // Refresh every 5 seconds
    })

    if (isLoading) return (
        <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
            <Spinner size="lg" color="primary" />
            <p className="text-gray-500 animate-pulse">Gathering system metrics...</p>
        </div>
    )

    if (isError || !status) return (
        <div className="p-8 text-center bg-red-50 rounded-xl border border-red-100">
            <FiActivity className="mx-auto text-4xl text-red-400 mb-4" />
            <h3 className="text-lg font-bold text-red-800">Connection Failed</h3>
            <p className="text-red-600">Could not retrieve system status. Please check your permissions.</p>
        </div>
    )

    const formatBytes = (bytes: number) => {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let i = 0;
        while (bytes >= 1024 && i < units.length - 1) {
            bytes /= 1024;
            i++;
        }
        return `${bytes.toFixed(2)} ${units[i]}`;
    };

    const formatUptime = (seconds: number) => {
        const d = Math.floor(seconds / (3600 * 24));
        const h = Math.floor((seconds % (3600 * 24)) / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = Math.floor(seconds % 60);

        const parts = [];
        if (d > 0) parts.push(`${d}d`);
        if (h > 0) parts.push(`${h}h`);
        if (m > 0) parts.push(`${m}m`);
        if (s > 0) parts.push(`${s}s`);
        return parts.join(' ') || '0s';
    };

    return (
        <PageContainer className="space-y-6">
            <div className="mb-3">
                <h1 className="text-2xl font-bold text-gray-900 tracking-tight">System Monitor</h1>
                <Breadcrumbs size="sm" className="mt-1.5">
                    <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                    <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                    <BreadcrumbItem>Monitor</BreadcrumbItem>
                </Breadcrumbs>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* CPU Status */}
                <Card shadow="sm" className="border-none bg-gradient-to-br from-blue-50 to-white">
                    <CardHeader className="flex gap-3">
                        <div className="p-2 bg-blue-500 rounded-lg text-white">
                            <FiCpu size={20} />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-sm text-gray-500 uppercase font-bold tracking-wider">CPU CORES</p>
                            <p className="text-xl font-black text-blue-900">{status.cpu.cores} Cores</p>
                        </div>
                    </CardHeader>
                    <CardBody>
                        <p className="text-xs text-blue-700 truncate mb-2">{status.cpu.model}</p>
                        <div className="flex justify-between text-xs mb-1">
                            <span>Load Detail</span>
                            <span>{status.cpu.loadAvg.map((l: any) => l.toFixed(2)).join(' | ')}</span>
                        </div>
                    </CardBody>
                </Card>

                {/* Memory Status */}
                <Card shadow="sm" className="border-none bg-gradient-to-br from-emerald-50 to-white">
                    <CardHeader className="flex gap-3">
                        <div className="p-2 bg-emerald-500 rounded-lg text-white">
                            <FiHardDrive size={20} />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-sm text-gray-500 uppercase font-bold tracking-wider">MEMORY USAGE</p>
                            <p className="text-xl font-black text-emerald-900">{status.memory.percentage}%</p>
                        </div>
                    </CardHeader>
                    <CardBody>
                        <Progress
                            size="sm"
                            aria-label="Memory usage"
                            value={status.memory.percentage}
                            color={status.memory.percentage > 80 ? "danger" : (status.memory.percentage > 60 ? "warning" : "success")}
                            className="bg-emerald-100"
                        />
                        <div className="flex justify-between text-[10px] mt-2 text-emerald-700 font-medium">
                            <span>Used: {formatBytes(status.memory.used)}</span>
                            <span>Total: {formatBytes(status.memory.total)}</span>
                        </div>
                    </CardBody>
                </Card>

                {/* OS Status */}
                <Card shadow="sm" className="border-none bg-gradient-to-br from-purple-50 to-white">
                    <CardHeader className="flex gap-3">
                        <div className="p-2 bg-purple-500 rounded-lg text-white">
                            <FiServer size={20} />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-sm text-gray-500 uppercase font-bold tracking-wider">PLATFORM</p>
                            <p className="text-xl font-black text-purple-900 capitalize">{status.os.platform}</p>
                        </div>
                    </CardHeader>
                    <CardBody>
                        <p className="text-xs text-purple-700 font-medium">Hostname: {status.os.hostname}</p>
                        <p className="text-[10px] text-purple-500 mt-1">Release: {status.os.release}</p>
                    </CardBody>
                </Card>

                {/* Uptime Status */}
                <Card shadow="sm" className="border-none bg-gradient-to-br from-orange-50 to-white">
                    <CardHeader className="flex gap-3">
                        <div className="p-2 bg-orange-500 rounded-lg text-white">
                            <FiClock size={20} />
                        </div>
                        <div className="flex flex-col">
                            <p className="text-sm text-gray-500 uppercase font-bold tracking-wider">SYSTEM UPTIME</p>
                            <p className="text-xl font-black text-orange-900">{formatUptime(status.os.uptime)}</p>
                        </div>
                    </CardHeader>
                    <CardBody>
                        <div className="flex items-center gap-2 text-xs text-orange-700 font-medium">
                            <FiActivity size={12} className="animate-pulse" />
                            <span>Server is Healthy</span>
                        </div>
                        <p className="text-[10px] text-orange-500 mt-1">Last Update: {new Date(status.timestamp).toLocaleTimeString()}</p>
                    </CardBody>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Process Details */}
                <Card className="lg:col-span-1 shadow-md border-none">
                    <CardHeader className="bg-gray-50/50 border-b border-gray-100 py-3">
                        <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
                            <FiActivity className="text-blue-500" />
                            Process Context
                        </h3>
                    </CardHeader>
                    <CardBody className="p-0">
                        <div className="divide-y divide-gray-100">
                            {[
                                { label: 'Node/Bun Version', value: status.process.version },
                                { label: 'Process Uptime', value: formatUptime(status.process.uptime) },
                                { label: 'RSS (Memory)', value: formatBytes(status.process.memoryUsage.rss) },
                                { label: 'Heap Total', value: formatBytes(status.process.memoryUsage.heapTotal) },
                                { label: 'Heap Used', value: formatBytes(status.process.memoryUsage.heapUsed) },
                                { label: 'Architecture', value: status.os.arch },
                            ].map((item, i) => (
                                <div key={i} className="flex justify-between items-center px-4 py-3">
                                    <span className="text-xs text-gray-500">{item.label}</span>
                                    <span className="text-xs font-mono font-bold text-gray-700">{item.value}</span>
                                </div>
                            ))}
                        </div>
                    </CardBody>
                </Card>

                {/* System Load / Environment */}
                <Card className="lg:col-span-2 shadow-md border-none">
                    <CardHeader className="bg-gray-50/50 border-b border-gray-100 py-3">
                        <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
                            <FiServer className="text-purple-500" />
                            Infrastructure Insights
                        </h3>
                    </CardHeader>
                    <CardBody className="flex flex-col justify-center items-center p-8 gap-6">
                        <div className="text-center space-y-2">
                            <div className="relative inline-block">
                                <FiActivity size={64} className="text-blue-100" />
                                <motion.div
                                    className="absolute inset-0 flex items-center justify-center"
                                    animate={{ scale: [1, 1.2, 1] }}
                                    transition={{ duration: 2, repeat: Infinity }}
                                >
                                    <FiActivity size={32} className="text-blue-500" />
                                </motion.div>
                            </div>
                            <h2 className="text-xl font-bold text-gray-800">System is Responding</h2>
                            <p className="text-sm text-gray-500 max-w-sm">
                                All core modules are operational. The system is currently running on <span className="font-bold text-gray-700">{status.os.hostname}</span> with optimal resource allocation.
                            </p>
                        </div>

                        <div className="w-full max-w-md space-y-4">
                            <div className="space-y-1">
                                <div className="flex justify-between text-xs font-bold text-gray-600">
                                    <span>REAL-TIME PERFORMANCE</span>
                                    <span>STABLE</span>
                                </div>
                                <div className="h-1 bg-blue-50 rounded-full overflow-hidden">
                                    <motion.div
                                        className="h-full bg-blue-500"
                                        animate={{ width: ["10%", "40%", "25%", "60%", "30%"] }}
                                        transition={{ duration: 10, repeat: Infinity }}
                                    />
                                </div>
                            </div>
                        </div>
                    </CardBody>
                </Card>
            </div>
        </PageContainer>
    )
}
