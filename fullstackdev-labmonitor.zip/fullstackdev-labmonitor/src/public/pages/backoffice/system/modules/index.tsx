import { useQuery } from "@tanstack/react-query";
import { client } from "../../../../../client";
import { PageContainer } from "../../../../components/PageContainer";
import { createColumnHelper, getCoreRowModel, useReactTable, getSortedRowModel, SortingState } from "@tanstack/react-table";
import { ZZBYDatatable } from "../../../../components/Datatables/zzbyDatatable";
import { useState, useMemo } from "react";
import { Chip } from "@heroui/react";

interface ModuleEntity {
    id: number;
    key: string;
    name: string;
    description: string;
    icon: string;
    is_active: boolean;
    createdAt: Date;
    updatedAt: Date;
}

const columnHelper = createColumnHelper<ModuleEntity>();

export default function ModuleIndex() {
    const [sorting, setSorting] = useState<SortingState>([]);

    const query = useQuery({
        queryKey: ["modules", "active"],
        queryFn: async () => {
            const res = await client.api.configs.modules.active.get();
            if (res.error) throw res.error;
            return res.data;
        }
    });

    const columns = useMemo(() => [
        columnHelper.accessor("key", {
            header: "Key",
            cell: info => info.getValue(),
        }),
        columnHelper.accessor("name", {
            header: "Name",
            cell: info => <span className="font-semibold">{info.getValue()}</span>,
        }),
        columnHelper.accessor("description", {
            header: "Description",
            cell: info => info.getValue(),
        }),
        columnHelper.accessor("icon", {
            header: "Icon",
            cell: info => info.getValue(),
        }),
        columnHelper.accessor("is_active", {
            header: "Status",
            cell: info => (
                <Chip size="sm" color={info.getValue() ? "success" : "danger"} variant="flat">
                    {info.getValue() ? "Active" : "Inactive"}
                </Chip>
            ),
        }),
    ], []);

    const table = useReactTable({
        data: query.data || [],
        columns,
        state: {
            sorting,
        },
        onSortingChange: setSorting,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
    });

    return (
        <PageContainer>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900">System Modules</h1>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                <ZZBYDatatable
                    table={table}
                    isFetching={query.isLoading}
                    handleSort={(id) => {
                        const col = table.getColumn(id);
                        col?.toggleSorting();
                    }}
                />
            </div>
        </PageContainer>
    );
}
