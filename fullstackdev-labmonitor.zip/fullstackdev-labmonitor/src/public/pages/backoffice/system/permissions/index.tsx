import { BreadcrumbItem, Breadcrumbs, Button, Chip } from '@heroui/react'
import { useNavigate } from 'react-router'
import { client } from '../../../../../client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../common/types'
import { PermissionEntity } from "../../../../../modules/core/domains/entities/permission.entity"
import { FilterFormDefs } from '../../../../components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../components/PageContainer'

export default function PermissionIndex() {

    const permissionColDefs: EntityColumn<PermissionEntity>[] = [
        {
            key: "name",
            header: "Name",
            meta: {
                isTitle: true
            },
            cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
        },
        {
            key: "description",
            header: "Description",
            cell: (info) => <span className="text-gray-600">{info.getValue() || "-"}</span>,
        },
        {
            key: "createdAt",
            header: "Created At",
            cell: (info) => <span className="text-gray-500">{new Date(info.getValue() as string).toLocaleDateString()}</span>,
        },
        {
            key: "creatorName",
            header: "Created By",
            cell: (info) => <span className="text-gray-500 font-mono text-tiny">{info.getValue() || "System"}</span>,
        },
        {
            key: "updatedAt",
            header: "Updated At",
            cell: (info) => <span className="text-gray-500">{new Date(info.getValue() as string).toLocaleDateString()}</span>,
        },
        {
            key: "updatedBy",
            header: "Updated By",
            cell: (info) => <span className="text-gray-500 font-mono text-tiny">{info.getValue() || "System"}</span>,
        },
    ]

    const permissionDefaultFilter: TPaginateQueryForm<PermissionEntity> = {
        page: 1,
        limit: 20,
        filter: {
            name: {
                key: 'name',
                operator: 'like' as TFilterOperator,
                value: ''
            },
        },
        withAudit: true,
        sort: [{ key: 'name', order: 'asc' as TSortOrder }]
    }

    const permissionFilterForm: FilterFormDefs[] = [
        {
            widget: 'text',
            label: 'Name',
            name: 'name'
        }
    ]

    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Permissions Management</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/system/permissions">Permissions</BreadcrumbItem>
                    </Breadcrumbs>

                </div>
            </div>
            <GenericDataTable<PermissionEntity>
                queryKey={['permissions']}
                queryFn={client.api.permissions.filter.post}
                viewRoute="/backoffice/system/permissions/:name"
                colDefs={permissionColDefs}
                defaultFilter={permissionDefaultFilter}
                filterFormDefs={permissionFilterForm}
            />
        </PageContainer>
    )
}
