import { addToast, BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Tab, Tabs } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router";
import { client, fetcher } from "../../../../../client";
import { PermissionCreateDto, PermissionUpdateDto } from "../../../../../modules/core/applications/dtos/permission.dto";
import { ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../components/ZZBYForm";
import { DeleteDropdownItem } from "../../../../components/Datatables/deleteDropdownItem";
import { PageContainer } from "../../../../components/PageContainer";


export interface PermissionFormProps {
    form: any;
    mode: "CREATE" | "EDIT";
}
export function PermissionForm({ form, mode }: PermissionFormProps) {

    return (
        <Tabs className="pt-3">
            <Tab key={'basic'} title="Basic Information" >
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2">
                        <Card>
                            <CardHeader>
                                Permission Details
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFormFieldInput
                                    name="name"
                                    form={form}
                                    label="Permission Name"
                                    placeholder="Enter permission name"
                                    isReadOnly={true}
                                />

                                <ZZBYFormFieldInput
                                    name="description"
                                    form={form}
                                    label="Description"
                                    placeholder="Enter description"
                                    isReadOnly={true}
                                />

                            </CardBody>
                        </Card>
                    </div>
                </div>
            </Tab>
        </Tabs >
    )
}


export default function PermissionEdit() {
    const routeParams = useParams();
    const navigate = useNavigate();

    const name = routeParams.name as string;
    const mode: "EDIT" | "CREATE" = name ? "EDIT" : "CREATE"
    let formProps: ZZBYFormGeneratorWrapperProps<any>
    let queryKey = mode === "EDIT" ? ['permission', name] : ['permissions']
    let entityName = "Permission"
    let validatorsOnSubmit = mode === "EDIT" ? PermissionUpdateDto : PermissionCreateDto
    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => mode === "EDIT" ? client.api.permissions({ name: name }).get() : null,
        enabled: mode === "EDIT" && !!name
    })

    if (mode === "EDIT") {
        if (itemQuery.isLoading) {
            return <div className="p-3">Loading...</div>
        }

        if (itemQuery.error) {
            throw itemQuery.error
        }

        if (!itemQuery.data?.data) {
            return (
                <div className="p-3">
                    <div className="mb-4">Permission not found</div>
                    <Button color="primary" onPress={() => window.history.back()}>
                        Back
                    </Button>
                </div>
            )
        }

        const permissionData = itemQuery.data.data as any;
        formProps = {
            mode: mode,
            defaultValues: {
                name: permissionData.name,
                description: permissionData.description,
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (returnedName: string) => navigate(`/backoffice/system/permissions/${returnedName}`),
            primaryKey: 'name'
        }

    } else {

        formProps = {
            mode: mode,
            defaultValues: {
                name: '',
                description: '',
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            entityName: entityName,
            queryKey: queryKey,
            primaryKey: 'name',
            redirectEdit: (returnedName: string) => navigate(`/backoffice/system/permissions/${returnedName}`, { replace: true })
        }
    }

    const backRoute = '/backoffice/system/permissions';
    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Permission View : {name} </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/system/permissions">Permissions</BreadcrumbItem>
                                <BreadcrumbItem href={`/backoffice/system/permissions/${name}`}>Permission View : {name}</BreadcrumbItem>
                            </Breadcrumbs>

                        </div>

                        <div className="flex flex-row gap-3">
                            <Button color="default" variant="flat" onPress={() => navigate(backRoute)}>
                                Back
                            </Button>
                        </div>

                    </div>
                    <PermissionForm form={form} mode={mode} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )

}
