import { Route } from "react-router";
import UserIndex from "./users";
import UserEdit from "./users/edit";
import RoleIndex from "./roles";
import RoleEdit from "./roles/edit";
import PermissionIndex from "./permissions";
import PermissionEdit from "./permissions/edit";
import SystemIndex from "./SystemIndex";
import SystemMonitorIndex from "./monitor";
import ModuleIndex from "./modules";
import SMTPConfig from "./config/smtp";
import SocialProviderIndex from "../config/social-providers";
import SocialProviderEdit from "../config/social-providers/edit";

export default function SystemRoutes() {


    return (
        <Route path="system">
            <Route index element={<SystemIndex />} />
            <Route path="users" element={<UserIndex />} />
            <Route path="users/:id" element={<UserEdit />} />
            <Route path="users/create" element={<UserEdit />} />

            <Route path="roles" element={<RoleIndex />} />
            <Route path="roles/:id" element={<RoleEdit />} />
            <Route path="roles/create" element={<RoleEdit />} />
            <Route path="permissions" element={<PermissionIndex />} />
            <Route path="permissions/:name" element={<PermissionEdit />} />
            <Route path="modules" element={<ModuleIndex />} />
            <Route path="monitor" element={<SystemMonitorIndex />} />

            <Route path="config">
                <Route path="smtp" element={<SMTPConfig />} />
                <Route path="modules" element={<ModuleIndex />} />
                <Route path="social-providers" element={<SocialProviderIndex />} />
                <Route path="social-providers/create" element={<SocialProviderEdit />} />
                <Route path="social-providers/:id" element={<SocialProviderEdit />} />
            </Route>
        </Route>
    )
}