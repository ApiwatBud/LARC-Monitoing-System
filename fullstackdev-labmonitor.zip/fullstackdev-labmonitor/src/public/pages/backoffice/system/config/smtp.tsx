import { addToast, BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Checkbox, Input } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { client, fetcher } from "../../../../../client";
import { SMTPUpdateDto } from "../../../../../modules/config/applications/dtos/smtp.dto";
import { ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../components/ZZBYForm";
import { PageContainer } from "../../../../components/PageContainer";

export default function SMTPConfig() {
    const queryKey = ['smtp-config']
    const entityName = "SMTP Configuration"
    const [testEmail, setTestEmail] = useState("");
    const [isTesting, setIsTesting] = useState(false);

    const smtpQuery = useQuery({
        queryKey: queryKey,
        queryFn: async () => {
            const res = await client.api.configs.smtp.get();
            return res.data;
        },
    })

    const handleSendTest = async () => {
        if (!testEmail) {
            addToast({
                title: "Error",
                description: "Please enter a test email address",
                color: "danger"
            });
            return;
        }

        setIsTesting(true);
        try {
            const res = await fetcher("/api/configs/smtp/test", {
                method: "POST",
                body: { to: testEmail },
                headers: {}
            });

            if (res.status === 200) {
                addToast({
                    title: "Success",
                    description: "Test email sent successfully!",
                    color: "success"
                });
            } else {
                throw new Error(res.error?.value?.message || "Failed to send test email");
            }
        } catch (error: any) {
            addToast({
                title: "Error",
                description: error.message,
                color: "danger"
            });
        } finally {
            setIsTesting(false);
        }
    };

    if (smtpQuery.isLoading) {
        return <div className="p-3">Loading...</div>
    }

    const defaultValues = smtpQuery.data ? {
        ...smtpQuery.data,
        auth: {
            ...smtpQuery.data.auth,
            password_confirmation: smtpQuery.data.auth?.pass
        }
    } : {
        host: "",
        port: 587,
        secure: false,
        auth: {
            user: "",
            pass: "",
            password_confirmation: ""
        }
    };

    const formProps: ZZBYFormGeneratorWrapperProps<any> = {
        mode: "EDIT",
        defaultValues: defaultValues,
        validators: {
            onSubmit: SMTPUpdateDto
        },
        apiSubmit: (value: any) => fetcher("/api/configs/smtp", {
            method: "POST",
            body: value,
            headers: {}
        }),
        entityName: entityName,
        queryKey: queryKey,
    }

    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form: any) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">SMTP Configuration</h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem>Configuration</BreadcrumbItem>
                                <BreadcrumbItem>SMTP Settings</BreadcrumbItem>
                            </Breadcrumbs>
                        </div>

                        <div className="flex flex-row gap-3">
                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save Settings
                            </Button>
                        </div>
                    </div>

                    <div className='grid grid-cols-1 gap-4 max-w-2xl'>
                        <Card shadow="sm">
                            <CardHeader className="font-bold px-4 pt-4 text-gray-800">
                                Server Settings
                            </CardHeader>
                            <CardBody className="flex flex-col gap-4 p-4">
                                <ZZBYFormFieldInput
                                    name="host"
                                    form={form}
                                    label="SMTP Host"
                                    placeholder="smtp.example.com"
                                />

                                <ZZBYFormFieldInput
                                    name="port"
                                    form={form}
                                    label="SMTP Port"
                                    placeholder="587"
                                    type="number"
                                />

                                <form.Field
                                    name="secure"
                                    children={(field: any) => (
                                        <Checkbox
                                            isSelected={field.state.value}
                                            onValueChange={field.handleChange}
                                        >
                                            Use Secure Connection (SSL/TLS)
                                        </Checkbox>
                                    )}
                                />
                            </CardBody>
                        </Card>

                        <Card shadow="sm">
                            <CardHeader className="font-bold px-4 pt-4 text-gray-800">
                                Authentication
                            </CardHeader>
                            <CardBody className="flex flex-col gap-4 p-4">
                                <ZZBYFormFieldInput
                                    name="auth.user"
                                    form={form}
                                    label="Username / Email"
                                    placeholder="user@example.com"
                                />

                                <ZZBYFormFieldInput
                                    name="auth.pass"
                                    form={form}
                                    label="Password"
                                    placeholder="SMTP Password"
                                    type="password"
                                />
                                <ZZBYFormFieldInput
                                    name="auth.password_confirmation"
                                    form={form}
                                    label="Confirm Password"
                                    placeholder="Confirm SMTP Password"
                                    type="password"
                                />
                            </CardBody>
                        </Card>

                        <Card shadow="sm" className="border-t-2 border-primary/20">
                            <CardHeader className="font-bold px-4 pt-4 text-gray-800">
                                Test Connection
                            </CardHeader>
                            <CardBody className="flex flex-col gap-4 p-4">
                                <p className="text-sm text-gray-500">
                                    Send a test email to verify your SMTP settings. Save your changes first.
                                </p>
                                <div className="flex gap-3">
                                    <Input
                                        label="Receiver Email"
                                        placeholder="test@example.com"
                                        size="sm"
                                        value={testEmail}
                                        onValueChange={setTestEmail}
                                    />
                                    <Button
                                        color="secondary"
                                        variant="flat"
                                        className="h-auto px-6"
                                        onPress={handleSendTest}
                                        isLoading={isTesting}
                                    >
                                        Send Test
                                    </Button>
                                </div>
                            </CardBody>
                        </Card>
                    </div>
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )
}

