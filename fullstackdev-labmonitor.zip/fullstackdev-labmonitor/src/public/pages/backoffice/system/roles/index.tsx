import { BreadcrumbItem, Breadcrumbs, Button } from '@heroui/react'
import { useNavigate } from 'react-router'
import { client } from '../../../../../client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../common/types'
import { RoleEntity } from "../../../../../modules/core/domains/entities/role.entity"
import { FilterFormDefs } from '../../../../components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../components/PageContainer'

export default function RoleIndex() {

    const roleColDefs: EntityColumn<RoleEntity>[] = [
        {
            key: "id",
            header: "ID",
            cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
        },
        {
            key: "name",
            header: "Name",
            meta: {
                isTitle: true
            },
            cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
        },
        {
            key: "description",
            header: "Description",
            cell: (info) => <span className="text-gray-600">{info.getValue()}</span>,
        },
        {
            key: "createdAt",
            header: "Created At",
            cell: (info) => <span className="text-gray-500">{(info.getValue() as Date).toLocaleDateString()}</span>,
        },
        {
            key: "creatorName",
            header: "Created By",
            cell: (info) => <span className="text-gray-500 font-mono text-tiny">{info.getValue() || "System"}</span>,
        },
        {
            key: "updatedAt",
            header: "Updated At",
            cell: (info) => <span className="text-gray-500">{(info.getValue() as Date).toLocaleDateString()}</span>,
        },
        {
            key: "updaterName",
            header: "Updated By",
            cell: (info) => <span className="text-gray-500 font-mono text-tiny">{info.getValue() || "System"}</span>,
        },
    ]

    const roleDefaultFilter: TPaginateQueryForm<RoleEntity> = {
        page: 1,
        limit: 20,
        filter: {
            name: {
                key: 'name',
                operator: 'like' as TFilterOperator,
                value: ''
            },
        },
        withAudit: true,
        sort: [{ key: 'id', order: 'asc' as TSortOrder }]
    }

    const roleFilterForm: FilterFormDefs[] = [
        {
            widget: 'text',
            label: 'Role Name',
            name: 'name'
        }
    ]

    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Roles Management</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/system/roles">Roles</BreadcrumbItem>
                    </Breadcrumbs>

                </div>
                <Button color="default" onPress={() => navigate('/backoffice/system/roles/create')}>
                    Add Role
                </Button>
            </div>
            <GenericDataTable<RoleEntity>
                queryKey={['roles']}
                queryFn={client.api.roles.filter.post}
                viewRoute="/backoffice/system/roles/:id"
                colDefs={roleColDefs}
                defaultFilter={roleDefaultFilter}
                filterFormDefs={roleFilterForm}
            />
        </PageContainer>
    )
}
