import { addToast, BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Checkbox, CheckboxGroup, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Tab, Tabs } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router";
import { client, fetcher } from "../../../../../client";
import { RoleCreateDto, RoleUpdateDto } from "../../../../../modules/core/applications/dtos/role.dto";
import { RoleWithPermissionsCreateDto, RoleWithPermissionsUpdateDto } from "../../../../../modules/core/applications/dtos/role.aggs.dto";
import { ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../components/ZZBYForm";
import { DeleteDropdownItem } from "../../../../components/Datatables/deleteDropdownItem";
import { PageContainer } from "../../../../components/PageContainer";
import { PermissionResponseDto } from "../../../../../modules/core/applications/dtos/permission.dto";
import { ModuleResponseDto } from "../../../../../modules/config/applications/dtos/module.dto";


export interface RoleFormProps {
    form: any;
    mode: "CREATE" | "EDIT";
}
export function RoleForm({ form, mode }: RoleFormProps) {

    const permissionQuery = useQuery({
        queryKey: ['permissions'],
        queryFn: () => client.api.permissions.get().then((r: any) => {
            // group by entity
            if (!r.data) {
                return {}
            }
            const grouped: Record<string, PermissionResponseDto[]> = r.data.reduce((acc: Record<string, PermissionResponseDto[]>, permission: PermissionResponseDto) => {
                const entity = permission.name.split(':')[0]
                if (!acc[entity]) {
                    acc[entity] = []
                }
                acc[entity].push(permission)
                return acc
            }, {} as Record<string, PermissionResponseDto[]>)
            return grouped
        }),
    })

    const moduleQuery = useQuery({
        queryKey: ['modules'],
        queryFn: () => client.api.configs.modules.active.get().then((r: any) => r.data || [])
    })


    return (
        <Tabs className="pt-3">
            <Tab key={'basic'} title="Basic Information" >
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2">
                        <Card>
                            <CardHeader>
                                Role Details
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFormFieldInput
                                    name="name"
                                    form={form}
                                    label="Role Name"
                                    placeholder="Enter role name"
                                />

                                <ZZBYFormFieldInput
                                    name="description"
                                    form={form}
                                    label="Description"
                                    placeholder="Enter description"
                                />

                            </CardBody>
                        </Card>
                    </div>
                </div>
            </Tab>
            <Tab key={'permissions'} title="Permissions" >
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2">
                        <Card>
                            <CardHeader>
                                Permissions
                            </CardHeader>
                            <CardBody>
                                <form.Field name="permissions">
                                    {(field: any) => {
                                        const currentPermissions: string[] = field.state.value || [];
                                        return (
                                            <CheckboxGroup
                                                label="Select Permissions"
                                                value={currentPermissions}
                                                onValueChange={(values) => field.handleChange(values)}
                                            >
                                                {permissionQuery.data && Object.keys(permissionQuery.data).map((entity) => (
                                                    <div key={entity} className="mb-4">
                                                        <h3 className="font-bold text-small text-default-500 mb-2 uppercase">{entity}</h3>
                                                        <div className="flex flex-wrap gap-4 ml-2">
                                                            {permissionQuery.data[entity].map((permission: PermissionResponseDto) => (
                                                                <Checkbox
                                                                    key={permission.name}
                                                                    value={permission.name}
                                                                    size="sm"
                                                                >
                                                                    {permission.name}
                                                                </Checkbox>
                                                            ))}
                                                        </div>
                                                    </div>
                                                ))}
                                            </CheckboxGroup>
                                        )
                                    }}
                                </form.Field>
                            </CardBody>
                        </Card>
                    </div>
                </div>
            </Tab>
            <Tab key={'modules'} title="Module Permissions" >
                <div className='grid grid-cols-1 gap-3'>
                    <Card>
                        <CardHeader>
                            Module Access
                        </CardHeader>
                        <CardBody>
                            <form.Field name="modules">
                                {(field: any) => {
                                    const currentModules: string[] = field.state.value || [];
                                    return (
                                        <CheckboxGroup
                                            label="Select Accessible Modules"
                                            value={currentModules}
                                            onValueChange={(values) => field.handleChange(values)}
                                            orientation="horizontal"
                                        >
                                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full">
                                                {moduleQuery.data?.map((module: ModuleResponseDto) => (
                                                    <div key={module.key} className="border p-4 rounded-lg flex items-center gap-3 hover:bg-default-100 transition-colors">
                                                        <Checkbox
                                                            value={module.key}
                                                            size="lg"
                                                            name={module.key}
                                                        >
                                                            <div className="flex flex-col">
                                                                <span className="font-semibold">{module.name}</span>
                                                                <span className="text-tiny text-default-500">{module.description || "No description"}</span>
                                                            </div>
                                                        </Checkbox>
                                                    </div>
                                                ))}
                                            </div>
                                        </CheckboxGroup>
                                    )
                                }}
                            </form.Field>
                        </CardBody>
                    </Card>
                </div>
            </Tab>
        </Tabs >
    )
}


export default function RoleEdit() {
    const routeParams = useParams();
    const navigate = useNavigate();

    const id = routeParams.id as string;
    const mode: "EDIT" | "CREATE" = id ? "EDIT" : "CREATE"
    let formProps: ZZBYFormGeneratorWrapperProps<any>
    let queryKey = mode === "EDIT" ? ['role', id] : ['roles']
    let entityName = "Role"
    let validatorsOnSubmit = mode === "EDIT" ? RoleWithPermissionsUpdateDto : RoleWithPermissionsCreateDto
    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => mode === "EDIT" ? client.api.roles({ id: id }).get() : null,
        enabled: mode === "EDIT" && !!id
    })

    if (mode === "EDIT") {
        if (itemQuery.isLoading) {
            return <div className="p-3">Loading...</div>
        }

        if (itemQuery.error) {
            throw itemQuery.error
        }

        if (!itemQuery.data?.data) {
            return (
                <div className="p-3">
                    <div className="mb-4">Role not found</div>
                    <Button color="primary" onPress={() => window.history.back()}>
                        Back
                    </Button>
                </div>
            )
        }

        const roleData = itemQuery.data.data as any;
        formProps = {
            mode: mode,
            defaultValues: {
                name: roleData.name,
                description: roleData.description,
                permissions: roleData.permissions || [],
                modules: roleData.modules || [],
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/roles/:id", {
                method: "PUT",
                body: value as any,
                params: { id: id! },
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/system/roles/${id}`)
        }

    } else {

        formProps = {
            mode: mode,
            defaultValues: {
                name: '',
                description: '',
                permissions: [],
                modules: [],
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/roles", {
                method: "POST",
                body: value as any,
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/system/roles/${id}`, { replace: true })
        }
    }

    const backRoute = '/backoffice/system/roles';
    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{mode === "CREATE" ? "Create Role" : `Role Edit : ${id}`} </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/system/roles">Roles</BreadcrumbItem>
                                {
                                    mode === "CREATE"
                                        ? <BreadcrumbItem>Create Role</BreadcrumbItem>
                                        : <BreadcrumbItem href={`/backoffice/system/roles/${id}`}>Role Edit : {id}</BreadcrumbItem>
                                }
                            </Breadcrumbs>

                        </div>

                        <div className="flex flex-row gap-3">
                            {(
                                <Dropdown>
                                    <DropdownTrigger>
                                        <Button isIconOnly variant="flat">
                                            <span className="text-lg font-bold">...</span>
                                        </Button>
                                    </DropdownTrigger>
                                    <DropdownMenu aria-label="Role Actions">
                                        {mode == "EDIT" ? (
                                            DeleteDropdownItem({
                                                entityName: entityName,
                                                id: id!,
                                                backRoute: backRoute,
                                                deleteFn: () => fetcher("/api/roles/:id", {
                                                    method: "DELETE",
                                                    params: { id: id! },
                                                    headers: {},
                                                    body: {}
                                                })
                                            })
                                        ) : null}

                                        <DropdownItem
                                            key="cancel"
                                            onPress={() => navigate(backRoute)}
                                        >
                                            Cancel
                                        </DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            )}

                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save
                            </Button>
                        </div>

                    </div>
                    <RoleForm form={form} mode={mode} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )

}
