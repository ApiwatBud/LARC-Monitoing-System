import { Card, CardBody, CardHeader, Skeleton } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { client } from "../../../../client";
import { FiUsers, FiShield, FiKey } from "react-icons/fi";
import { PageContainer } from "../../../components/PageContainer";
import ConfigPermissions from "../../../../modules/config/domains/permissions/config.permissions";
import { CorePermissions } from "../../../../modules/core/domains/permissions";
import { useCurrentUser } from "../../../providers/CurrentUserProvider";

export default function SystemIndex() {
    const { checkPermission } = useCurrentUser();


    const userCountQuery = useQuery({
        queryKey: ["users", "count"],
        queryFn: async () => {
            //check permission
            if (!checkPermission(CorePermissions.UsersRead)) return 0;

            const res = await client.api.users.filter.post({
                page: 1,
                limit: 1,
                filter: [],
                sort: [],
                withAudit: false,
            });
            if (res.error) throw res.error;
            return res.data?.total || 0;
        },
    });

    const roleCountQuery = useQuery({
        queryKey: ["roles", "count"],
        queryFn: async () => {
            //check permission
            if (!checkPermission(CorePermissions.RolesRead)) return 0;

            const res = await client.api.roles.filter.post({
                page: 1,
                limit: 1,
                filter: [],
                sort: [],
                withAudit: false,
            });
            if (res.error) throw res.error;
            return res.data?.total || 0;
        },
    });

    const permissionCountQuery = useQuery({
        queryKey: ["permissions", "count"],
        queryFn: async () => {
            //check permission
            if (!checkPermission(CorePermissions.PermissionsRead)) return 0;

            const res = await client.api.permissions.filter.post({
                page: 1,
                limit: 1,
                filter: [],
                sort: [],
                withAudit: false,
            });
            if (res.error) throw res.error;
            return res.data?.total || 0;
        },
    });

    const stats = [
        {
            label: "Total Users",
            value: userCountQuery.data,
            isLoading: userCountQuery.isLoading,
            description: "Registered in system",
            icon: FiUsers,
            color: "primary",
            permissions: [CorePermissions.UsersRead]
        },
        {
            label: "Total Roles",
            value: roleCountQuery.data,
            isLoading: roleCountQuery.isLoading,
            description: "Access groups defined",
            icon: FiShield,
            color: "secondary",
            permissions: [CorePermissions.UsersRead]
        },
        {
            label: "Total Permissions",
            value: permissionCountQuery.data,
            isLoading: permissionCountQuery.isLoading,
            description: "Individual access keys",
            icon: FiKey,
            color: "warning",
            permissions: [CorePermissions.UsersRead]
        },
    ];

    const filteredStats = stats.filter(stat => stat.permissions.every(p => checkPermission(p)));

    return (
        <PageContainer>
            <h1 className="text-2xl font-bold mb-6 text-gray-900">System Dashboard</h1>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

                {filteredStats.map((stat, index) => (
                    <Card key={index} className="hover:scale-[1.02] transition-transform duration-200 shadow-sm border-none bg-white/50 backdrop-blur-md">
                        <CardHeader className="flex gap-4 px-6 pt-6">
                            <div className={`p-3 bg-${stat.color}/10 rounded-xl`}>
                                <stat.icon className={`w-6 h-6 text-${stat.color}`} />
                            </div>
                            <div className="flex flex-col">
                                <p className="text-sm font-medium text-default-500">{stat.label}</p>
                                <p className="text-xs text-default-400">{stat.description}</p>
                            </div>
                        </CardHeader>
                        <CardBody className="px-6 pb-6 pt-2">
                            <div className="flex items-baseline gap-2">
                                {stat.isLoading ? (
                                    <Skeleton className="h-10 w-16 rounded-lg" />
                                ) : (
                                    <span className="text-4xl font-bold tracking-tight text-gray-900">
                                        {stat.value}
                                    </span>
                                )}
                            </div>
                        </CardBody>
                    </Card>
                ))}
            </div>
        </PageContainer>
    );
}