import { addToast, BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Tab, Tabs } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router";
import { client, fetcher } from "../../../../../client";
import { UserCreateDtoWithRoles, UserUpdateDtoWithRoles } from "../../../../../modules/core/applications/dtos/user.dto";
import { ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper, ZZBYRoleCheckboxInput } from "../../../../components/ZZBYForm";
import { DeleteDropdownItem } from "../../../../components/Datatables/deleteDropdownItem";
import { PageContainer } from "../../../../components/PageContainer";


export interface UserFormProps {
    form: any;
    mode: "CREATE" | "EDIT";
}
export function UserForm({ form, mode }: UserFormProps) {

    return (
        <Tabs className="pt-3">
            <Tab key={'basic'} title="Basic Information" >
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2">
                        <Card>
                            <CardHeader>
                                Login Information
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFormFieldInput
                                    name="username"
                                    form={form}
                                    label="Username"
                                    placeholder="Enter username"
                                    isReadOnly={mode === "EDIT"}
                                />

                                <ZZBYFormFieldInput
                                    name="email"
                                    form={form}
                                    label="Email"
                                    placeholder="Enter email" />

                                <ZZBYFormFieldInput
                                    name="password"
                                    form={form}
                                    label="Password"
                                    placeholder="Enter password"
                                    type="password" />

                                <ZZBYFormFieldInput
                                    name="password_confirmation"
                                    form={form}
                                    label="Confirm Password"
                                    placeholder="Confirm password"
                                    type="password" />

                            </CardBody>
                        </Card>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-2">
                        <Card>
                            <CardHeader>
                                Role Information
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYRoleCheckboxInput form={form} name="roles" />
                            </CardBody>
                        </Card>
                    </div>
                </div>
            </Tab>
        </Tabs >
    )
}


export default function UserEdit() {
    const routeParams = useParams();
    const navigate = useNavigate();

    const id = routeParams.id as string;
    const mode: "EDIT" | "CREATE" = id ? "EDIT" : "CREATE"
    let formProps: ZZBYFormGeneratorWrapperProps<any>
    let queryKey = mode === "EDIT" ? ['user', id] : ['users']
    let entityName = "User"
    let validatorsOnSubmit = mode === "EDIT" ? UserUpdateDtoWithRoles : UserCreateDtoWithRoles
    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => mode === "EDIT" ? client.api.users({ id: id }).get() : null,
        enabled: mode === "EDIT" && !!id
    })

    if (mode === "EDIT") {
        if (itemQuery.isLoading) {
            return <div className="p-3">Loading...</div>
        }

        if (itemQuery.error) {
            throw itemQuery.error
        }

        if (!itemQuery.data?.data) {
            return (
                <div className="p-3">
                    <div className="mb-4">User not found</div>
                    <Button color="primary" onPress={() => window.history.back()}>
                        Back
                    </Button>
                </div>
            )
        }

        const userData = itemQuery.data.data as any;

        formProps = {
            mode: mode,
            defaultValues: {
                username: userData.username,
                email: userData.email,
                roles: userData.roles.map((role: any) => role.id) ?? [],
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/users/:id", {
                method: "PUT",
                body: value as any,
                params: { id: id! },
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/system/users/${id}`)
        }

    } else {

        formProps = {
            mode: mode,
            defaultValues: {
                username: '',
                email: '',
                roles: [],
                password: '',
                password_confirmation: ''
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/users", {
                method: "POST",
                body: value as any,
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/system/users/${id}`, { replace: true })
        }
    }

    const backRoute = '/backoffice/system/users';
    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{mode === "CREATE" ? "Create User" : `User Edit : ${id}`} </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/system/users">Users</BreadcrumbItem>
                                {
                                    mode === "CREATE"
                                        ? <BreadcrumbItem>Create User</BreadcrumbItem>
                                        : <BreadcrumbItem href={`/backoffice/system/users/${id}`}>User Edit : {id}</BreadcrumbItem>
                                }
                            </Breadcrumbs>

                        </div>

                        <div className="flex flex-row gap-3">
                            {(
                                <Dropdown>
                                    <DropdownTrigger>
                                        <Button isIconOnly>
                                            <span className="text-lg font-bold">...</span>
                                        </Button>
                                    </DropdownTrigger>
                                    <DropdownMenu aria-label="User Actions">
                                        {mode == "EDIT" ? DeleteDropdownItem({
                                            entityName: entityName,
                                            id: id,
                                            backRoute: backRoute,
                                            deleteFn: () => fetcher("/api/users/:id", {
                                                method: "DELETE",
                                                params: { id: id! },
                                                headers: {},
                                                body: {}
                                            })
                                        }) : null}

                                        <DropdownItem
                                            key="cancel"
                                            onPress={() => navigate(backRoute)}
                                        >
                                            Cancel
                                        </DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            )}

                            {/* 
                            <Button color="default" onPress={() => navigate('/backoffice/system/users')}>
                                Cancel
                            </Button> */}

                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save
                            </Button>
                        </div>

                    </div>
                    <UserForm form={form} mode={mode} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )

}
