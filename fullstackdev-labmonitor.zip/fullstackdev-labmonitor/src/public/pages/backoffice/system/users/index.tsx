import { BreadcrumbItem, Breadcrumbs, Button, Pagination } from '@heroui/react'
import { useForm } from '@tanstack/react-form'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { ColumnDef, createColumnHelper, getCoreRowModel, useReactTable } from '@tanstack/react-table'
import { useMemo } from 'react'
import { client } from '../../../../../client'
import { TFilterOperator, TPaginateQuery, TPaginateQueryForm, TPaginateResult, TSortOrder, TSortQuery } from '../../../../../common/types'
import { debounce } from '../../../../../common/utils/debounce'
import { UserEntity } from "../../../../../modules/core/domains/entities/user.entity"
import { FilterDateRangeInput, FilterFormDefs, FilterTextInput } from '../../../../components/Datatables/filterForm'
import { EntityColumn, GenericDataTable, ZZBYDatatable } from '../../../../components/Datatables/zzbyDatatable'
import { BaseEntity } from '../../../../../common/domains/baseEntity'
import { useNavigate } from 'react-router'
import { PageContainer } from '../../../../components/PageContainer'



export default function UserIndex() {

    const userColDefs: EntityColumn<UserEntity>[] = [
        {
            key: "id",
            header: "ID",
            cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
        },
        {
            key: "username",
            header: "Username",
            meta: {
                isTitle: true
            },
            cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
        },
        {
            key: "email",
            header: "Email",
            cell: (info) => <span className="text-gray-600">{info.getValue()}</span>,
        },
        {
            key: "createdAt",
            header: "Created At",
            cell: (info) => <span className="text-gray-500">{(info.getValue() as Date).toLocaleDateString()}</span>,
        },
        {
            key: "creatorName",
            header: "Created By",
            cell: (info) => <span className="text-gray-500 font-mono text-tiny">{info.getValue() || "System"}</span>,
        },
        {
            key: "updatedAt",
            header: "Updated At",
            cell: (info) => <span className="text-gray-500">{(info.getValue() as Date).toLocaleDateString()}</span>,
        },
        {
            key: "updaterName",
            header: "Updated By",
            cell: (info) => <span className="text-gray-500 font-mono text-tiny">{info.getValue() || "-"}</span>,
        },
    ]

    const userDefaultFilter: TPaginateQueryForm<UserEntity> = {
        page: 1,
        limit: 20,
        withAudit: true,
        filter: {
            keyword: {
                key: 'username|email' as keyof UserEntity,
                operator: 'like' as TFilterOperator,
                value: ''
            },
            createdAt: {
                key: 'createdAt' as keyof UserEntity,
                operator: 'between' as TFilterOperator,
                value: []
            },
        },
        sort: [{ key: 'id', order: 'asc' as TSortOrder }]
    }

    const userFilterForm: FilterFormDefs[] = [
        {
            widget: 'text',
            label: 'Username Or Email',
            name: 'keyword'
        },
        {
            widget: 'dateRange',
            label: 'Created At',
            name: 'createdAt'
        }
    ]

    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Users Management</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/system">System</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/system/users">Users</BreadcrumbItem>
                    </Breadcrumbs>

                </div>
                <Button color="default" onPress={() => navigate('/backoffice/system/users/create')}>
                    Add User
                </Button>
            </div>
            <GenericDataTable<UserEntity>
                queryKey={['users']}
                queryFn={client.api.users.filter.post}
                viewRoute="/backoffice/system/users/:id"
                colDefs={userColDefs} defaultFilter={userDefaultFilter}
                filterFormDefs={userFilterForm} />
        </PageContainer>
    )
}
