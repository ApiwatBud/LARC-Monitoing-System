import { PageContainer } from "../../../components/PageContainer";

export default function Dashboard() {
    return (
        <PageContainer>
            <h1>Dashboard</h1>
        </PageContainer>
    )
}