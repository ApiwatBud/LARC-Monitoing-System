import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { client, fetcher } from "../../../client";
import { UserUpdateDto } from "../../../modules/core/applications/dtos/user.dto";
import { ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../components/ZZBYForm";
import { PageContainer } from "../../components/PageContainer";

export default function ProfileEdit() {
    const queryKey = ['me']
    const entityName = "Profile"

    const meQuery = useQuery({
        queryKey: queryKey,
        queryFn: async () => {
            let data = await client.api.me.post({
                body: {},
                headers: {},
            })
            if (data.status === 200) {
                return data.data
            }
            throw new Error("Failed to fetch user data")
        },
    })

    if (meQuery.isLoading) {
        return <div className="p-3">Loading...</div>
    }

    console.log(meQuery.data)

    if (!meQuery.data?.user) {
        return <div className="p-3">User session not found</div>
    }

    const userData = meQuery.data.user as any;

    const formProps: ZZBYFormGeneratorWrapperProps<any> = {
        mode: "EDIT",
        defaultValues: {
            username: userData.username,
            email: userData.email,
        },
        validators: {
            onSubmit: UserUpdateDto
        },
        apiSubmit: async (value: any) => {
            let data = await client.api.me.put(value)
            return data

        },
        entityName: entityName,
        queryKey: queryKey,
    }

    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form: any) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Edit Profile</h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem>Edit Profile</BreadcrumbItem>
                            </Breadcrumbs>
                        </div>

                        <div className="flex flex-row gap-3">
                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save Changes
                            </Button>
                        </div>
                    </div>

                    <div className='grid grid-cols-1 gap-3 max-w-2xl'>
                        <Card>
                            <CardHeader className="font-bold px-4 pt-4 text-gray-800">
                                Personal Information
                            </CardHeader>
                            <CardBody className="flex flex-col gap-4 p-4">
                                <ZZBYFormFieldInput
                                    name="username"
                                    form={form}
                                    label="Username"
                                    placeholder="Your username"
                                    isReadOnly
                                />

                                <ZZBYFormFieldInput
                                    name="email"
                                    form={form}
                                    label="Email Address"
                                    placeholder="Your email address"
                                />

                                <div className="border-t border-gray-100 my-2"></div>
                                <p className="text-xs text-gray-500 font-medium">Leave password fields blank if you don't want to change it.</p>

                                <ZZBYFormFieldInput
                                    name="password"
                                    form={form}
                                    label="New Password"
                                    placeholder="Enter new password"
                                    type="password"
                                />

                                <ZZBYFormFieldInput
                                    name="password_confirmation"
                                    form={form}
                                    label="Confirm New Password"
                                    placeholder="Confirm your new password"
                                    type="password"
                                />
                            </CardBody>
                        </Card>
                    </div>
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )
}
