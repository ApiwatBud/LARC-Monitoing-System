import { Route } from "react-router";
import ProfileEdit from "../profile";

export default function MyWorkspaceRoutes() {
    return (
        <Route path="myworkspace">
            <Route index element={<ProfileEdit />} />
            <Route path="profile" element={<ProfileEdit />} />
        </Route>
    )
}
