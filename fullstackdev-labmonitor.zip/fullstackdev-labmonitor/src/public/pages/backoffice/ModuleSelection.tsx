import { Card, CardBody } from "@heroui/react";
import { motion } from "framer-motion";
import { FiGrid, FiUser } from "react-icons/fi";
import { useNavigate } from "react-router";
import { PageContainer } from "../../components/PageContainer";
import { useAppModuleStore } from "../../stores/useAppModuleStore";

import { Variants } from "framer-motion";

const container: Variants = {
    hidden: { opacity: 0 },
    show: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1,
            delayChildren: 0.2
        }
    }
};

const item: Variants = {
    hidden: { y: 20, opacity: 0 },
    show: {
        y: 0,
        opacity: 1,
        transition: {
            type: "spring" as const,
            stiffness: 300,
            damping: 24
        }
    }
};

export default function ModuleSelection() {
    const navigate = useNavigate();
    const { moduleMenus, setModuleKey } = useAppModuleStore();


    // Visual configuration for modules
    const visualConfig: Record<string, { colorClass: string, bgClass: string, iconColor: string }> = {
        'myworkspace': { colorClass: "text-emerald-600", bgClass: "bg-emerald-50", iconColor: "text-emerald-500" },
        'system': { colorClass: "text-purple-600", bgClass: "bg-purple-50", iconColor: "text-purple-500" },
        'labmonitor': { colorClass: "text-blue-600", bgClass: "bg-blue-50", iconColor: "text-blue-500" },
        'inventory': { colorClass: "text-amber-600", bgClass: "bg-amber-50", iconColor: "text-amber-500" },
    };

    const handleSelect = (key: string, path: string) => {
        setModuleKey(key);
        navigate(path);
    };


    return (
        <PageContainer className="">
            <div className="max-w-6xl mx-auto py-12 px-6">
                <header className="text-center mb-16 relative">
                    <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-64 h-64 bg-primary-200/20 blur-[80px] rounded-full -z-10" />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5 }}
                    >
                        <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight mb-4">
                            Welcome to <span className="text-primary-600">ZZBY</span>
                        </h1>
                        <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">
                            Select a workspace to begin. Manage your laboratory operations and system configurations from one central hub.
                        </p>
                    </motion.div>
                </header>

                <motion.div
                    variants={container}
                    initial="hidden"
                    animate="show"
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                >
                    {moduleMenus.map((mod) => {
                        const config = visualConfig[mod.key] || { colorClass: "text-slate-600", bgClass: "bg-slate-50", iconColor: "text-slate-500" };
                        const targetPath = mod.children?.[0]?.route || mod.route || "/backoffice";
                        return (
                            <motion.div key={mod.key} variants={item}>
                                <Card
                                    isPressable
                                    onPress={() => handleSelect(mod.key, targetPath)}
                                    className="h-full border-none shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-400 group overflow-hidden bg-white rounded-3xl"
                                >
                                    <CardBody className="p-10 flex flex-col items-center text-center">
                                        <div className={`p-6 rounded-2xl ${config.bgClass} mb-8 group-hover:scale-110 transition-transform duration-300 relative`}>
                                            <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 rounded-2xl transition-opacity" />
                                            <mod.icon size={52} className={config.colorClass} />

                                        </div>

                                        <h3 className="text-2xl font-extrabold text-slate-800 mb-4 group-hover:text-primary-600 transition-colors">
                                            {mod.name}
                                        </h3>

                                        <p className="text-slate-500 leading-relaxed font-normal">
                                            {mod.description || `Access and manage the ${mod.name} workspace.`}
                                        </p>

                                        <div className="mt-8 flex items-center gap-2 text-primary-500 font-bold text-sm uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0">
                                            Open Workspace
                                            <FiGrid size={16} />
                                        </div>
                                    </CardBody>

                                    <div className={`absolute bottom-0 left-0 right-0 h-1.5 ${config.colorClass.replace('text-', 'bg-')} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left`} />
                                </Card>
                            </motion.div>
                        );
                    })}
                </motion.div>
            </div>
        </PageContainer>
    );
}
