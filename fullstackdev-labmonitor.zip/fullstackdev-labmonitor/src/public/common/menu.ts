import { ModuleMenu } from "../../modules/config/domains/entities/menu.entity";

/**
 * Filter visible menus based on user permissions, roles, and enabled modules.
 * This function handles both top-level module visibility and recursive permission checks.
 */
export function filterVisibleMenus(
    menus: ModuleMenu[],
    userPermissions: readonly string[],
    userRoles: readonly string[],
    enabledModules: readonly string[]
): ModuleMenu[] {
    const isSuperAdmin = userRoles.includes("superadmin") || userRoles.includes("admin");

    // Helper to check if a root-level module is enabled for the user
    const isRootModuleEnabled = (menu: ModuleMenu) => {
        if (isSuperAdmin) return true;
        // Always allow if 'self' permission is present (e.g. My Workspace)
        if (menu.permissions?.includes("self")) return true;
        // Check if module key is in user's enabled modules list
        return enabledModules.includes(menu.key);
    };

    // Recursive function to filter menu items based on permissions and roles
    const filterItem = (menu: ModuleMenu): ModuleMenu | null => {
        // 1. Permission Check
        const hasPermission =
            !menu.permissions ||
            menu.permissions.length === 0 ||
            menu.permissions.includes("self") ||
            (isSuperAdmin ? true : menu.permissions.some(p => userPermissions.includes(p)));

        // 2. Role Check
        const hasRole =
            !menu.roles ||
            menu.roles.length === 0 ||
            (isSuperAdmin ? true : menu.roles.some(r => userRoles.includes(r)));

        if (!hasPermission || !hasRole) {
            return null;
        }

        // 3. Process Children Recursively
        if (menu.children) {
            const filteredChildren = menu.children
                .map(child => filterItem(child))
                .filter((child): child is ModuleMenu => child !== null);

            // If a parent item has no route and no visible children, hide it
            // (e.g. a category with all items hidden)
            if (!menu.route && filteredChildren.length === 0) {
                return null;
            }

            return { ...menu, children: filteredChildren };
        }

        return menu;
    };

    return menus
        .filter(menu => isRootModuleEnabled(menu)) // First filter root modules
        .map(menu => filterItem(menu))             // Then filter contents recursively
        .filter((menu): menu is ModuleMenu => menu !== null);
}