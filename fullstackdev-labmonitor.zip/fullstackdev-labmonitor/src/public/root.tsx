import { useNavigate, BrowserRouter, Route, Routes } from "react-router";
import AuthLayout from "./layouts/AuthLayout";
import Home from "./pages/Home";
import Login from "./pages/Login";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import DashboardLayout from "./layouts/DashboardLayout";
import ModuleSelection from "./pages/backoffice/ModuleSelection";
import { HeroUIProvider, ToastProvider } from "@heroui/react";
import { HealthCheckProvider } from "./providers/HealthCheckProvider";
import AppLayout from "./layouts/AppLayout";
import { CurrentUserProvider } from "./providers/CurrentUserProvider";

// Import Module Metas
import { RegisteredModules } from "../registry";
import React from "react";

import ProfileEdit from "./pages/backoffice/profile";

const queryClient = new QueryClient();

function AppContent() {
    const navigate = useNavigate();

    return (
        <HeroUIProvider navigate={navigate}>
            <ToastProvider />
            <QueryClientProvider client={queryClient}>
                <HealthCheckProvider>
                    <CurrentUserProvider>
                        <Routes>
                            <Route path="/" element={<Home />} />
                            <Route element={<AuthLayout />}>
                                <Route path="/login" element={<Login />} />
                            </Route>
                            <Route path="backoffice">
                                <Route element={<AppLayout />}>
                                    <Route path="" index element={<ModuleSelection />} />
                                </Route>

                                <Route element={<DashboardLayout />}>
                                    <Route path="profile" element={<ProfileEdit />} />
                                    {RegisteredModules.map((module) => (
                                        (module.routes) ? (
                                            <React.Fragment key={module.key}>
                                                {module.routes()}
                                            </React.Fragment>
                                        ) : null
                                    ))}
                                </Route>
                            </Route>
                        </Routes>
                    </CurrentUserProvider>
                </HealthCheckProvider>
            </QueryClientProvider>
        </HeroUIProvider >
    );
}

export function App() {
    return (
        <BrowserRouter>
            <AppContent />
        </BrowserRouter>
    )
}