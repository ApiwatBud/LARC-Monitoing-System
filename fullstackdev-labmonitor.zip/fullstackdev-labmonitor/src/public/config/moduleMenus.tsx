import { ModuleMenu } from "../../modules/config/domains/entities/menu.entity";
import { RegisteredModules } from "../../registry";


export const moduleMenus: ModuleMenu[] = RegisteredModules.map(m => m.menu());
