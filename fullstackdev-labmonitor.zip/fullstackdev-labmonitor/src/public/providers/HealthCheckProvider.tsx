import React, { createContext, useContext } from "react";
import { useQuery } from "@tanstack/react-query";
import { client } from "../../client";

interface HealthStatus {
    isOnline: boolean;
    isLoading: boolean;
    error?: any;
}

const HealthCheckContext = createContext<HealthStatus | undefined>(undefined);

export const HealthCheckProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { data, isError, isLoading, isFetching, error } = useQuery({
        queryKey: ["healthCheck"],
        queryFn: async () => {
            const { data, error } = await client.api.health.get();
            if (error) throw error;
            return data;
        },
        refetchInterval: 10000, // Check every 10 seconds
        retry: 3,
        refetchOnWindowFocus: true,
        refetchIntervalInBackground: false, // Don't poll when tab is inactive to save resources
    });

    const isOnline = !!data && typeof data === 'object' && 'status' in data && (data as any).status === "online";

    // Optimization: We only include isOnline, isLoading, and error in the status.
    // By excluding isFetching from the memo dependencies, we ensure that background
    // polls (which toggle isFetching) do not trigger re-renders of all context consumers
    // unless the actual server status or error state changes.
    // This fixes the "[Violation] 'setTimeout' handler took 186ms" caused by excessive re-renders.
    const status = React.useMemo<HealthStatus>(() => ({
        isOnline: isOnline && !isError,
        isLoading: isLoading,
        error: isError ? error : undefined,
    }), [isOnline, isError, isLoading, error]);

    return (
        <HealthCheckContext.Provider value={status}>
            {children}
        </HealthCheckContext.Provider>
    );
};

export const useHealthCheck = () => {
    const context = useContext(HealthCheckContext);
    if (context === undefined) {
        throw new Error("useHealthCheck must be used within a HealthCheckProvider");
    }
    return context;
};
