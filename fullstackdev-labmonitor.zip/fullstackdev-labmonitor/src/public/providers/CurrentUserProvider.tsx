import { createContext, useContext, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { client } from "../../client";
import { UserEntity } from "../../modules/core/domains/entities/user.entity";

interface CurrentUserContextType {
    user: UserEntity | null;
    permissions: readonly string[];
    roles: readonly string[];
    modules: readonly string[];
    isLoading: boolean;
    refetch: () => void;
    checkPermission: (required: string | string[]) => boolean;
}

const CurrentUserContext = createContext<CurrentUserContextType | undefined>(undefined);

export function CurrentUserProvider({ children }: { children: React.ReactNode }) {
    const { data, isLoading, refetch } = useQuery({
        queryKey: ['me'],
        queryFn: async () => {
            const res = await client.api.me.post();
            if (res.status === 200 && res.data) {
                return res.data;
            }
            return null;
        },
        staleTime: 1000 * 60 * 5, // 5 minutes
        retry: false
    });

    const user = (data?.user && 'id' in data.user && typeof data.user.id === 'number') ? data.user as unknown as UserEntity : null;
    const permissions = (data?.permissions || []) as string[];
    const roles = data?.roles || [];
    const modules = data?.modules || [];

    const checkPermission = (required: string | string[]) => {
        const requiredList = Array.isArray(required) ? required : [required];
        if (requiredList.includes('anyone')) return true;
        if (requiredList.includes('guest')) return true;

        if (!user) return false;

        if (user.username === 'superadmin') return true;

        return requiredList.some(p => permissions.includes(p as any));
    }

    const value = {
        user,
        permissions,
        roles,
        modules,
        isLoading,
        refetch,
        checkPermission
    };

    return (
        <CurrentUserContext.Provider value={value}>
            {children}
        </CurrentUserContext.Provider>
    );
}

export function useCurrentUser() {
    const context = useContext(CurrentUserContext);
    if (context === undefined) {
        throw new Error("useCurrentUser must be used within a CurrentUserProvider");
    }
    return context;
}
