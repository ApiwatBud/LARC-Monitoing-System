import { Outlet } from "react-router";

export default function AuthLayout() {
    return (
        <div className="flex items-center justify-center h-screen bg-slate-50">
            <Outlet />
        </div>
    )
}