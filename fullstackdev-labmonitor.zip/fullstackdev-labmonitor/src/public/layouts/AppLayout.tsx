import { Outlet, useNavigate } from "react-router";
import { SidebarProvider } from "../providers/SidebarProvider";


import { Navbar, NavbarBrand, NavbarContent, Button, Dropdown, DropdownTrigger, DropdownMenu, DropdownItem } from "@heroui/react";
import Sidebar from "../components/Sidebar/Sidebar";
import UserDropdown from "../components/UserDropdown";
import { useSidebar } from "../providers/SidebarProvider";
import { FiMenu, FiGrid, FiChevronDown } from "react-icons/fi";
import { HealthStatus } from "../components/HealthStatus";
import { useAppModuleStore } from "../stores/useAppModuleStore";
import { NavbarComponent } from "../components/Navbar";

function AppLayoutContent() {
    return (
        <div className="flex h-screen overflow-hidden">
            <div className="flex flex-col flex-1 min-w-0">
                <NavbarComponent />
                <div className="flex-1 overflow-auto p-4">
                    <Outlet />
                </div>
            </div>
        </div>
    )
}

export default function AppLayout() {
    return (
        <SidebarProvider>
            <AppLayoutContent />
        </SidebarProvider>
    )
}
