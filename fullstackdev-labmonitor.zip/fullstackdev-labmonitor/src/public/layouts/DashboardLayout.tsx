import { Outlet } from "react-router";
import { SidebarProvider } from "../providers/SidebarProvider";


import { NavbarComponent } from "../components/Navbar";
import Sidebar from "../components/Sidebar/Sidebar";


function DashboardLayoutContent() {
    return (
        <div className="flex h-screen overflow-hidden">
            {/* Sidebar is a flex item. When it expands/contracts, the sibling div will adjust. */}
            <Sidebar />

            <div className="flex flex-col flex-1 min-w-0">
                <NavbarComponent />
                <div className="flex-1 overflow-auto p-4">
                    <Outlet />
                </div>
            </div>
        </div>
    )
}

export default function DashboardLayout() {
    return (
        <SidebarProvider>
            <DashboardLayoutContent />
        </SidebarProvider>
    )
}
