import { AIMeta } from "../modules/ai/module.meta";
import { ConfigMeta } from "./modules/config/module.meta";
import { IModuleMeta } from "./modules/config/domains/entities/module.meta";
import { CoreMeta } from "./modules/core/module.meta";
import { LabMonitorMeta } from "../modules/labmonitor/module.meta";

/**
 * Central registry of all available modules in the application.
 * This array is the single source of truth for:
 * 1. Routing (root.tsx)
 * 2. Menu generation (moduleMenus.tsx)
 * 3. Permission syncing (sync-permissions.ts)
 */
export const RegisteredModules: IModuleMeta[] = [
    CoreMeta,
    LabMonitorMeta,
    ConfigMeta,
    AIMeta,
];
