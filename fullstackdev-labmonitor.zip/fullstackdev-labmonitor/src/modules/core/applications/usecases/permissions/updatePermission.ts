import z from "zod";
import { IPermissionRepository } from "../../../domains/repositories/permission.repository";
import { PermissionUpdateDto, PermissionResponseDto, PermissionEntityToResponseDto } from "../../dtos/permission.dto";
import { BusinessValidationError } from "../../../../../common/errors";

interface UpdatePermissionDeps {
    permissionRepository: IPermissionRepository
}

interface UpdatePermissionProps {
    name: string
    dto: PermissionUpdateDto
    userId?: number
}

export const UpdatePermission = ({ permissionRepository }: UpdatePermissionDeps) => async ({ name, dto, userId }: UpdatePermissionProps) => {

    const validate = await PermissionUpdateDto.parseAsync(dto)
    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await permissionRepository.transaction(async (transaction) => {
        const existingPermission = await permissionRepository.findById({ name, transaction })

        if (!existingPermission) {
            throw new Error("Permission not found")
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }

        const permission = await permissionRepository.update({ name, entity: validate, transaction, userId })
        return PermissionEntityToResponseDto(permission)
    })
}
