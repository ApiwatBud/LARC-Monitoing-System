import { IPermissionRepository } from "../../../domains/repositories/permission.repository"
import { PermissionEntityToResponseDto, PermissionResponseDto } from "../../dtos/permission.dto"

interface GetPermissionsDeps {
    permissionRepository: IPermissionRepository
}
interface GetPermissionsProps {

}
export const GetPermissions = ({ permissionRepository }: GetPermissionsDeps) => async ({ }: GetPermissionsProps) => {
    let permissions = await permissionRepository.findAll()
    return permissions.map(permission => PermissionEntityToResponseDto(permission))

}
