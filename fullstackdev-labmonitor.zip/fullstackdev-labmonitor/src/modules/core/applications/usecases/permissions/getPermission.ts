import { IPermissionRepository } from "../../../domains/repositories/permission.repository"
import { PermissionEntityToResponseDto, PermissionResponseDto } from "../../dtos/permission.dto"

interface GetPermissionDeps {
    permissionRepository: IPermissionRepository
}
interface GetPermissionProps {
    name: string
}
export const GetPermission = ({ permissionRepository }: GetPermissionDeps) => async ({ name }: GetPermissionProps) => {
    const permission = await permissionRepository.findById({ name })
    if (!permission) {
        throw new Error("Permission not found")
    }
    return PermissionEntityToResponseDto(permission)
}
