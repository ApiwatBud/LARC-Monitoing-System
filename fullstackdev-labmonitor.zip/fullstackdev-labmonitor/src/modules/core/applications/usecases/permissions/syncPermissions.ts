import { PermissionEntity } from "../../../domains/entities/permission.entity";
import { IPermissionRepository } from "../../../domains/repositories/permission.repository";

interface syncPermissionsDeps {
    permissionRepository: IPermissionRepository
}

interface syncPermissionsProps {
    permissions: string[]
}

export const SyncPermissions = ({ permissionRepository }: syncPermissionsDeps) => async ({ permissions }: syncPermissionsProps) => {
    return await permissionRepository.transaction(async (transaction) => {
        //just insert if exists ignore
        const createdPermissions = [] as PermissionEntity[]
        for (const permission of permissions) {
            const existingPermission = await permissionRepository.findById({ name: permission, transaction })
            if (!existingPermission) {
                const permissionEntity = await permissionRepository.create({ entity: { name: permission }, transaction })
                createdPermissions.push(permissionEntity)
            }
        }
        return createdPermissions
    })
}