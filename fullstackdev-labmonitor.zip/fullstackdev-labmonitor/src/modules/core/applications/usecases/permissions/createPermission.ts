import z from "zod";
import { IPermissionRepository } from "../../../domains/repositories/permission.repository";
import { PermissionCreateDto, PermissionEntityToResponseDto, PermissionResponseDto } from "../../dtos/permission.dto";
import { BusinessValidationError } from "../../../../../common/errors";

interface CreatePermissionDeps {
    permissionRepository: IPermissionRepository
}

interface CreatePermissionProps {
    dto: PermissionCreateDto
    userId?: number
}

export const CreatePermission = ({ permissionRepository }: CreatePermissionDeps) => async ({ dto, userId }: CreatePermissionProps) => {

    const validate = dto
    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await permissionRepository.transaction(async (transaction) => {
        const existingPermission = await permissionRepository.findById({ name: validate.name, transaction })

        if (existingPermission) {
            issues.push({ path: ["name"], message: "Permission name already exists", code: "custom" });
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }

        const permission = await permissionRepository.create({ entity: validate, transaction, userId })
        return PermissionEntityToResponseDto(permission)
    })
}
