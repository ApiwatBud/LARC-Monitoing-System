import { TPaginateQuery, TPaginateResult } from "../../../../../common/types"
import { PermissionEntity } from "../../../domains/entities/permission.entity"
import { IPermissionRepository } from "../../../domains/repositories/permission.repository"
import { PermissionEntityToResponseDto, PermissionResponseDto } from "../../dtos/permission.dto"

interface PaginatePermissionDeps {
    permissionRepository: IPermissionRepository
}

interface PaginatePermissionProps extends TPaginateQuery<PermissionEntity> {
}

export const PaginatePermission = ({ permissionRepository }: PaginatePermissionDeps) => async ({ page, limit, filter, sort, withAudit }: PaginatePermissionProps) => {

    page = page || 1
    limit = limit || 20
    filter = filter || []
    sort = sort || []
    withAudit = withAudit || false

    const result = await permissionRepository.paginate({ query: { page, limit, filter, sort, withAudit } })
    const pginateResult: TPaginateResult<PermissionResponseDto> = {
        ...result,
        data: result.data.map(permission => PermissionEntityToResponseDto(permission))
    }
    return pginateResult
}
