import z from "zod"
import { BusinessValidationError } from "../../../../../common/errors"
import { IPermissionRepository } from "../../../domains/repositories/permission.repository"
import { PermissionEntityToResponseDto, PermissionResponseDto } from "../../dtos/permission.dto"

interface DeletePermissionDeps {
    permissionRepository: IPermissionRepository
}
interface DeletePermissionProps {
    name: string
}
export const DeletePermission = ({ permissionRepository }: DeletePermissionDeps) => async ({ name }: DeletePermissionProps) => {
    return await permissionRepository.transaction(async (transaction) => {
        const permission = await permissionRepository.findById({ name, transaction })
        if (!permission) {
            throw new BusinessValidationError([
                {
                    path: ["name"],
                    message: "Permission not found",
                    code: "custom"
                }
            ] as z.core.$ZodSuperRefineIssue[])
        }

        const deletedPermission = await permissionRepository.delete({ name, transaction })
        return PermissionEntityToResponseDto(deletedPermission)
    })
}
