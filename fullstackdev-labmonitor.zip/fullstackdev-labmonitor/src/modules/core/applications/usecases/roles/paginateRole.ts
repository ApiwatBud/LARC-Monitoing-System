import { TPaginateQuery } from "../../../../../common/types"
import { RoleEntity } from "../../../domains/entities/role.entity"
import { IRoleRepository } from "../../../domains/repositories/role.repository"

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface PaginateRoleDeps {
    roleRepository: IRoleRepository
}

interface PaginateRoleProps extends TPaginateQuery<RoleEntity> {
    context: UsecaseContext
}

export const PaginateRole = ({ roleRepository }: PaginateRoleDeps) => async ({ page, limit, filter, sort, withAudit, context }: PaginateRoleProps) => {

    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesRead)

    page = page || 1
    limit = limit || 20
    filter = filter || []
    sort = sort || []
    withAudit = withAudit || false

    const result = await roleRepository.paginate({ query: { page, limit, filter, sort, withAudit } })
    return result
}
