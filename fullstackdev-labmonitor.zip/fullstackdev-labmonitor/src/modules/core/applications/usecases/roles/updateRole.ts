import z from "zod";
import { IRoleRepository } from "../../../domains/repositories/role.repository";
import { RoleUpdateDto, RoleResponseDto } from "../../dtos/role.dto";
import { BusinessValidationError } from "../../../../../common/errors";
import { IPermissionRoleRepository } from "../../../domains/repositories/permission_role.repository";
import { RoleWithPermissionsEntityToResponseDto, RoleWithPermissionsUpdateDto } from "../../dtos/role.aggs.dto";
import { AnyTransaction } from "../../../../../common/persistents/types";
import { IRoleModuleRepository } from "../../../domains/repositories/role_module.repository";
import { PermissionEntity } from "../../../domains/entities/permission.entity";

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { CorePermissions } from "../../../domains/permissions";

interface UpdateRoleDeps {
    roleRepository: IRoleRepository
}

interface UpdateRoleProps {
    id: number
    dto: RoleUpdateDto
    context: UsecaseContext
}

export const UpdateRole = ({ roleRepository }: UpdateRoleDeps) => async ({ id, dto, context }: UpdateRoleProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesUpdate)

    const issues = [] as z.core.$ZodSuperRefineIssue[]

    const validateGuard = async (transaction: AnyTransaction) => {
        const existingRole = await roleRepository.findByName({ name: dto.name, transaction })

        if (existingRole && existingRole.id !== id) {
            issues.push({ path: ["name"], message: "Role name already exists", code: "custom" });
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }
    }

    return await roleRepository.transaction(async (transaction) => {
        await validateGuard(transaction)

        const role = await roleRepository.update({ id, entity: dto, transaction, userId: context.user?.id })
        return RoleResponseDto.parse(role)
    })
}

interface UpdateRoleWithPermissionsDeps {
    roleRepository: IRoleRepository
    permissionRoleRepository: IPermissionRoleRepository
    roleModuleRepository: IRoleModuleRepository
}

interface UpdateRoleWithPermissionsProps {
    id: number
    dto: RoleWithPermissionsUpdateDto
    context: UsecaseContext
}

export const UpdateRoleWithPermissions = ({ roleRepository, permissionRoleRepository, roleModuleRepository }: UpdateRoleWithPermissionsDeps) => async ({ id, dto, context }: UpdateRoleWithPermissionsProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesUpdate)
    const issues = [] as z.core.$ZodSuperRefineIssue[]

    const validateGuard = async (transaction: AnyTransaction) => {
        const existingRole = await roleRepository.findByName({ name: dto.name, transaction })

        if (existingRole && existingRole.id !== id) {
            issues.push({ path: ["name"], message: "Role name already exists", code: "custom" });
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }
    }

    return await roleRepository.transaction(async (transaction) => {
        await validateGuard(transaction)
        const role = await roleRepository.update({ id, entity: dto, transaction, userId: context.user?.id })

        let permission: PermissionEntity[] = []
        if (dto.permissions) {
            permission = await permissionRoleRepository.syncPermissions({ id, permissions: dto.permissions, transaction })
        } else {
            permission = await permissionRoleRepository.findPermissionsByRoleId({ role_id: id, transaction })
        }

        // Handle modules
        if (dto.modules) {
            await roleModuleRepository.syncModules({ roleId: id, moduleKeys: dto.modules, transaction });
        }
        const modules = await roleModuleRepository.getModulesByRoleId({ roleId: id, transaction });

        return RoleWithPermissionsEntityToResponseDto(
            role,
            permission,
            modules
        )
    })
}