import { RoleEntity } from "../../../domains/entities/role.entity"
import { IRoleRepository } from "../../../domains/repositories/role.repository"

interface InitializeRoleDeps {
    roleRepository: IRoleRepository
}

export const InitializeRoles = ({ roleRepository }: InitializeRoleDeps) => async () => {
    const roles = [
        {
            name: "superadmin",
            description: "Super Administrator"
        },
        {
            name: "admin",
            description: "Administrator"
        },
        {
            name: "user",
            description: "User"
        }
    ]

    return await roleRepository.transaction(async (transaction) => {
        const promises = [] as Promise<RoleEntity>[]
        for (const role of roles) {
            const existingRole = await roleRepository.findByName({ name: role.name, transaction })
            if (existingRole) {
                continue
            }
            promises.push(roleRepository.create({ entity: role, transaction }))
        }
        let createdRoles = await Promise.all(promises)
        console.log("Roles created: ", createdRoles)
        return createdRoles
    })
}