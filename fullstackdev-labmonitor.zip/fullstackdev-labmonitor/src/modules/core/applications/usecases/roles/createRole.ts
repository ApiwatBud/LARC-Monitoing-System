import z from "zod";
import { IRoleRepository } from "../../../domains/repositories/role.repository";
import { RoleCreateDto, RoleResponseDto } from "../../dtos/role.dto";
import { BusinessValidationError } from "../../../../../common/errors";
import { IPermissionRoleRepository } from "../../../domains/repositories/permission_role.repository";
import { RoleWithPermissionsCreateDto, RoleWithPermissionsEntityToResponseDto } from "../../dtos/role.aggs.dto";
import { PermissionEntity } from "../../../domains/entities/permission.entity";
import { IRoleModuleRepository } from "../../../domains/repositories/role_module.repository";
import { ModuleEntity } from "../../../../config/domains/entities/module.enity";

interface CreateRoleDeps {
    roleRepository: IRoleRepository
}

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { CorePermissions } from "../../../domains/permissions";

interface CreateRoleProps {
    dto: RoleCreateDto
    context: UsecaseContext
}

export const CreateRole = ({ roleRepository }: CreateRoleDeps) => async ({ dto, context }: CreateRoleProps) => {

    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesCreate)

    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await roleRepository.transaction(async (transaction) => {
        const existingRole = await roleRepository.findByName({ name: dto.name, transaction })

        if (existingRole) {
            issues.push({ path: ["name"], message: "Role name already exists", code: "custom" });
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }

        const role = await roleRepository.create({ entity: dto, transaction, userId: context.user?.id })
        return RoleResponseDto.parse(role)
    })
}


interface CreateRoleWithPermissionsDeps {
    roleRepository: IRoleRepository
    permissionRoleRepository: IPermissionRoleRepository
    roleModuleRepository: IRoleModuleRepository
}

interface CreateRoleWithPermissionsProps {
    dto: RoleWithPermissionsCreateDto
    context: UsecaseContext
}

export const CreateRoleWithPermissions = ({ roleRepository, permissionRoleRepository, roleModuleRepository }: CreateRoleWithPermissionsDeps) => async ({ dto, context }: CreateRoleWithPermissionsProps) => {

    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesCreate)

    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await roleRepository.transaction(async (transaction) => {
        const existingRole = await roleRepository.findByName({ name: dto.name, transaction })

        if (existingRole) {
            issues.push({ path: ["name"], message: "Role name already exists", code: "custom" });
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }
        const role = await roleRepository.create({ entity: dto, transaction, userId: context.user?.id })
        let permission = [] as PermissionEntity[]
        if (dto.permissions.length > 0) {
            permission = await permissionRoleRepository.syncPermissions({ id: role.id, permissions: dto.permissions, transaction })
        }

        // Handle modules
        await roleModuleRepository.syncModules({ roleId: role.id, moduleKeys: dto.modules, transaction });
        const modules = await roleModuleRepository.getModulesByRoleId({ roleId: role.id, transaction });

        return RoleWithPermissionsEntityToResponseDto(
            role,
            permission,
            modules,
        )
    })
}