import { IRoleRepository } from "../../../domains/repositories/role.repository"
import { RoleResponseDto } from "../../dtos/role.dto"

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface GetRolesDeps {
    roleRepository: IRoleRepository
}
interface GetRolesProps {
    context: UsecaseContext
}
export const GetRoles = ({ roleRepository }: GetRolesDeps) => async ({ context }: GetRolesProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesRead)
    let roles = await roleRepository.findAll()
    return roles.map(role => RoleResponseDto.parse(role))

}