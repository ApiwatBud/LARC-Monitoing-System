import z from "zod"
import { BusinessValidationError } from "../../../../../common/errors"
import { IRoleRepository } from "../../../domains/repositories/role.repository"
import { RoleResponseDto } from "../../dtos/role.dto"

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface DeleteRoleDeps {
    roleRepository: IRoleRepository
}
interface DeleteRoleProps {
    id: number
    context: UsecaseContext
}
export const DeleteRole = ({ roleRepository }: DeleteRoleDeps) => async ({ id, context }: DeleteRoleProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesDelete)
    return await roleRepository.transaction(async (transaction) => {
        const role = await roleRepository.findById({ id, transaction })
        if (!role) {
            throw new BusinessValidationError([
                {
                    path: ["id"],
                    message: "Role not found",
                    code: "custom"
                }
            ] as z.core.$ZodSuperRefineIssue[])
        }

        if (role.name === "superadmin") {
            throw new BusinessValidationError([
                {
                    path: ["name"],
                    message: "Cannot delete superadmin role",
                    code: "custom"
                }
            ] as z.core.$ZodSuperRefineIssue[])
        }

        const deletedRole = await roleRepository.delete({ id, transaction })
        return RoleResponseDto.parse(deletedRole)
    })
}
