import { IPermissionRoleRepository } from "../../../domains/repositories/permission_role.repository"
import { IRoleRepository } from "../../../domains/repositories/role.repository"
import { RoleWithPermissionsEntityToResponseDto } from "../../dtos/role.aggs.dto"
import { RoleResponseDto } from "../../dtos/role.dto"
import { IRoleModuleRepository } from "../../../domains/repositories/role_module.repository"

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface GetRoleDeps {
    roleRepository: IRoleRepository
}
interface GetRoleProps {
    id: number
    context: UsecaseContext
}
export const GetRole = ({ roleRepository }: GetRoleDeps) => async ({ id, context }: GetRoleProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesRead)
    const role = await roleRepository.findById({ id })
    if (!role) {
        throw new Error("Role not found")
    }
    return RoleResponseDto.parse(role)
}


interface GetRoleWithPermissionsDeps {
    roleRepository: IRoleRepository
    permissionRoleRepository: IPermissionRoleRepository
    roleModuleRepository: IRoleModuleRepository
}
interface GetRoleWithPermissionsProps {
    id: number
    context: UsecaseContext
}



export const GetRoleWithPermissions = ({ roleRepository, permissionRoleRepository, roleModuleRepository }: GetRoleWithPermissionsDeps) => async ({ id, context }: GetRoleWithPermissionsProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.RolesRead)
    const role = await roleRepository.findById({ id })
    if (!role) {
        throw new Error("Role not found")
    }
    const permissions = await permissionRoleRepository.findPermissionsByRoleId({ role_id: id })
    const modules = await roleModuleRepository.getModulesByRoleId({ roleId: id })
    return RoleWithPermissionsEntityToResponseDto(role, permissions, modules)
}