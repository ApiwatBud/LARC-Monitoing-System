import z from "zod"
import { BusinessValidationError } from "../../../../../common/errors"
import { UserEntity } from "../../../domains/entities/user.entity"
import { IUserRepository } from "../../../domains/repositories/user.repository"
import { UserResponseDto } from "../../dtos/user.dto"

interface DeleteUserDeps {
    userRepository: IUserRepository
}

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface DeleteUserProps {
    id: UserEntity['id']
    context: UsecaseContext
}

export const DeleteUser = ({ userRepository }: DeleteUserDeps) => async ({ id, context }: DeleteUserProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersDelete)
    return await userRepository.transaction(async (transaction) => {
        const user = await userRepository.findById({ id, transaction })
        if (!user) {
            throw new BusinessValidationError([
                {
                    path: ["id"],
                    message: "User not found",
                    code: "custom"
                }
            ] as z.core.$ZodSuperRefineIssue[])
        }

        const superadminUsername = process.env.SUPERADMIN_USERNAME || "superadmin"
        if (user.username === superadminUsername) {
            throw new BusinessValidationError([
                {
                    path: ["username"],
                    message: "Cannot delete superadmin user",
                    code: "custom"
                }
            ] as z.core.$ZodSuperRefineIssue[])
        }

        let deletedUser = await userRepository.delete({ id, transaction })
        return UserResponseDto.parse(deletedUser)
    })
}