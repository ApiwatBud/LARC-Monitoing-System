import z, { ZodType } from "zod";
import { UserEntity, UserUpdateEntity } from "../../../domains/entities/user.entity";
import { IUserRepository } from "../../../domains/repositories/user.repository";
import { AnyTransaction } from "../../../../../common/persistents/types";
import { BusinessValidationError } from "../../../../../common/errors";
import { UserResponseDto, UserUpdateDto, UserUpdateDtoWithRoles } from "../../dtos/user.dto";
import { IRoleUserRepository } from "../../../domains/repositories/role_user.repository";
import { IRoleRepository } from "../../../domains/repositories/role.repository";
import { hashPassword } from "../../../../../common/utils/password";


import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { CorePermissions } from "../../../domains/permissions";

interface UpdateUserDeps {
    userRepository: IUserRepository
}

interface UpdateUserDepsWithRoles {
    userRepository: IUserRepository
    roleRepository: IRoleRepository
    roleUserRepository: IRoleUserRepository
}


interface UpdateUserProps {
    id: UserEntity["id"],
    userUpdateDto: UserUpdateDto
    transaction?: AnyTransaction
    context: UsecaseContext
}

interface UpdateUserWithRolesProps {
    id: UserEntity["id"],
    userUpdateDtoWithRoles: UserUpdateDtoWithRoles
    transaction?: AnyTransaction
    context: UsecaseContext
}


export const UpdateUserWithRoles = ({ userRepository, roleRepository, roleUserRepository }: UpdateUserDepsWithRoles) => async ({ id, userUpdateDtoWithRoles, context }: UpdateUserWithRolesProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersUpdate)

    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await userRepository.transaction(async (transaction) => {
        //check user not found here
        const checkuser = await userRepository.findById({ id, transaction })
        if (!checkuser) {
            throw new Error("User not found")
        }

        const [existingUser, existingEmail, superAdminRole] = await Promise.all([
            userRepository.findByUsername({ username: userUpdateDtoWithRoles.username, transaction }),
            userRepository.findByEmail({ email: userUpdateDtoWithRoles.email, transaction }),
            roleRepository.findByName({ name: "superadmin", transaction })

        ]);

        if (existingUser && existingUser.id !== id) {
            issues.push({ path: ["username"], message: "Username already exists", code: "custom" })
        }
        if (existingEmail && existingEmail.id !== id) {
            issues.push({ path: ["email"], message: "Email already exists", code: "custom" })
        }

        if (!superAdminRole) {
            issues.push({ path: ["roles"], message: "Superadmin role not found", code: "custom" })
        }

        if (issues.length > 0) {
            throw new BusinessValidationError(issues)
        }
        if (!userUpdateDtoWithRoles.password) {
            delete userUpdateDtoWithRoles.password
            delete userUpdateDtoWithRoles.password_confirmation
        } else {
            userUpdateDtoWithRoles.password = await hashPassword(userUpdateDtoWithRoles.password)
        }
        const user = await userRepository.update({ id, entity: userUpdateDtoWithRoles, transaction, userId: context.user?.id })


        const userSelectedRoles = userUpdateDtoWithRoles.roles ?? []

        if (user.username === 'superadmin' && superAdminRole) {
            if (!userSelectedRoles.includes(superAdminRole.id)) {
                userSelectedRoles.push(superAdminRole.id)
            }
        }

        const roleUsers = await roleUserRepository.syncRoles({
            user_id: user.id,
            userSelectedRoles,
            transaction
        })

        return UserResponseDto.parse(user)
    })
}

export const UpdateUser = ({ userRepository }: UpdateUserDeps) => async ({ id, userUpdateDto, context }: UpdateUserProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersUpdate)

    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await userRepository.transaction(async (transaction) => {
        //check user not found here
        const checkuser = await userRepository.findById({ id, transaction })
        if (!checkuser) {
            throw new Error("User not found")
        }

        const [existingUser, existingEmail] = await Promise.all([
            userRepository.findByUsername({ username: userUpdateDto.username, transaction }),
            userRepository.findByEmail({ email: userUpdateDto.email, transaction }),

        ]);

        if (existingUser && existingUser.id !== id) {
            issues.push({ path: ["username"], message: "Username already exists", code: "custom" })
        }
        if (existingEmail && existingEmail.id !== id) {
            issues.push({ path: ["email"], message: "Email already exists", code: "custom" })
        }


        if (issues.length > 0) {
            throw new BusinessValidationError(issues)
        }
        if (!userUpdateDto.password) {
            delete userUpdateDto.password
            delete userUpdateDto.password_confirmation
        } else {
            userUpdateDto.password = await hashPassword(userUpdateDto.password)
        }
        const user = await userRepository.update({ id, entity: userUpdateDto, transaction, userId: context.user?.id })

        return UserResponseDto.parse(user)
    })
}