import z from "zod";
import { BusinessValidationError } from "../../../../../common/errors";
import { IUserRepository } from "../../../domains/repositories/user.repository";
import { hashPassword } from "../../../../../common/utils/password";

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { CorePermissions } from "../../../domains/permissions";

interface resetPasswordDeps {
    userRepository: IUserRepository
}

interface resetPasswordProps {
    username: string
    password: string
    context: UsecaseContext
}

export function ResetPasswordUsecase(deps: resetPasswordDeps) {
    return async function resetPassword(props: resetPasswordProps): Promise<boolean> {
        const guard = createGuard(props.context)
        guard.ensure(CorePermissions.UsersUpdate)
        const user = await deps.userRepository.findByUsername({ username: props.username })
        const issues: z.core.$ZodSuperRefineIssue[] = []
        if (!user) {
            issues.push({
                code: "custom",
                path: ["username"],
                message: "User not found"
            })
        }
        if (issues.length > 0) {
            throw new BusinessValidationError(issues)
        }
        const newpassword = await hashPassword(props.password)
        await deps.userRepository.update({ id: user!.id, entity: { password: newpassword } })
        return true
    }
}