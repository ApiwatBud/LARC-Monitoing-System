import { status } from "elysia"
import { IRoleUserRepository } from "../../../domains/repositories/role_user.repository"
import { IUserRepository } from "../../../domains/repositories/user.repository"
import { UserWithRolesResponseDto } from "../../dtos/user.aggs.dto"
import { UserResponseDto } from "../../dtos/user.dto"

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface GetUserProps {
    id: number
    context: UsecaseContext
}
interface GetUserDeps {
    userRepository: IUserRepository
}

export const GetUser = (deps: GetUserDeps) => async ({ id, context }: GetUserProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersRead)
    let user = await deps.userRepository.findById({ id })
    if (!user) {
        throw status(404, "User not found")
    }
    return UserResponseDto.parse(user)
}

interface GetUserWithRolesDeps {
    userRepository: IUserRepository
    roleUserRepository: IRoleUserRepository
}

export const GetUserWithRoles = (deps: GetUserWithRolesDeps) => async ({ id, context }: GetUserProps) => {
    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersRead)
    let user = await deps.userRepository.findById({ id })
    let roles = await deps.roleUserRepository.findRolesByUserId({ id })
    return UserWithRolesResponseDto.parse({
        ...user,
        roles: roles
    })
}