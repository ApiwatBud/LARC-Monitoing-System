import { TPaginateQuery, TPaginateResult, TUsecase } from "../../../../../common/types"
import { UserEntity } from "../../../domains/entities/user.entity"
import { IUserRepository } from "../../../domains/repositories/user.repository"

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard"
import { CorePermissions } from "../../../domains/permissions"

interface PaginateUserDeps {
    userRepository: IUserRepository
}
interface PaginateUserProps extends TPaginateQuery<UserEntity> {
    context: UsecaseContext
}

export const PaginateUser: TUsecase<PaginateUserDeps, PaginateUserProps, TPaginateResult<UserEntity>> = ({ userRepository }: PaginateUserDeps) => async ({ page, limit, filter, sort, withAudit, context }: PaginateUserProps) => {

    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersRead)

    page = page || 1
    limit = limit || 20
    filter = filter || []
    sort = sort || []
    withAudit = withAudit || false

    const result = await userRepository.paginate({ query: { page, limit, filter, sort, withAudit } })
    return result
}
