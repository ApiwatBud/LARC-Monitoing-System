import z, { ZodIssue, ZodType } from "zod";
import { AnyDatabase, AnyTransaction } from "../../../../../common/persistents/types";
import { UserCreateEntity } from "../../../domains/entities/user.entity";
import { IUserRepository } from "../../../domains/repositories/user.repository";
import { UserCreateDto, UserCreateDtoWithRoles, UserResponseDto as UserResponseDto } from "../../dtos/user.dto";
import { BusinessValidationError } from "../../../../../common/errors";
import { IRoleUserRepository } from "../../../domains/repositories/role_user.repository";
import { hashPassword } from "../../../../../common/utils/password";
import { TUsecase } from "../../../../../common/types";
import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { CorePermissions } from "../../../domains/permissions";




interface CreateUserDeps {
    userRepository: IUserRepository
}


interface CreateUserProps {
    userCreateDto: UserCreateDto
    transaction?: AnyTransaction
    context: UsecaseContext
}

export const CreateUser: TUsecase<CreateUserDeps, CreateUserProps, UserResponseDto> = ({ userRepository }: CreateUserDeps) => async ({ userCreateDto, context }: CreateUserProps) => {

    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersCreate)

    const validate = userCreateDto
    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await userRepository.transaction(async (transaction) => {
        // Manual DB checks
        const [existingUser, existingEmail] = await Promise.all([
            userRepository.findByUsername({ username: validate.username, transaction }),
            userRepository.findByEmail({ email: validate.email, transaction })
        ]);

        if (existingUser) {
            issues.push({ path: ["username"], message: "Username already taken", code: "custom" });
        }
        if (existingEmail) {
            issues.push({ path: ["email"], message: "Email already registered", code: "custom" });
        }

        // If we have issues, throw them as a single object
        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }


        const { password_confirmation, ...userCreateEntity } = validate
        const user = await userRepository.create({ entity: userCreateEntity, transaction, userId: context.user?.id })
        return UserResponseDto.parse(user)
    })
}

//implement create user with sync roles
interface CreateUserWithSyncRolesDeps {
    userRepository: IUserRepository
    roleUserRepository: IRoleUserRepository
}
interface CreateUserWithSyncRolesProps {
    dto: UserCreateDtoWithRoles
    context: UsecaseContext
}
export const CreateUserWithSyncRoles = ({ userRepository, roleUserRepository }: CreateUserWithSyncRolesDeps) => async ({ dto, context }: CreateUserWithSyncRolesProps) => {

    const guard = createGuard(context)
    guard.ensure(CorePermissions.UsersCreate)

    const validate = await UserCreateDtoWithRoles.parseAsync(dto)
    const issues = [] as z.core.$ZodSuperRefineIssue[]

    return await userRepository.transaction(async (transaction) => {
        // Manual DB checks
        const [existingUser, existingEmail] = await Promise.all([
            userRepository.findByUsername({ username: validate.username, transaction }),
            userRepository.findByEmail({ email: validate.email, transaction })
        ]);

        if (existingUser) {
            issues.push({ path: ["username"], message: "Username already taken", code: "custom" });
        }
        if (existingEmail) {
            issues.push({ path: ["email"], message: "Email already registered", code: "custom" });
        }

        // If we have issues, throw them as a single object
        if (issues.length > 0) {
            throw new BusinessValidationError(issues);
        }


        const { password_confirmation, ...userCreateEntity } = validate
        if (userCreateEntity.password) {
            userCreateEntity.password = await hashPassword(userCreateEntity.password)
        }
        const user = await userRepository.create({ entity: userCreateEntity, transaction, userId: context.user?.id })

        await roleUserRepository.syncRoles({ user_id: user.id, userSelectedRoles: dto.roles, transaction })

        return UserResponseDto.parse(user)
    })
}
