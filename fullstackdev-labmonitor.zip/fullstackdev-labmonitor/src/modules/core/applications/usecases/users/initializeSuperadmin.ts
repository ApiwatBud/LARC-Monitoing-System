import { hashPassword } from "../../../../../common/utils/password"
import { IRoleRepository } from "../../../domains/repositories/role.repository"
import { IRoleUserRepository } from "../../../domains/repositories/role_user.repository"
import { IUserRepository } from "../../../domains/repositories/user.repository"

interface InitializeSuperadminDeps {
    userRepository: IUserRepository
    roleRepository: IRoleRepository
    roleUserRepository: IRoleUserRepository
}

export const InitializeSuperadmin = ({ userRepository, roleRepository, roleUserRepository }: InitializeSuperadminDeps) => async () => {
    const superadmin = {
        username: process.env.SUPERADMIN_USERNAME! || "superadmin",
        password: await hashPassword(process.env.SUPERADMIN_PASSWORD! || 'superadmin'),
        email: process.env.SUPERADMIN_EMAIL! || "superadmin@superadmin.com",
    }
    const existingSuperadmin = await userRepository.findByUsername({ username: superadmin.username })
    const superadminRole = await roleRepository.findByName({ name: "superadmin" })

    if (existingSuperadmin) {
        console.log("✅ Superadmin already exists")

        let hasUpserAdmin = await roleUserRepository.findById({ user_id: existingSuperadmin.id, role_id: superadminRole!.id })
        if (hasUpserAdmin) {
            console.log("✅ Superadmin already has role")
            return
        }
        await roleUserRepository.create({
            entity: {
                user_id: existingSuperadmin.id,
                role_id: superadminRole!.id
            }
        })
        console.log("✅ Assign Superadmin Role to Superadmin")
        return
    }
    if (!superadminRole) {
        throw new Error("❌ Superadmin role not found")
    }
    const createdUser = await userRepository.create({ entity: superadmin })
    const createdSuperadmin = await roleUserRepository.create({
        entity: {
            user_id: createdUser.id,
            role_id: superadminRole.id
        }
    })

    console.log("✅ Superadmin Newly created")
}