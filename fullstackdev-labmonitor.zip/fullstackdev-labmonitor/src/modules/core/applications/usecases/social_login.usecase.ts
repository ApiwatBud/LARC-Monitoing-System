import { SocialAuthService } from "../services/social_auth.service";
import { IUserRepository } from "../../domains/repositories/user.repository";
import { ISocialAccountRepository } from "../../persistents/pg/repositories/social_account.pg.repository";
import { ISocialProviderRepository } from "../../../config/persistents/pg/repositories/social_provider.pg.repository";
import { ISessionRepository } from "../../domains/repositories/session.repository";
import { SessionEntity } from "../../domains/entities/sessions.entity";
import { UserEntity } from "../../domains/entities/user.entity"; // Ensure imports
import { SocialAccountEntity } from "../../domains/entities/social_account.entity";
import { AUTH_SESSION_EXPIRES_IN_DAYS } from "../../../../server_config";

export const SocialLogin = (
    socialAuthService: SocialAuthService,
    userRepo: IUserRepository,
    socialAccountRepo: ISocialAccountRepository,
    socialProviderRepo: ISocialProviderRepository,
    sessionRepo: ISessionRepository
) => async (props: {
    provider: string;
    code: string;
    codeVerifier?: string;
}) => {
        const { provider, code, codeVerifier } = props;

        // 1. Validate permissions/setup
        const providerConfig = await socialProviderRepo.findByProvider(provider);
        if (!providerConfig) throw new Error("Provider not configured");

        // 2. Exchange code for tokens
        const tokens = await socialAuthService.validateCallback(provider, code, codeVerifier);

        // 3. Get User Profile
        const profile = await socialAuthService.getUserProfile(provider, tokens.accessToken);
        if (!profile) throw new Error("Failed to retrieve user profile");

        // 4. Check if Social Account exists
        // We need providerConfig.id for the relation
        const existingAccount = await socialAccountRepo.findByProviderAndSocialId(providerConfig.id!, profile.id);

        let userId: number;
        let user: UserEntity | null = null;

        if (existingAccount) {
            userId = existingAccount.userId;
            user = await userRepo.findById({ id: userId });
            // Update tokens logic could go here (e.g. updating access/refresh tokens in social account)
            // For brevity we skip updating the social account tokens on every login unless necessary
        } else {
            // 5. Check if User exists by email (if email is available)
            if (profile.email) {
                user = await userRepo.findByEmail({ email: profile.email });
            }

            if (!user) {
                // Create new user
                const randomPassword = Math.random().toString(36).slice(-10) + Math.random().toString(36).slice(-10);

                // Note: userRepo.create expects 'entity' property based on GenericPgTransactionalRepository
                user = await userRepo.create({
                    entity: {
                        username: profile.name || `user_${profile.id.substring(0, 8)}`,
                        email: profile.email || `${provider}_${profile.id}@social.login`,
                        password: randomPassword,
                    }
                });
            }

            if (!user || !user.id) throw new Error("Failed to create or find user");

            userId = user.id;

            // 6. Link Social Account
            await socialAccountRepo.create({
                userId: userId,
                providerId: providerConfig.id!,
                socialId: profile.id,
                email: profile.email,
                name: profile.name,
                avatar: profile.avatar,
                accessToken: tokens.accessToken,
                refreshToken: tokens.refreshToken,
                expiresAt: tokens.expiresIn ? new Date(Date.now() + tokens.expiresIn * 1000) : undefined
            } as SocialAccountEntity);
        }

        if (!user) throw new Error("User not found");

        // 7. Generate Session (Database Session)
        const token = crypto.randomUUID()
        const refreshToken = crypto.randomUUID()
        const lastActive = new Date()
        const expiresAt = new Date().setDate(new Date().getDate() + AUTH_SESSION_EXPIRES_IN_DAYS)

        const newSessionEntity: SessionEntity = {
            id: token,
            user_id: user.id!,
            refresh_token: refreshToken,
            expires_at: new Date(expiresAt),
            created_at: lastActive,
            is_revoked: false,
            last_active: lastActive,
        }

        const session = await sessionRepo.create({ session: newSessionEntity })

        return {
            user,
            session: {
                access_token: session.id,
                refresh_token: session.refresh_token,
                expires_at: session.expires_at,
            }
        };
    };
