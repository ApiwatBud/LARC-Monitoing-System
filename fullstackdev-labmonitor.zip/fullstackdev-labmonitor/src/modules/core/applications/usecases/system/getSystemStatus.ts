import * as os from 'node:os';
import { TUsecase } from "../../../../../common/types";
import { SystemStatusEntity } from '../../../domains/entities/system_status.entity';

export const GetSystemStatus: TUsecase<{}, {}, SystemStatusEntity> = () => async () => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memPercentage = (usedMem / totalMem) * 100;

    const cpus = os.cpus();
    const cpuModel = cpus.length > 0 ? cpus[0].model : 'Unknown';
    const cpuSpeed = cpus.length > 0 ? cpus[0].speed : 0;

    return {
        os: {
            platform: os.platform(),
            release: os.release(),
            arch: os.arch(),
            uptime: os.uptime(),
            hostname: os.hostname(),
        },
        cpu: {
            model: cpuModel,
            speed: cpuSpeed,
            cores: cpus.length,
            loadAvg: os.loadavg(),
        },
        memory: {
            total: totalMem,
            free: freeMem,
            used: usedMem,
            percentage: Number(memPercentage.toFixed(2)),
        },
        process: {
            memoryUsage: process.memoryUsage(),
            uptime: process.uptime(),
            version: process.version,
        },
        timestamp: new Date()
    };
};
