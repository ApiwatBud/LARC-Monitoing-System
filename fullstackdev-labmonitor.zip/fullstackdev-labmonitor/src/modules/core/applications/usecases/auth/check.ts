import { z } from "zod"
import { IUserRepository } from "../../../domains/repositories/user.repository"
import { ISessionRepository } from "../../../domains/repositories/session.repository"
import { status } from "elysia"
import { loginResponseDto } from "../../dtos/auth.dto"

export const checkDto = z.object({
    user_id: z.number(),
    username: z.string(),
    email: z.string(),
    access_token: z.string(),
    refresh_token: z.string(),
    expires_at: z.iso.datetime(),
})

interface checkDeps {
    userRepository: IUserRepository,
    sessionRepository: ISessionRepository
}

interface checkProps {
    user_id: number,
    username: string,
    email: string,
    access_token: string,
    refresh_token: string,
    expires_at: string,
}

export const CheckUseCase = (deps: checkDeps) => async (props: checkProps) => {
    const { userRepository, sessionRepository } = deps
    const { user_id, username, email, access_token, refresh_token, expires_at } = checkDto.parse(props)
    const user = await userRepository.findByEmail({ email })
    const session = await sessionRepository.findById({ id: access_token })

    if (!user || !session) {
        throw status(401, "Invalid Login Credentials")
    }

    if (user.id != user_id || user.username != username || user.email != email || session.id != access_token || session.refresh_token != refresh_token || session.expires_at.toISOString() != expires_at) {
        throw status(401, "Invalid Login Credentials")
    }

    //update last active
    let updatedSession = await sessionRepository.updateLastActive({ id: access_token })

    return loginResponseDto.parse({
        user: user, session: {
            access_token: session.id,
            refresh_token: session.refresh_token,
            expires_at: session.expires_at.toISOString(),
        }
    })
}