import { z } from "zod"
import { ISessionRepository } from "../../../domains/repositories/session.repository"
import { IUserRepository } from "../../../domains/repositories/user.repository"
import { verifyPassword } from "../../../../../common/utils/password"
import { SessionEntity } from "../../../domains/entities/sessions.entity"
import { status } from "elysia"
import { loginDto, loginResponseDto } from "../../dtos/auth.dto"
import { AUTH_SESSION_EXPIRES_IN_DAYS } from "../../../../../server_config"
interface LoginDeps {
    userRepository: IUserRepository
    sessionRepository: ISessionRepository
}

interface LoginProps {
    email: string
    password: string
}



export const LoginUseCase = (deps: LoginDeps) => (props: LoginProps) => {
    const { userRepository, sessionRepository } = deps
    return userRepository.transaction(async (trx) => {
        const { email, password } = loginDto.parse(props)
        const isEmail = email.includes("@")
        const user = isEmail ? await userRepository.findByEmail({ email, transaction: trx }) : await userRepository.findByUsername({ username: email, transaction: trx })
        if (!user) {
            throw status(401, { message: "Invalid Login Credentials" })
        }
        const isPasswordValid = await verifyPassword(password, user.password)
        if (!isPasswordValid) {
            throw status(401, { message: "Invalid Login Credentials" })
        }
        const token = crypto.randomUUID()
        const refreshToken = crypto.randomUUID()
        const lastActive = new Date()
        const expiresAt = new Date().setDate(new Date().getDate() + AUTH_SESSION_EXPIRES_IN_DAYS)
        const newSessionEntity: SessionEntity = {
            id: token,
            user_id: user.id,
            refresh_token: refreshToken,
            expires_at: new Date(expiresAt),
            created_at: lastActive,
            is_revoked: false,
            last_active: lastActive,
        }
        const session = await sessionRepository.create({ session: newSessionEntity, transaction: trx })
        return loginResponseDto.parse({
            user: user, session: {
                access_token: session.id,
                refresh_token: session.refresh_token,
                expires_at: session.expires_at.toISOString(),
            }
        })
    })
}