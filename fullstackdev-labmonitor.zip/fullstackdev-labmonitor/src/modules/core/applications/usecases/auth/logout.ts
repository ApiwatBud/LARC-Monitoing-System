import { ISessionRepository } from "../../../domains/repositories/session.repository"
import { status } from "elysia"

interface LogoutDeps {
    sessionRepository: ISessionRepository
}

interface LogoutProps {
    sessionId: string
}

export const LogoutUseCase = (deps: LogoutDeps) => async (props: LogoutProps) => {
    const { sessionRepository } = deps
    const { sessionId } = props

    await sessionRepository.delete({ id: sessionId })

    return {
        message: "Logged out successfully"
    }
}
