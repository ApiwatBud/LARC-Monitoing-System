import { z } from "zod"
import { ISessionRepository } from "../../../domains/repositories/session.repository"
import { IUserRepository } from "../../../domains/repositories/user.repository"
import { SessionEntity } from "../../../domains/entities/sessions.entity"
import { status } from "elysia"
import { loginResponseDto } from "../../dtos/auth.dto"
import { AUTH_SESSION_EXPIRES_IN_DAYS } from "../../../../../server_config"

interface RefreshDeps {
    userRepository: IUserRepository
    sessionRepository: ISessionRepository
}

interface RefreshProps {
    refreshToken: string
}

export const RefreshUseCase = (deps: RefreshDeps) => async (props: RefreshProps) => {
    const { userRepository, sessionRepository } = deps
    const { refreshToken } = props

    const session = await sessionRepository.findByRefreshToken({ refreshToken })
    if (!session || session.is_revoked) {
        throw status(401, { message: "Invalid Refresh Token" })
    }

    const user = await userRepository.findById({ id: session.user_id })
    if (!user) {
        throw status(401, { message: "User not found" })
    }

    // Revoke old session
    await sessionRepository.delete({ id: session.id })

    // Create new session
    const newToken = crypto.randomUUID()
    const newRefreshToken = crypto.randomUUID()
    const lastActive = new Date()
    const expiresAt = new Date().setDate(new Date().getDate() + AUTH_SESSION_EXPIRES_IN_DAYS)

    const newSessionEntity: SessionEntity = {
        id: newToken,
        user_id: user.id,
        refresh_token: newRefreshToken,
        expires_at: new Date(expiresAt),
        created_at: lastActive,
        is_revoked: false,
        last_active: lastActive,
    }

    const newSession = await sessionRepository.create({ session: newSessionEntity })

    return loginResponseDto.parse({
        user: user, session: {
            access_token: newSession.id,
            refresh_token: newSession.refresh_token,
            expires_at: newSession.expires_at.toISOString(),
        }
    })
}
