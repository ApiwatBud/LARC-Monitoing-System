import z from "zod"
import { PermissionEntity } from "../../domains/entities/permission.entity"
import { RoleWithPermissionsEntity } from "../../domains/entities/role.aggregate"
import { RoleEntity } from "../../domains/entities/role.entity"
import { ModuleEntity } from "../../../config/domains/entities/module.enity"
import { RoleCreateDto, RoleUpdateDto } from "./role.dto"

export const RoleWithPermissionsResponseDto = z.object({
    id: z.number(),
    name: z.string(),
    description: z.string().default(""),
    createdAt: z.date(),
    updatedAt: z.date(),
    permissions: z.array(z.string()),
    modules: z.array(z.string()).default([]),
} satisfies Partial<Record<keyof RoleWithPermissionsEntity, unknown>>)

export type RoleWithPermissionsResponseDto = z.infer<typeof RoleWithPermissionsResponseDto>


export function RoleWithPermissionsEntityToResponseDto(
    role: RoleEntity,
    permissions: PermissionEntity[],
    modules: ModuleEntity[] = []
): RoleWithPermissionsResponseDto {
    return RoleWithPermissionsResponseDto.parse({
        ...role,
        permissions: permissions.map(permission => permission.name),
        modules: modules.map(module => module.key),
    })
}

export const RoleWithPermissionsCreateDto = RoleCreateDto.extend({
    permissions: z.array(z.string()).default([]),
    modules: z.array(z.string()).default([]),
})

export type RoleWithPermissionsCreateDto = z.infer<typeof RoleWithPermissionsCreateDto>

export const RoleWithPermissionsUpdateDto = RoleUpdateDto.extend({
    permissions: z.array(z.string()).optional(),
    modules: z.array(z.string()).optional(),
})

export type RoleWithPermissionsUpdateDto = z.infer<typeof RoleWithPermissionsUpdateDto>
