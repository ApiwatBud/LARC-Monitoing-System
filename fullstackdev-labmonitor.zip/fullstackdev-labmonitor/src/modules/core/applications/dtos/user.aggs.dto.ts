import z from "zod"
import { UserResponseDto } from "./user.dto"
import { RoleResponseDto } from "./role.dto"

export const UserWithRolesResponseDto = UserResponseDto.extend({
    roles: z.array(RoleResponseDto)
})

export type UserWithRolesResponseDto = z.infer<typeof UserWithRolesResponseDto>