import z from "zod"
import { RoleEntity } from "../../domains/entities/role.entity"

export const RoleResponseDto = z.object({
    id: z.number(),
    name: z.string(),
    description: z.string(),
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
})

export type RoleResponseDto = z.infer<typeof RoleResponseDto>

export const RoleCreateDto = z.object({
    name: z.string().min(1, "Name is required"),
    description: z.string().optional().default(""),
})

export type RoleCreateDto = z.infer<typeof RoleCreateDto>

export const RoleUpdateDto = z.object({
    name: z.string().min(1, "Name is required"),
    description: z.string().optional().default(""),
})

export type RoleUpdateDto = z.infer<typeof RoleUpdateDto>



export function RoleEntityToResponseDto(role: RoleEntity): RoleResponseDto {
    return RoleResponseDto.parse({
        ...role,
        createdAt: role.createdAt,
        updatedAt: role.updatedAt,
    })
}


