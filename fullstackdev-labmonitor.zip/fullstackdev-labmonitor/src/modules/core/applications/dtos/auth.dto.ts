import z from "zod"

export const loginDto = z.object({
    email: z.string().min(1, "Email or Username is required"),
    password: z.string().min(1, "Password is required")
})

export const loginResponseDto = z.object({
    user: z.object({
        id: z.number(),
        username: z.string(),
        email: z.string(),
    }),
    session: z.object({
        access_token: z.string(),
        refresh_token: z.string(),
        expires_at: z.iso.datetime(),
    })
})