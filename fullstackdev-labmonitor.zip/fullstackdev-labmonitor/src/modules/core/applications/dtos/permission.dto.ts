import z from "zod"
import { PermissionEntity } from "../../domains/entities/permission.entity"

export const PermissionResponseDto = z.object({
    name: z.string(),
    description: z.string().nullish(),
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullish(),
    updaterName: z.string().nullish(),
} satisfies Partial<Record<keyof PermissionEntity, unknown>>)

export type PermissionResponseDto = z.infer<typeof PermissionResponseDto>

export const PermissionCreateDto = z.object({
    name: z.string().min(1, "Name is required"),
    description: z.string().optional().default(""),
} satisfies Partial<Record<keyof PermissionEntity, unknown>>)

export type PermissionCreateDto = z.infer<typeof PermissionCreateDto>

export const PermissionUpdateDto = z.object({
    description: z.string().optional().default(""),
} satisfies Partial<Record<keyof PermissionEntity, unknown>>)

export type PermissionUpdateDto = z.infer<typeof PermissionUpdateDto>


export function PermissionEntityToResponseDto(permission: PermissionEntity): PermissionResponseDto {
    return PermissionResponseDto.parse({
        ...permission,
        createdAt: permission.createdAt,
        updatedAt: permission.updatedAt,
        creatorName: (permission as any).creatorName,
        updaterName: (permission as any).updaterName,
    })
}