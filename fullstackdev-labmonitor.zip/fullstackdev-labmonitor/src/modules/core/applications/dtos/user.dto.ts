import z, { ZodType } from "zod"
import { UserCreateEntity, UserEntity, UserUpdateEntity } from "../../domains/entities/user.entity"

export const UserCreateDto = z.object({
    username: z.string().min(1, "Username is required"),
    email: z.email().min(1, "Email is required"),
    password: z.string().min(1, "Password is required"),
    password_confirmation: z.string().min(1, "Password Confirmation is required")
}).refine((data) => (data.password ?? "") === (data.password_confirmation ?? ""), {
    message: "Passwords do not match",
    path: ["password_confirmation"],
}) satisfies ZodType<UserCreateEntity>


export const UserUpdateDto = z.object({
    username: z.string().min(1, "Username is required"),
    email: z.email().min(1, "Email is required"),
    password: z.string().optional(),
    password_confirmation: z.string().optional()
}).refine((data) => (data.password ?? "") === (data.password_confirmation ?? ""), {
    message: "Passwords do not match",
    path: ["password_confirmation"],
}) satisfies ZodType<UserUpdateEntity>

export const UserCreateDtoWithRoles = UserCreateDto.extend({
    roles: z.array(z.number())
}) satisfies ZodType<UserCreateEntity>
export const UserUpdateDtoWithRoles = UserUpdateDto.extend({
    roles: z.array(z.number())
}) satisfies ZodType<UserUpdateEntity>

export type UserCreateDto = z.infer<typeof UserCreateDto>
export type UserUpdateDto = z.infer<typeof UserUpdateDto>
export type UserCreateDtoWithRoles = z.infer<typeof UserCreateDtoWithRoles>
export type UserUpdateDtoWithRoles = z.infer<typeof UserUpdateDtoWithRoles>

export const UserResponseDto = z.object({
    id: z.number(),
    username: z.string(),
    email: z.string(),
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullish(),
    updaterName: z.string().nullish(),
} satisfies Partial<Record<keyof UserEntity, unknown>>)

export type UserResponseDto = z.infer<typeof UserResponseDto>


