import * as p from '@clack/prompts';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

export async function main() {
    p.intro('Drizzle Kit CLI Helper');

    // 1. Scan for drizzle config files
    const configFiles = fs.readdirSync(process.cwd())
        .filter(file => file.startsWith('drizzle.config.') && (file.endsWith('.ts') || file.endsWith('.js')));

    if (configFiles.length === 0) {
        p.log.error('No drizzle.config.ts or drizzle.config.js files found in the root directory.');
        process.exit(1);
    }

    // 2. Select config file
    const selectedConfig = await p.select({
        message: 'Select a Drizzle configuration file',
        options: configFiles.map(file => ({ value: file, label: file })),
    });

    if (p.isCancel(selectedConfig)) {
        p.cancel('Operation cancelled');
        process.exit(0);
    }

    // 3. Select command
    const selectedCommand = await p.select({
        message: 'Select a drizzle-kit command',
        options: [
            { value: 'push', label: 'Push (db push)' },
            { value: 'generate', label: 'Generate (generate:migrations)' },
            { value: 'migrate', label: 'Migrate (migrate)' },
            { value: 'pull', label: 'Pull (introspect)' },
            { value: 'studio', label: 'Studio' },
        ],
    });

    if (p.isCancel(selectedCommand)) {
        p.cancel('Operation cancelled');
        process.exit(0);
    }

    let port = 3333;
    let host = "localhost"
    if (selectedCommand === 'studio') {
        const portInput = await p.text({
            message: 'Enter port (default: 3333)',
            placeholder: '3333',
            validate: (value) => {
                if (value && isNaN(Number(value))) return 'Please enter a valid number';
            },
        });

        if (!p.isCancel(portInput) && portInput) {
            port = Number(portInput);
        }

        const hostInput = await p.text({
            message: 'Enter host (default: localhost)',
            placeholder: 'localhost',
            validate: (value) => {
                if (value && !/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/.test(value)) return 'Please enter a valid IP address';
            },
        });

        if (!p.isCancel(hostInput) && hostInput) {
            host = hostInput;
        }
    }

    // 4. Run command
    const args = [selectedCommand as string, `--config=${selectedConfig}`];

    if (selectedCommand === 'studio') {
        args.push(`--port=${port}`);
        args.push(`--host=${host}`);
    }

    // For specific commands, we might need extra flags or slightly different names in newer drizzle-kit
    // but usually push, generate, migrate, pull, studio are the core ones.

    p.log.info(`Running: bunx drizzle-kit ${args.join(' ')}`);

    const runProcess = () => new Promise<void>((resolve, reject) => {
        const drizzleProcess = spawn('bunx', ['drizzle-kit', ...args], {
            stdio: 'inherit',
            shell: true
        });

        drizzleProcess.on('close', (code) => {
            if (code === 0) {
                p.outro('Drizzle Kit command completed successfully!');
                resolve();
            } else {
                p.log.error(`Drizzle Kit command failed with exit code ${code}`);
                reject(new Error(`Exit code ${code}`));
            }
        });

        drizzleProcess.on('error', (err) => {
            p.log.error(`Process error: ${err.message}`);
            reject(err);
        });
    });

    try {
        await runProcess();
    } catch (error) {
        process.exit(1);
    }
}
