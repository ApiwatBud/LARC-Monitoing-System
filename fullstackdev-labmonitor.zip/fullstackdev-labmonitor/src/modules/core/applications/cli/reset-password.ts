import { ResetPasswordUsecase } from "../usecases/users/resetPassword";
import 'dotenv/config';
import * as p from '@clack/prompts';
import { UserSqliteRepository } from "../../persistents/sqlite/repositories/user.sqlite.repository";
import { UserPgRepository } from "../../persistents/pg/repositories/user.pg.repository";
import { CorePermissions } from "../../domains/permissions";


export async function main() {

    const DB = process.env.DB
    const DB_FILE_NAME = process.env.DB_FILE_NAME

    if (!DB) {
        console.log("DB is not defined")
        process.exit(1)
    }

    if (DB) {

        console.log("Welcome to reset password cli")
        console.log("DB", DB)
        let resetPasswordUsecase: ReturnType<typeof ResetPasswordUsecase> | null = null;
        if (DB == 'sqlite') {
            const sqliteClient = await import("../../../../common/persistents/sqliteClient");
            resetPasswordUsecase = ResetPasswordUsecase({
                userRepository: new UserSqliteRepository(sqliteClient.default)
            })
        } else {
            const pgClient = await import("../../../../common/persistents/pgClient");
            resetPasswordUsecase = ResetPasswordUsecase({
                userRepository: new UserPgRepository(pgClient.default)
            })
        }

        const username = await p.text({
            message: "Enter username",
            placeholder: "username"
        })

        if (p.isCancel(username)) {
            p.cancel('Operation cancelled.');
            process.exit(0);
        }

        const password = await p.password({
            message: "Enter password",
        })

        if (p.isCancel(password)) {
            p.cancel('Operation cancelled.');
            process.exit(0);
        }

        const result = await resetPasswordUsecase({
            username: username as string,
            password: password as string,
            context: {
                user: {
                    id: 1,
                    username: "superadmin",
                    email: "superadmin@superadmin.com"
                },
                permissions: [CorePermissions.UsersUpdate]
            }
        })

        if (result) {
            console.log("Password reset successfully")
        } else {
            console.log("Password reset failed")
        }

    }

}
