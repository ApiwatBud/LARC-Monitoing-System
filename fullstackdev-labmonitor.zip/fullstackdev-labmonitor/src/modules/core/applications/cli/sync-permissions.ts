/*
This function will scan all permissions from all modules and sync them to the database.
It will create new permissions if they don't exist and update existing permissions if they do.
*/

import 'dotenv/config';
import { SyncPermissions } from "../usecases/permissions/syncPermissions";
import { CoreIoC } from '../../ioc';
import { RegisteredModules } from "../../../../registry";

export async function main() {

    const allPermissions: string[] = [];
    // Use RegisteredModules instead of file scanning for robustness
    for (const mod of RegisteredModules) {
        if (!mod.permissions) continue;

        console.log(`Processing permissions for module: ${mod.name}`);

        let perms: string[] = [];
        if (Array.isArray(mod.permissions)) {
            perms = mod.permissions;
        } else {
            // It's a Record<string, string>, get values
            perms = Object.values(mod.permissions);
        }

        // Filter out pseudo-permissions
        const cleanPerms = perms.filter(p => !['self', 'guest', 'anyone'].includes(p));

        console.log(`  Found ${cleanPerms.length} permissions`);
        allPermissions.push(...cleanPerms);
    }

    console.log(`Found ${allPermissions.length} unique permissions across modules`);

    // De-duplicate just in case
    const uniquePermissions = [...new Set(allPermissions)];

    const syncPermissionsUsecase = SyncPermissions({
        permissionRepository: CoreIoC.decorator.permissionRepository
    })

    const result = await syncPermissionsUsecase({
        permissions: uniquePermissions
    })

    if (result) {
        console.log("Permissions synced successfully")
    } else {
        console.log("Permissions sync failed")
    }
}
