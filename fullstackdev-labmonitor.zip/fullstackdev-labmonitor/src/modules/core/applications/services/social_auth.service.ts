import { Google, Line, MicrosoftEntraId } from "arctic";
import { ISocialProviderRepository } from "../../../config/persistents/pg/repositories/social_provider.pg.repository";
import { SocialProviderEntity } from "../../../config/domains/entities/social_provider.entity";

export interface ISocialUserProfile {
    id: string;
    email?: string;
    name?: string;
    avatar?: string;
    provider: string;
}

export class SocialAuthService {
    constructor(
        private socialProviderRepo: ISocialProviderRepository,
    ) { }

    private getProviderInstance(config: SocialProviderEntity) {
        // Use a default callback URL if not specified, but usually it should be matched with what's registered
        // validation logic often requires the exact same redirect URI used to generate the link
        const redirectUri = config.redirectUri || `${process.env.APP_URL}/api/auth/social/${config.provider}/callback`;

        switch (config.provider) {
            case 'google':
                return new Google(config.clientId, config.clientSecret, redirectUri);
            case 'line':
                return new Line(config.clientId, config.clientSecret, redirectUri);
            case 'microsoft':
                return new MicrosoftEntraId(process.env.MICROSOFT_TENANT_ID || "common", config.clientId, config.clientSecret, redirectUri);
            default:
                throw new Error(`Unsupported provider: ${config.provider}`);
        }
    }

    async getAuthorizationUrl(providerName: string, state: string, codeVerifier?: string) {
        const config = await this.socialProviderRepo.findByProvider(providerName);
        if (!config || !config.isActive) throw new Error("Provider not found or inactive");

        const provider = this.getProviderInstance(config);
        const scopes = config.scopes.length > 0 ? config.scopes : ["openid", "profile", "email"];

        let url: URL;

        try {
            if (provider instanceof Google) {
                url = await provider.createAuthorizationURL(state, codeVerifier!, scopes);
            } else if (provider instanceof Line) {
                url = await provider.createAuthorizationURL(state, codeVerifier!, scopes);
            } else if (provider instanceof MicrosoftEntraId) {
                url = await provider.createAuthorizationURL(state, codeVerifier!, scopes);
            } else {
                throw new Error("Provider implementation pending");
            }
            return url;
        } catch (e) {
            console.error("Error creating auth URL", e);
            throw e;
        }
    }

    async validateCallback(providerName: string, code: string, codeVerifier?: string) {
        const config = await this.socialProviderRepo.findByProvider(providerName);
        if (!config) throw new Error("Provider not found");

        const providerInstance = this.getProviderInstance(config);
        let tokens: any;

        try {
            if (providerInstance instanceof Google) {
                tokens = await providerInstance.validateAuthorizationCode(code, codeVerifier!);
            } else if (providerInstance instanceof Line) {
                tokens = await providerInstance.validateAuthorizationCode(code, codeVerifier!);
            } else if (providerInstance instanceof MicrosoftEntraId) {
                tokens = await providerInstance.validateAuthorizationCode(code, codeVerifier!);
            }
        } catch (e) {
            console.error("Token validation failed", e);
            throw new Error("Invalid code or provider error");
        }

        return tokens;
    }

    async getUserProfile(providerName: string, accessToken: string): Promise<ISocialUserProfile | null> {
        let profile: any = {};

        try {
            if (providerName === 'google') {
                const response = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
                    headers: { Authorization: `Bearer ${accessToken}` }
                });
                profile = await response.json();
                return {
                    id: profile.sub,
                    email: profile.email,
                    name: profile.name,
                    avatar: profile.picture,
                    provider: providerName
                };
            } else if (providerName === 'line') {
                const response = await fetch("https://api.line.me/v2/profile", {
                    headers: { Authorization: `Bearer ${accessToken}` }
                });
                profile = await response.json();
                // Line email requires separate API call/scope if strictly needed, or decoded from ID token
                // For simplicity, we stick to profile. 
                return {
                    id: profile.userId,
                    name: profile.displayName,
                    avatar: profile.pictureUrl,
                    provider: providerName
                }
            } else if (providerName === 'microsoft') {
                const response = await fetch("https://graph.microsoft.com/v1.0/me", {
                    headers: { Authorization: `Bearer ${accessToken}` }
                });
                profile = await response.json();
                return {
                    id: profile.id,
                    email: profile.mail || profile.userPrincipalName,
                    name: profile.displayName,
                    provider: providerName
                }
            }
        } catch (e) {
            console.error("Error fetching user profile", e);
        }

        return null;
    }
}
