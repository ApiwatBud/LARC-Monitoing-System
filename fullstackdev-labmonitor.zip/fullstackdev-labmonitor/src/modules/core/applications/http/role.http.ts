import { Elysia } from "elysia";
import { PaginateQueryDto, TPaginateQuery } from "../../../../common/types";
import { RoleEntity } from "../../domains/entities/role.entity";
import { CoreIoC } from "../../ioc";
import { RoleWithPermissionsCreateDto, RoleWithPermissionsUpdateDto } from "../dtos/role.aggs.dto";
import { CreateRoleWithPermissions } from "../usecases/roles/createRole";
import { DeleteRole } from "../usecases/roles/deleteRole";
import { GetRoleWithPermissions } from "../usecases/roles/getRole";
import { GetRoles } from "../usecases/roles/getRoles";
import { InitializeRoles } from "../usecases/roles/initializeRoles";
import { PaginateRole } from "../usecases/roles/paginateRole";
import { UpdateRoleWithPermissions } from "../usecases/roles/updateRole";

import { AuthMiddleware } from "./middlewares/auth.middleware";
import { logger } from "../../../../common/utils/logger";

export const RoleUseCase = new Elysia()
    .use(CoreIoC)
    .decorate("initializeRoles", InitializeRoles({ roleRepository: CoreIoC.decorator.roleRepository }))
    .decorate("getRoles", GetRoles({ roleRepository: CoreIoC.decorator.roleRepository }))
    .decorate("paginateRole", PaginateRole({ roleRepository: CoreIoC.decorator.roleRepository }))
    .decorate("createRole", CreateRoleWithPermissions({
        roleRepository: CoreIoC.decorator.roleRepository,
        permissionRoleRepository: CoreIoC.decorator.permissionRoleRepository,
        roleModuleRepository: CoreIoC.decorator.roleModuleRepository
    }))
    .decorate("updateRole", UpdateRoleWithPermissions({
        roleRepository: CoreIoC.decorator.roleRepository,
        permissionRoleRepository: CoreIoC.decorator.permissionRoleRepository,
        roleModuleRepository: CoreIoC.decorator.roleModuleRepository
    }))
    .decorate("deleteRole", DeleteRole({ roleRepository: CoreIoC.decorator.roleRepository }))
    .decorate("getRole", GetRoleWithPermissions({
        roleRepository: CoreIoC.decorator.roleRepository,
        permissionRoleRepository: CoreIoC.decorator.permissionRoleRepository,
        roleModuleRepository: CoreIoC.decorator.roleModuleRepository
    }))

RoleUseCase.decorator.initializeRoles()

export const RoleHttp = new Elysia({
    detail: {
        tags: ['api.roles']
    }
})
    .use(RoleUseCase)
    .use(AuthMiddleware)
    .group("/roles", (app) => app
        .get("", ({ getRoles, user, permissions }) => getRoles({ context: { user, permissions: permissions as any || [] } }), {
            permission: ["roles:read"]
        })
        .post("/filter", async ({ body, paginateRole, user, permissions }) => {
            const query = PaginateQueryDto.parse(body) as TPaginateQuery<RoleEntity>
            const result = await paginateRole({ ...query, context: { user, permissions: permissions as any || [] } })
            return result

        }, {
            body: PaginateQueryDto,
            permission: ["roles:read"]
        })
        .get(":id", async ({ params, getRole, user, permissions }) => {
            const id = Number(params.id)
            return await getRole({ id, context: { user, permissions: permissions as any || [] } })
        }, {
            permission: ["roles:read"]
        })
        .post("", async ({ body, createRole, user, permissions }) => {
            logger.info({ action: 'create_role', role_name: body.name, performed_by: user?.email }, `Creating role ${body.name}`);
            const result = await createRole({ dto: body, context: { user, permissions: permissions as any || [] } })
            logger.info({ action: 'create_role_success', role_name: body.name, result_id: result.id }, `Role ${body.name} created successfully`);
            return result
        }, {
            body: RoleWithPermissionsCreateDto,
            permission: ["roles:create"]
        })
        .put(":id", async ({ params, body, updateRole, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'update_role', target_id: id, role_name: body.name, performed_by: user?.email }, `Updating role ID ${id} (${body.name})`);
            const result = await updateRole({ id, dto: body, context: { user, permissions: permissions as any || [] } })
            logger.info({ action: 'update_role_success', target_id: id }, `Role ID ${id} updated successfully`);
            return result
        }, {
            body: RoleWithPermissionsUpdateDto,
            permission: ["roles:update"]
        })
        .delete(":id", async ({ params, deleteRole, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'delete_role', target_id: id, performed_by: user?.email }, `Deleting role ID ${id}`);
            const result = await deleteRole({ id, context: { user, permissions: permissions as any || [] } })
            logger.info({ action: 'delete_role_success', target_id: id }, `Role ID ${id} deleted successfully`);
            return result
        }, {
            permission: ["roles:delete"]
        })
    )
