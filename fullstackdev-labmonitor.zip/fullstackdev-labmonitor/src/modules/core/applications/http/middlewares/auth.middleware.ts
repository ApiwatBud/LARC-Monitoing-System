import { Elysia, status } from "elysia";
import { CoreIoC } from "../../../ioc";
import { AUTH_SESSION_EXPIRES_IN_DAYS, IS_DEV } from "../../../../../server_config";

export const AuthMiddleware = new Elysia({
    name: 'auth-middleware',
    cookie: {
        httpOnly: true,
        secure: !IS_DEV,
        sameSite: 'lax'
    }
})
    .use(CoreIoC)
    .resolve({ as: 'global' }, async ({
        cookie: { access_token, refresh_token, user_id, username, email, expires_at },
        headers,
        sessionRepository,
        userRepository,
        roleUserRepository,
        permissionRoleRepository,
        roleModuleRepository,
        ...rest
    }) => {
        // --- Device Token Auth ---
        const deviceToken = headers['x-device-token'] as string;
        if (deviceToken) {
            const deviceRepository = (rest as any).deviceRepository;
            if (deviceRepository) {
                const device = await deviceRepository.findByToken({ token: deviceToken });
                if (device) {
                    return {
                        user: {
                            id: undefined,
                            username: device.name,
                            email: `device_${device.id}@internal.system`,
                        },
                        permissions: ['labmonitor:ingest']
                    };
                }
            }
        }

        // --- Standard Session Auth ---
        let token = access_token?.value;
        let session = null;

        if (token && typeof token === 'string') {
            session = await sessionRepository.findById({ id: token });
        }

        if (!session || session.is_revoked || session.expires_at < new Date()) {
            const rt = refresh_token?.value;
            if (rt && typeof rt === 'string') {
                const existingSession = await sessionRepository.findByRefreshToken({ refreshToken: rt });
                if (existingSession && !existingSession.is_revoked) {
                    const user = await userRepository.findById({ id: existingSession.user_id });
                    if (user) {
                        // Revoke old session
                        await sessionRepository.delete({ id: existingSession.id });

                        // Create new session
                        const newToken = crypto.randomUUID();
                        const newRefreshToken = crypto.randomUUID();
                        const lastActive = new Date();
                        const nextExpiresAt = new Date().setDate(new Date().getDate() + AUTH_SESSION_EXPIRES_IN_DAYS);

                        const newSessionEntity = {
                            id: newToken,
                            user_id: user.id,
                            refresh_token: newRefreshToken,
                            expires_at: new Date(nextExpiresAt),
                            created_at: lastActive,
                            is_revoked: false,
                            last_active: lastActive,
                        };

                        session = await sessionRepository.create({ session: newSessionEntity });

                        // Update cookies
                        access_token.value = session.id;
                        refresh_token.value = session.refresh_token;
                        user_id.value = user.id.toString();
                        username.value = user.username;
                        email.value = user.email;
                        expires_at.value = session.expires_at.toString();

                        token = session.id;
                    }
                }
            }
        }

        if (!session || session.is_revoked || session.expires_at < new Date()) {
            return {
                user: null,
                permissions: [] as string[]
            };
        }

        const user = await userRepository.findById({ id: session.user_id });

        if (!user) {
            return {
                user: null,
                permissions: [] as string[]
            };
        }

        // Update last active
        await sessionRepository.updateLastActive({ id: session.id });

        // Fetch user permissions through roles
        const roles = await roleUserRepository.findRolesByUserId({ id: user.id });
        const permissionPromises = roles.map((role: any) => permissionRoleRepository.findPermissionsByRoleId({ role_id: role.id }));
        const permissionSets = await Promise.all(permissionPromises);

        const modulePromises = roles.map((role: any) => roleModuleRepository.getModulesByRoleId({ roleId: role.id }));
        const moduleSets = await Promise.all(modulePromises);

        // Flatten permissions and remove duplicates
        const permissions = Array.from(new Set(permissionSets.flat().map((p: any) => p.name)));
        const modules = Array.from(new Set(moduleSets.flat().map((m: any) => m.key)));

        return {
            user,
            permissions,
            roles: roles.map((r: any) => r.name),
            modules
        };
    })
    .macro({
        permission: (names: string | string[]) => ({
            beforeHandle({ user, permissions, error }: any) {

                const required = Array.isArray(names) ? names : [names]
                // 1️⃣ guest‑only routes – no auth needed
                if (required.includes('guest')) return
                // 2️⃣ must be logged in
                if (!user) throw status(401, 'Unauthorized')
                // 2️⃣‑1 allow any authenticated user
                if (required.includes('anyone')) return
                // 3️⃣ does the user have at least one of the required perms?
                const hasPermission = required.some(p => permissions?.includes(p))
                if (hasPermission) return
                // 4️⃣ ownership check will be done later in the handler
                if (required.includes('role:self')) return
                if (user.username === 'superadmin') return
                // 5️⃣ nothing matched → reject
                throw status(403, 'Forbidden: You do not have permission')
            }
        })
    })
