import { Elysia } from "elysia";
import { AuthMiddleware } from "../../../core/applications/http/middlewares/auth.middleware";

export const SystemHttp = new Elysia({ prefix: '/system', detail: { tags: ['System'] } })
    .use(AuthMiddleware)
    .get('/status', async ({ getSystemStatus }) => {
        return await getSystemStatus({});
    }, {
        permission: ['system:read'],
        log: false
    });
