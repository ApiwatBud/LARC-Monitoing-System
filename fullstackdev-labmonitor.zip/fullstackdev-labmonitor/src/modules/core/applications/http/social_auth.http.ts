import { Elysia, redirect, t } from "elysia";
import { SocialLogin } from "../usecases/social_login.usecase";
import { SocialAuthService } from "../services/social_auth.service";
import { CoreIoC } from "../../ioc";
import { ConfigIoC } from "../../../config/ioc";
import { IS_DEV } from "../../../../server_config";
import { generateState, generateCodeVerifier } from "arctic";
import { ISocialProviderRepository } from "../../../config/persistents/pg/repositories/social_provider.pg.repository";

// Setup Dependencies
const socialProviderRepo = ConfigIoC.decorator.socialProviderRepository as ISocialProviderRepository;
const socialAccountRepo = CoreIoC.decorator.socialAccountRepository; // Need to register this in CoreIoC
const userRepo = CoreIoC.decorator.userRepository;
const sessionRepo = CoreIoC.decorator.sessionRepository; // Need to ensure this is exposed/registered

// Service
const socialAuthService = new SocialAuthService(socialProviderRepo);

// Use Case
const socialLogin = SocialLogin(
    socialAuthService,
    userRepo,
    socialAccountRepo,
    socialProviderRepo,
    sessionRepo
);

export const SocialAuthHttp = new Elysia({
    prefix: "/auth/social",
    cookie: {
        httpOnly: true,
        secure: !IS_DEV,
        sameSite: 'lax',
        path: '/'
    }
})
    .get("/providers", async () => {
        const providers = await socialProviderRepo.findAllActive();
        return providers.map(p => ({
            provider: p.provider,
            name: p.name
        }));
    })
    .get("/:provider/login", async ({ params: { provider }, set, cookie: { oauth_state, oauth_code_verifier } }) => {
        const state = generateState();
        const codeVerifier = generateCodeVerifier();

        try {
            const url = await socialAuthService.getAuthorizationUrl(provider, state, codeVerifier);

            oauth_state.value = state;
            oauth_state.maxAge = 60 * 10; // 10 min

            oauth_code_verifier.value = codeVerifier;
            oauth_code_verifier.maxAge = 60 * 10;

            return set.redirect = url.toString();
        } catch (e: any) {
            set.status = 400;
            return { error: e.message } as any;
        }
    })
    .get("/:provider/callback", async ({ params: { provider }, query, set, cookie: { user_id, username, email, access_token, refresh_token, expires_at, oauth_state, oauth_code_verifier } }) => {
        const code = query.code as string;
        const state = query.state as string;
        // Fix: Use destructured cookie values directly to resolve type inference issue
        const storedState = oauth_state.value as string;
        const storedCodeVerifier = oauth_code_verifier.value as string;

        if (!code || !state || !storedState || !storedCodeVerifier || state !== storedState) {
            set.status = 400;
            return { error: "Invalid state or code" };
        }

        try {
            const result = await socialLogin({
                provider,
                code,
                codeVerifier: storedCodeVerifier
            });

            // Set Session Cookies
            access_token.value = result.session.access_token;
            refresh_token.value = result.session.refresh_token;
            user_id.value = result.user.id!.toString();
            username.value = result.user.username;
            email.value = result.user.email;
            expires_at.value = result.session.expires_at.toISOString();

            // Clear OAuth cookies
            oauth_state.remove();
            oauth_code_verifier.remove();

            return redirect("/backoffice/dashboard"); // Or wherever
        } catch (e: any) {
            set.status = 500;
            return { error: "Authentication failed", details: e.message } as any;
        }
    });
