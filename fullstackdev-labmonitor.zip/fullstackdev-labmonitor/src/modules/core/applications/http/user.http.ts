import { Elysia } from "elysia";
import { PaginateQueryDto, TPaginateQuery } from "../../../../common/types";
import { UserEntity } from "../../domains/entities/user.entity";
import { CoreIoC } from "../../ioc";
import { UserCreateDtoWithRoles, UserUpdateDtoWithRoles } from "../dtos/user.dto";
import { CreateUserWithSyncRoles } from "../usecases/users/createUser";
import { DeleteUser } from "../usecases/users/deleteUser";
import { GetUserWithRoles } from "../usecases/users/getUser";
import { InitializeSuperadmin } from "../usecases/users/initializeSuperadmin";
import { PaginateUser } from "../usecases/users/paginateUser";
import { UpdateUserWithRoles } from "../usecases/users/updateUser";

import { AuthMiddleware } from "./middlewares/auth.middleware";
import { logger } from "../../../../common/utils/logger";

export const UserUseCase = new Elysia()
    .use(CoreIoC)
    .decorate("initializeSuperadmin", InitializeSuperadmin({
        userRepository: CoreIoC.decorator.userRepository,
        roleRepository: CoreIoC.decorator.roleRepository,
        roleUserRepository: CoreIoC.decorator.roleUserRepository
    }))
    .decorate("paginateUser", PaginateUser({
        userRepository: CoreIoC.decorator.userRepository
    }))
    .decorate("getUser", GetUserWithRoles({
        userRepository: CoreIoC.decorator.userRepository,
        roleUserRepository: CoreIoC.decorator.roleUserRepository
    }))
    .decorate("updateUser", UpdateUserWithRoles({
        userRepository: CoreIoC.decorator.userRepository,
        roleRepository: CoreIoC.decorator.roleRepository,
        roleUserRepository: CoreIoC.decorator.roleUserRepository
    }))
    .decorate("createUser", CreateUserWithSyncRoles({
        userRepository: CoreIoC.decorator.userRepository,
        roleUserRepository: CoreIoC.decorator.roleUserRepository
    }))
    .decorate("deleteUser", DeleteUser({
        userRepository: CoreIoC.decorator.userRepository,
    }))

UserUseCase.decorator.initializeSuperadmin()

export const UserHttp = new Elysia({
    detail: {
        tags: ['api.users']
    }
})
    .use(UserUseCase)
    .group("/users", (app) => app
        .use(AuthMiddleware)
        .get("", () => "list users", { permission: ["users:read"] })
        .post("/filter", async ({ body, paginateUser, user, permissions }) => {
            const query = PaginateQueryDto.parse(body) as TPaginateQuery<UserEntity>
            const result = await paginateUser({ ...query, context: { user, permissions: permissions as any || [] } })
            return result
        }, {
            body: PaginateQueryDto,
            permission: ["users:read"]
        })
        .get(":id", async ({ params, getUser, user, permissions }) => {
            const id = Number(params.id)
            const userResponse = await getUser({ id, context: { user, permissions: permissions as any || [] } })
            return userResponse
        }, {
            permission: ["users:read", "role:self"]
        })
        .post("", async ({ body, createUser, user, permissions }) => {
            logger.info({ action: 'create_user', target_email: body.email, performed_by: user?.email }, `Creating user ${body.email}`);
            const result = await createUser({
                dto: body,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'create_user_success', target_email: body.email, result_id: result.id }, `User ${body.email} created successfully`);
            return result
        }, {
            body: UserCreateDtoWithRoles,
            permission: ["users:create"]
        })
        .put(":id", async ({ params, body, updateUser, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'update_user', target_id: id, performed_by: user?.email }, `Updating user ID ${id}`);
            const result = await updateUser({
                id: id,
                userUpdateDtoWithRoles: {
                    ...body,
                    password: body.password ?? '',
                    password_confirmation: body.password_confirmation ?? '',
                    roles: body.roles
                },
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'update_user_success', target_id: id }, `User ID ${id} updated successfully`);
            return result
        }, {
            body: UserUpdateDtoWithRoles,
            permission: ["users:update", "role:self"]
        })
        .delete(":id", async ({ params, deleteUser, user: currentUser, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'delete_user', target_id: id, performed_by: currentUser?.email }, `Deleting user ID ${id}`);
            const user = await deleteUser({ id, context: { user: currentUser, permissions: permissions as any || [] } })
            logger.info({ action: 'delete_user_success', target_id: id }, `User ID ${id} deleted successfully`);
            return user
        }, {
            permission: ["users:delete"]
        })
    )
