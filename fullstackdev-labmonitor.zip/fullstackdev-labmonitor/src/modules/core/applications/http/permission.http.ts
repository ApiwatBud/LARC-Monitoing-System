import { Elysia } from "elysia";
import { PaginateQueryDto, TPaginateQuery } from "../../../../common/types";
import { PermissionEntity } from "../../domains/entities/permission.entity";
import { CorePermissions } from "../../domains/permissions";
import { CoreIoC } from "../../ioc";
import { CreatePermission } from "../usecases/permissions/createPermission";
import { DeletePermission } from "../usecases/permissions/deletePermission";
import { GetPermission } from "../usecases/permissions/getPermission";
import { GetPermissions } from "../usecases/permissions/getPermissions";
import { PaginatePermission } from "../usecases/permissions/paginatePermission";
import { UpdatePermission } from "../usecases/permissions/updatePermission";
import { AuthMiddleware } from "./middlewares/auth.middleware";


export const PermissionUseCase = new Elysia()
    .use(CoreIoC)
    .decorate("getPermissions", GetPermissions({ permissionRepository: CoreIoC.decorator.permissionRepository }))
    .decorate("paginatePermission", PaginatePermission({ permissionRepository: CoreIoC.decorator.permissionRepository }))
    .decorate("createPermission", CreatePermission({ permissionRepository: CoreIoC.decorator.permissionRepository }))
    .decorate("updatePermission", UpdatePermission({ permissionRepository: CoreIoC.decorator.permissionRepository }))
    .decorate("deletePermission", DeletePermission({ permissionRepository: CoreIoC.decorator.permissionRepository }))
    .decorate("getPermission", GetPermission({ permissionRepository: CoreIoC.decorator.permissionRepository }))

export const PermissionHttp = new Elysia({
    detail: {
        tags: ['api.permissions']
    }
})
    .use(PermissionUseCase)
    .use(AuthMiddleware)
    .group("/permissions", (app) => app
        .get("", ({ getPermissions }) => getPermissions({}), {
            permission: [CorePermissions.PermissionsRead]
        })
        .post("/filter", async ({ body, paginatePermission }) => {
            const query = PaginateQueryDto.parse(body) as TPaginateQuery<PermissionEntity>
            const result = await paginatePermission(query)
            return result

        }, {
            body: PaginateQueryDto,
            permission: [CorePermissions.PermissionsRead]
        })
        .get(":name", async ({ params, getPermission }) => {
            const name = params.name
            return await getPermission({ name })
        }, {
            permission: [CorePermissions.PermissionsRead]
        })
        /*
                .post("", async ({ body, createPermission, user }) => {
                    return await createPermission({ dto: body, userId: user?.id })
                }, {
                    body: PermissionCreateDto,
                    permission: [CorePermissions.PermissionsCreate]
                })
                .put(":name", async ({ params, body, updatePermission, user }) => {
                    const name = params.name
                    return await updatePermission({ name, dto: body, userId: user?.id })
                }, {
                    body: PermissionUpdateDto,
                    permission: [CorePermissions.PermissionsUpdate]
                })
                .delete(":name", async ({ params, deletePermission }) => {
                    const name = params.name
                    return await deletePermission({ name })
                }, {
                    permission: [CorePermissions.PermissionsDelete]
                })
        */
    )

