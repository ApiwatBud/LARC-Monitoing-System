import { Elysia } from "elysia";
import { CoreIoC } from "../../ioc";
import { LoginUseCase } from "../usecases/auth/login";
import { LogoutUseCase } from "../usecases/auth/logout";
import { UpdateUser } from "../usecases/users/updateUser";
import { loginDto, loginResponseDto } from "../dtos/auth.dto";
import { UserUpdateDto } from "../dtos/user.dto";
import z from "zod";
import { AuthMiddleware } from "./middlewares/auth.middleware";
import { IS_DEV } from "../../../../server_config";

export const AuthUseCase = new Elysia()
    .use(CoreIoC)
    .decorate("Login", LoginUseCase({
        userRepository: CoreIoC.decorator.userRepository,
        sessionRepository: CoreIoC.decorator.sessionRepository
    }))
    .decorate("Logout", LogoutUseCase({
        sessionRepository: CoreIoC.decorator.sessionRepository
    }))
    .decorate("UpdateProfile", UpdateUser({
        userRepository: CoreIoC.decorator.userRepository
    }))

export const AuthHttp = new Elysia({
    detail: {
        tags: ['api.auth']
    },
    cookie: {
        httpOnly: true,
        secure: !IS_DEV,
        sameSite: 'lax'
    }
})
    .use(AuthUseCase)
    .use(AuthMiddleware)
    .post("/login", async ({ body, Login, cookie: { user_id, username, email, access_token, refresh_token, expires_at } }) => {
        const result = await Login(body)

        access_token.value = result.session.access_token
        refresh_token.value = result.session.refresh_token
        user_id.value = result.user.id.toString()
        username.value = result.user.username
        email.value = result.user.email
        expires_at.value = result.session.expires_at.toString()


        return result
    }, {
        body: loginDto,
        permission: ["guest"],
        response: {
            200: loginResponseDto,
            401: z.object({
                message: z.string()
            })
        }
    })
    .post("/logout", async ({ Logout, cookie: { user_id, username, email, access_token, refresh_token, expires_at } }) => {
        const sessionId = access_token.value
        if (sessionId && typeof sessionId === 'string') {
            await Logout({ sessionId })
        }

        user_id.remove()
        username.remove()
        email.remove()
        access_token.remove()
        refresh_token.remove()
        expires_at.remove()

        return {
            message: "Logged out successfully"
        }
    }, {
        permission: ["anyone"]
    })
    .post('/me', async ({ user, permissions, roles, modules, cookie: { user_id, username, email, access_token, refresh_token, expires_at } }) => {
        if (!user) {
            user_id.remove()
            username.remove()
            email.remove()
            access_token.remove()
            refresh_token.remove()
            expires_at.remove()

            throw new Error("Unauthorized")
        }
        return {
            user,
            permissions,
            roles,
            modules,
        }
    }, {
        permission: ["anyone"]
    })
    .put('/me', async ({ user, body, UpdateProfile }) => {
        if (!user) throw new Error("Unauthorized")
        const result = await UpdateProfile({
            id: user.id!,
            userUpdateDto: body,
            context: {
                user: user,
                permissions: [] // Self update doesn't strictly require permissions via guard if checked otherwise, but satisfying interface
            }
        })
        return result
    }, {
        body: UserUpdateDto,
        permission: ["anyone"]
    })
