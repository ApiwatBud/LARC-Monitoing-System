import Elysia from "elysia";
import { CoreIoC } from "./ioc";
import { RoleHttp } from "./applications/http/role.http";
import { UserHttp } from "./applications/http/user.http";
import { AuthHttp } from "./applications/http/auth.http";
import { PermissionHttp } from "./applications/http/permission.http";
import { SocialAuthHttp } from "./applications/http/social_auth.http";
import { ConfigIoC } from "../config/ioc";

export const CoreModule = new Elysia({
    detail: {
        tags: ["core"]
    }
}).use(CoreIoC)
    .use(RoleHttp)
    .use(UserHttp)
    .use(AuthHttp)
    .use(PermissionHttp)
    .use(SocialAuthHttp)


