import { FiGrid, FiUser } from "react-icons/fi";
import { IModuleMeta } from "../config/domains/entities/module.meta";
import { CorePermissions } from "./domains/permissions";
import MyWorkspaceRoutes from "../../public/pages/backoffice/myworkspace/routes";

export const CoreMeta: IModuleMeta = {
    key: "myworkspace",
    name: "My Workspace",
    description: "Manage your personal profile, settings, and workspace preferences.",
    version: "1.0.0",
    icon: FiGrid,
    // Explicit 'self' permission for workspace access
    permissions: {
        self: 'self',
        ...CorePermissions
    },
    menu: () => ({
        key: "myworkspace",
        name: "My Workspace",
        description: "Manage your personal profile, settings, and workspace preferences.",
        color: "emerald",
        icon: FiGrid,
        children: [
            {
                key: "profile",
                name: "Edit Profile",
                icon: FiUser,
                route: "/backoffice/myworkspace/profile"
            }
        ],
        permissions: ['self'],
    }),
    routes: MyWorkspaceRoutes
};
