import { RoleEntity } from "./role.entity";
import { UserEntity } from "./user.entity";

export type UserEntityWithRoles = UserEntity & {
    roles: RoleEntity[];
}