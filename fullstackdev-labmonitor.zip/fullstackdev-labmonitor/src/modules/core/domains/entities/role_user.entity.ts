import { RoleEntity } from "./role.entity";
import { UserEntity } from "./user.entity";

export type RoleUserEntity = {
    role_id: RoleEntity['id'];
    user_id: UserEntity['id'];
}

export type UserWithRolesEntity = UserEntity & {
    roles: RoleEntity[];
}