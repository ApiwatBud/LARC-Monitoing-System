import { PermissionEntity } from "./permission.entity";
import { RoleEntity } from "./role.entity";

export type PermissionRoleEntity = {
    permission_name: PermissionEntity['name'];
    role_id: RoleEntity['id'];
}
