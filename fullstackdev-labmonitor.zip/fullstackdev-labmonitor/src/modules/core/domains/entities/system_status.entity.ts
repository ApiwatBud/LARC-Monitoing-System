export type SystemStatusEntity = {
    os: {
        platform: string;
        release: string;
        arch: string;
        uptime: number;
        hostname: string;
    };
    cpu: {
        model: string;
        speed: number;
        cores: number;
        loadAvg: number[];
    };
    memory: {
        total: number;
        free: number;
        used: number;
        percentage: number;
    };
    process: {
        memoryUsage: NodeJS.MemoryUsage;
        uptime: number;
        version: string;
    };
    timestamp: Date;
}
