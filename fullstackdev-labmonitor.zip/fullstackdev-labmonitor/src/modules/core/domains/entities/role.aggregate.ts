import { ModuleEntity } from "../../../config/domains/entities/module.enity";
import { PermissionEntity } from "./permission.entity";
import { RoleEntity } from "./role.entity";

export type RoleWithPermissionsEntity = RoleEntity & {
    permissions: PermissionEntity[];
    modules: ModuleEntity[];
}
