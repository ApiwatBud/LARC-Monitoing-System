import { BaseEntity } from "../../../../common/domains/baseEntity";

export type RoleEntity = {
    name: string;
    description?: string;
} & BaseEntity


//RoleCreateEntity is Role Entity without BaseEntity
export type RoleCreateEntity = Omit<RoleEntity, keyof BaseEntity>
export type RoleUpdateEntity = Partial<Omit<RoleEntity, keyof BaseEntity>>