export type RoleModuleEntity = {
    roleId: number;
    moduleId: number;
}
