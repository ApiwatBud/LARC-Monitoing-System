import { BaseEntity } from "../../../../common/domains/baseEntity";

export type UserEntity = {
    username: string;
    email: string;
    password: string;
} & BaseEntity

export type UserCreateEntity = Omit<UserEntity, keyof BaseEntity> & {
    password_confirmation: string;
}

export type UserUpdateEntity = Partial<Omit<UserEntity, keyof BaseEntity | "password" | "password_confirmation">> & Partial<{
    password?: string | null;
    password_confirmation?: string | null;
}>