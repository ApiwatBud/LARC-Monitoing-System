import { AuditEntity, JustEntity, TimestampEntity } from "../../../../common/domains/baseEntity";

export type PermissionEntity = JustEntity & {
    name: string;
    description?: string;
} & TimestampEntity & AuditEntity


//PermissionCreateEntity is Permission Entity without BaseEntity and AuditEntity
export type PermissionCreateEntity = Omit<PermissionEntity, keyof TimestampEntity | keyof AuditEntity>
export type PermissionUpdateEntity = Partial<Omit<PermissionEntity, keyof TimestampEntity | keyof AuditEntity>>