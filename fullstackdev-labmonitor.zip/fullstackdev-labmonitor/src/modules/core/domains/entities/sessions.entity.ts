export type SessionEntity = {
    id: string; // UUID
    user_id: number;
    refresh_token: string;
    ip_address?: string | null;
    user_agent?: string | null;
    is_revoked: boolean;
    expires_at: Date;
    created_at: Date;
    last_active: Date;
}

export type SessionCreateEntity = Omit<SessionEntity, "created_at">