import { BaseEntity } from "../../../../common/domains/baseEntity";

export type SocialAccountEntity = {
    userId: number;
    providerId: number; // Reference to SocialProviderEntity.id
    socialId: string; // The unique ID from the provider (e.g., 'sub')
    email?: string;
    name?: string;
    avatar?: string;
    accessToken?: string;
    refreshToken?: string;
    expiresAt?: Date;
} & BaseEntity
