import { AnyTransaction } from "../../../../common/persistents/types";
import { ModuleEntity } from "../../../config/domains/entities/module.enity";

export interface IRoleModuleRepository {
    getModulesByRoleId(props: { roleId: number, transaction?: AnyTransaction }): Promise<ModuleEntity[]>;
    syncModules(props: { roleId: number, moduleKeys: string[], transaction?: AnyTransaction }): Promise<void>;
}
