import { AnyTransaction } from "../../../../common/persistents/types";
import { ITransactionalRepository } from "../../../../common/repositories/repository.interface";
import { RoleEntity } from "../entities/role.entity";

export interface IRoleRepository extends ITransactionalRepository<RoleEntity> {
    findByName(props: { name: string, transaction?: AnyTransaction }): Promise<RoleEntity | null>;
}
