import { AnyTransaction } from "../../../../common/persistents/types";
import { AuditEntity, TimestampEntity } from "../../../../common/domains/baseEntity";
import { TPaginateQuery, TPaginateResult } from "../../../../common/types";
import { PermissionEntity } from "../entities/permission.entity";


//no soft delete
export interface IPermissionRepository {
    create(props: { entity: Omit<PermissionEntity, keyof TimestampEntity | keyof AuditEntity>, transaction?: AnyTransaction, userId?: number }): Promise<PermissionEntity>;
    update(props: { name: PermissionEntity['name'], entity: Partial<Omit<PermissionEntity, keyof TimestampEntity | keyof AuditEntity>>, transaction?: AnyTransaction, userId?: number }): Promise<PermissionEntity>;
    delete(props: { name: PermissionEntity['name'], transaction?: AnyTransaction }): Promise<PermissionEntity>;
    findById(props: { name: PermissionEntity['name'], transaction?: AnyTransaction }): Promise<PermissionEntity | null>;
    findAll(props?: { transaction?: AnyTransaction }): Promise<PermissionEntity[]>;
    paginate(props: { query: TPaginateQuery<PermissionEntity>, transaction?: AnyTransaction }): Promise<TPaginateResult<PermissionEntity>>;

    transaction<ANY>(callback: (transaction: AnyTransaction) => Promise<ANY>): Promise<ANY>;
}
