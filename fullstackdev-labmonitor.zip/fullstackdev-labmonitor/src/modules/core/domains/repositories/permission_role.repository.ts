import { AnyTransaction } from "../../../../common/persistents/types";
import { PermissionEntity } from "../entities/permission.entity";
import { PermissionRoleEntity } from "../entities/permission_role.entity";


//no soft delete
export interface IPermissionRoleRepository {
    syncPermissions(props: { id: number, permissions: string[] | undefined, transaction: AnyTransaction }): Promise<PermissionEntity[]>;

    create(props: { entity: PermissionRoleEntity, transaction?: AnyTransaction }): Promise<PermissionRoleEntity>;
    delete(props: { permission_name: PermissionRoleEntity['permission_name'], role_id: PermissionRoleEntity['role_id'], transaction?: AnyTransaction }): Promise<PermissionRoleEntity>;
    findById(props: { permission_name: PermissionRoleEntity['permission_name'], role_id: PermissionRoleEntity['role_id'], transaction?: AnyTransaction }): Promise<PermissionRoleEntity | null>;
    findAll(props?: { transaction?: AnyTransaction }): Promise<PermissionRoleEntity[]>;
    findByPermissionName(props: { permission_name: PermissionRoleEntity['permission_name'], transaction?: AnyTransaction }): Promise<PermissionRoleEntity[]>;
    findByRoleId(props: { role_id: PermissionRoleEntity['role_id'], transaction?: AnyTransaction }): Promise<PermissionRoleEntity[]>;
    deleteByPermissionName(props: { permission_name: PermissionRoleEntity['permission_name'], transaction?: AnyTransaction }): Promise<void>;
    deleteByRoleId(props: { role_id: PermissionRoleEntity['role_id'], transaction?: AnyTransaction }): Promise<void>;

    findPermissionsByRoleId(props: { role_id: PermissionRoleEntity['role_id'], transaction?: AnyTransaction }): Promise<PermissionEntity[]>;
}
