import { ITransactionalRepository } from "../../../../common/repositories/repository.interface";
import { UserEntity } from "../entities/user.entity";

export interface IUserRepository extends ITransactionalRepository<UserEntity> {
    findByUsername(props: { username: string, transaction?: any }): Promise<UserEntity | null>;
    findByEmail(props: { email: string, transaction?: any }): Promise<UserEntity | null>;
}
