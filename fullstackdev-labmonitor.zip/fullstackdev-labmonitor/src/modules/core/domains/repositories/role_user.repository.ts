import { LibSQLDatabase } from "drizzle-orm/libsql";
import { RoleUserEntity } from "../entities/role_user.entity";
import { RoleEntity } from "../entities/role.entity";
import { AnySqliteTransaction, AnyTransaction } from "../../../../common/persistents/types";


//no soft delete
export interface IRoleUserRepository {
    syncRoles(props: { user_id: number, userSelectedRoles: number[], transaction?: AnyTransaction }): Promise<RoleUserEntity[]>;
    findRolesByUserId(props: { id: number, transaction?: AnyTransaction }): Promise<RoleEntity[]>;

    create(props: { entity: RoleUserEntity, transaction?: AnyTransaction }): Promise<RoleUserEntity>;
    delete(props: { user_id: RoleUserEntity['user_id'], role_id: RoleUserEntity['role_id'], transaction?: AnyTransaction }): Promise<RoleUserEntity>;
    findById(props: { user_id: RoleUserEntity['user_id'], role_id: RoleUserEntity['role_id'], transaction?: AnyTransaction }): Promise<RoleUserEntity | null>;
    findAll(props?: { transaction?: AnyTransaction }): Promise<RoleUserEntity[]>;
    findByUserId(props: { user_id: RoleUserEntity['user_id'], transaction?: AnyTransaction }): Promise<RoleUserEntity[]>;
    findByRoleId(props: { role_id: RoleUserEntity['role_id'], transaction?: AnyTransaction }): Promise<RoleUserEntity[]>;
    deleteByUserId(props: { user_id: RoleUserEntity['user_id'], transaction?: AnyTransaction }): Promise<void>;
    deleteByRoleId(props: { role_id: RoleUserEntity['role_id'], transaction?: AnyTransaction }): Promise<void>;
}
