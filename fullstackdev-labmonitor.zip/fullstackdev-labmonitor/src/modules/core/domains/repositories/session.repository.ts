import { AnyTransaction } from "../../../../common/persistents/types"
import { SessionEntity } from "../entities/sessions.entity"

export interface ISessionRepository {
    create(props: { session: SessionEntity, transaction?: AnyTransaction }): Promise<SessionEntity>
    delete(props: { id: string, transaction?: AnyTransaction }): Promise<SessionEntity>
    findByRefreshToken(props: { refreshToken: string, transaction?: AnyTransaction }): Promise<SessionEntity | null>
    findByUserId(props: { userId: number, transaction?: AnyTransaction }): Promise<SessionEntity[]>
    findById(props: { id: string, transaction?: AnyTransaction }): Promise<SessionEntity | null>

    updateLastActive(props: { id: string, transaction?: AnyTransaction }): Promise<SessionEntity>
}