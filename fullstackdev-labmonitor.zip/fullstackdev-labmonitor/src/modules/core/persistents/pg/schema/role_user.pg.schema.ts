import { integer, pgTable, primaryKey } from "drizzle-orm/pg-core";
import { rolesTable } from "./role.pg.schema";
import { usersTable } from "./user.pg.schema";
import { RoleUserEntity } from "../../../domains/entities/role_user.entity";

export const roleUserTable = pgTable("role_user", {
    role_id: integer("role_id").notNull().references(() => rolesTable.id),
    user_id: integer("user_id").notNull().references(() => usersTable.id),
}, (table) => [
    primaryKey({ columns: [table.role_id, table.user_id] })
]) satisfies Record<keyof RoleUserEntity, any>;
