import { integer, pgTable, primaryKey, text } from "drizzle-orm/pg-core";
import { permissionsTable } from "./permission.pg.schema";
import { rolesTable } from "./role.pg.schema";
import { PermissionRoleEntity } from "../../../domains/entities/permission_role.entity";

export const permissionRoleTable = pgTable("permission_role", {
    permission_name: text("permission_name").notNull().references(() => permissionsTable.name),
    role_id: integer("role_id").notNull().references(() => rolesTable.id),
}, (table) => [
    primaryKey({ columns: [table.permission_name, table.role_id] })
]) satisfies Record<keyof PermissionRoleEntity, any>;
