import { integer, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { PermissionEntity } from "../../../domains/entities/permission.entity";
import { AuditorName } from "../../../../../common/persistents/types";

export const permissionsTable = pgTable("permissions", {
    name: varchar("name").primaryKey(),
    description: text("description"),
    createdAt: timestamp("created_at").notNull(),
    updatedAt: timestamp("updated_at").notNull(),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}) satisfies Record<keyof Omit<PermissionEntity, AuditorName>, any>;
