import { integer, pgTable, primaryKey } from "drizzle-orm/pg-core";
import { rolesTable } from "./role.pg.schema";
import { modulesTable } from "../../../../config/persistents/pg/schema/module.pg.schema";
import { RoleModuleEntity } from "../../../domains/entities/role_module.entity";

export const roleModulesTable = pgTable("role_modules", {
    roleId: integer("role_id").notNull().references(() => rolesTable.id, { onDelete: 'cascade' }),
    moduleId: integer("module_id").notNull().references(() => modulesTable.id, { onDelete: 'cascade' }),
}, (table) => [
    primaryKey({ columns: [table.roleId, table.moduleId] })
]) satisfies Record<keyof RoleModuleEntity, any>;
