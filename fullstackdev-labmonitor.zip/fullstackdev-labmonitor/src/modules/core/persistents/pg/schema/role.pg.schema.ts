import { isNull } from "drizzle-orm";
import { integer, pgTable, serial, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";
import { RoleEntity } from "../../../domains/entities/role.entity";
import { AuditorName } from "../../../../../common/persistents/types";

export const rolesTable = pgTable("roles", {
    id: serial("id").primaryKey(),
    name: varchar("name").notNull(),
    description: text("description"),
    createdAt: timestamp("created_at").notNull(),
    updatedAt: timestamp("updated_at").notNull(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}, (table) => [
    uniqueIndex("roles_name_idx1").on(table.name).where(isNull(table.deletedAt)),
]) satisfies Record<keyof Omit<RoleEntity, AuditorName>, any>;
