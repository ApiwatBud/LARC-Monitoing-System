import { isNull } from "drizzle-orm";
import { integer, pgTable, serial, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";
import { UserEntity } from "../../../domains/entities/user.entity";
import { AuditorName } from "../../../../../common/persistents/types";

export const usersTable = pgTable("users", {
    id: serial("id").primaryKey(),
    username: varchar("username").notNull(),
    email: varchar("email").notNull(),
    password: varchar("password").notNull(),
    createdAt: timestamp("created_at").notNull(),
    updatedAt: timestamp("updated_at").notNull(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}, (table) => [
    uniqueIndex("users_username_idx").on(table.username).where(isNull(table.deletedAt)),
    uniqueIndex("users_email_idx").on(table.email).where(isNull(table.deletedAt)),
]) satisfies Record<keyof Omit<UserEntity, AuditorName>, any>;
