import { integer, pgTable, serial, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";
import { AuditorName } from "../../../../../common/persistents/types";
import { usersTable } from "./user.pg.schema";
import { socialProvidersTable } from "../../../../config/persistents/pg/schema/social_provider.pg.schema"; // Cross-module reference
import { SocialAccountEntity } from "../../../domains/entities/social_account.entity";

export const socialAccountsTable = pgTable("social_accounts", {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => usersTable.id, { onDelete: 'cascade' }).notNull(),
    providerId: integer("provider_id").references(() => socialProvidersTable.id, { onDelete: 'cascade' }).notNull(),
    socialId: varchar("social_id", { length: 255 }).notNull(),
    email: varchar("email", { length: 255 }),
    name: varchar("name", { length: 255 }),
    avatar: text("avatar"),
    accessToken: text("access_token"),
    refreshToken: text("refresh_token"),
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: serial("created_by"),
    updatedBy: serial("updated_by"),
}, (table) => [
    // Ensure 1 user can only have 1 account per provider CONFIG
    uniqueIndex("social_accounts_user_provider_idx").on(table.userId, table.providerId),
    // Ensure social ID is unique per provider CONFIG
    uniqueIndex("social_accounts_provider_social_id_idx").on(table.providerId, table.socialId),
]) satisfies Record<keyof Omit<SocialAccountEntity, AuditorName>, any>;
