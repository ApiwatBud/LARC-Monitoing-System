import { boolean, integer, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { SessionEntity } from "../../../domains/entities/sessions.entity";

export const sessionTables = pgTable("sessions", {
    id: varchar("id").primaryKey(),
    user_id: integer("user_id").notNull(),
    refresh_token: varchar("refresh_token").notNull(),
    ip_address: varchar("ip_address"),
    user_agent: varchar("user_agent"),
    created_at: timestamp("created_at").notNull(),
    expires_at: timestamp("expires_at").notNull(),
    is_revoked: boolean("is_revoked").notNull(),
    last_active: timestamp("last_active"),
} satisfies Record<keyof SessionEntity, any>)
