import { eq, and } from "drizzle-orm";
import { PostgresJsDatabase } from "drizzle-orm/postgres-js";
import { SocialAccountEntity } from "../../../domains/entities/social_account.entity";
import { socialAccountsTable } from "../schema/social_account.pg.schema";

export interface ISocialAccountRepository {
    create(account: SocialAccountEntity): Promise<SocialAccountEntity | null>;
    findByProviderAndSocialId(providerId: number, socialId: string): Promise<SocialAccountEntity | null>;
    findByUserId(userId: number): Promise<SocialAccountEntity[]>;
    delete(id: number): Promise<boolean>;
}

export const SocialAccountPgRepository = (db: PostgresJsDatabase): ISocialAccountRepository => {
    return {
        async create(account: SocialAccountEntity) {
            const payload = { ...account } as any;
            if (payload.createdBy === null) delete payload.createdBy;
            if (payload.updatedBy === null) delete payload.updatedBy;
            const result = await db.insert(socialAccountsTable).values(payload).returning();
            return result[0] ? result[0] as SocialAccountEntity : null;
        },
        async findByProviderAndSocialId(providerId: number, socialId: string) {
            const result = await db
                .select()
                .from(socialAccountsTable)
                .where(and(
                    eq(socialAccountsTable.providerId, providerId),
                    eq(socialAccountsTable.socialId, socialId)
                ));
            return result[0] ? result[0] as SocialAccountEntity : null;
        },
        async findByUserId(userId: number) {
            const result = await db.select().from(socialAccountsTable).where(eq(socialAccountsTable.userId, userId));
            return result as SocialAccountEntity[];
        },
        async delete(id: number) {
            await db.delete(socialAccountsTable).where(eq(socialAccountsTable.id, id));
            return true;
        }
    };
};
