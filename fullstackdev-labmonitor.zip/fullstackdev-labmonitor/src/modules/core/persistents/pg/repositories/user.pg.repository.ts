import { and, eq, isNull } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { GenericPgTransactionalRepository } from "../../../../../common/repositories/generic.pg.repository";
import { UserEntity } from "../../../domains/entities/user.entity";
import { IUserRepository } from "../../../domains/repositories/user.repository";
import { usersTable } from "../schema/user.pg.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";
import { AnyPgTransaction } from "../../../../../common/persistents/types";


export class UserPgRepository extends GenericPgTransactionalRepository<UserEntity, typeof usersTable> implements IUserRepository {

    constructor(db: PgDatabase<any, any, any>) {
        super(db, "User", usersTable, "id", "deletedAt", usersTable);
    }

    async findByUsername(props: { username: string, transaction?: AnyPgTransaction }): Promise<UserEntity | null> {
        const { username, transaction } = props;
        const client = transaction || this.db;
        const result = await client.select().from(this.table).where(
            and(
                eq(this.table.username, username),
                isNull(this.table.deletedAt)
            )
        ).limit(1);
        return result[0] ? rowToEntity<UserEntity>(result[0]) : null;
    }

    async findByEmail(props: { email: string, transaction?: AnyPgTransaction }): Promise<UserEntity | null> {
        const { email, transaction } = props;
        const client = transaction || this.db;
        const result = await client.select().from(this.table)
            .where(and(
                eq(this.table.email, email),
                isNull(this.table.deletedAt)
            )).limit(1);
        return result[0] ? rowToEntity<UserEntity>(result[0]) : null;
    }
}
