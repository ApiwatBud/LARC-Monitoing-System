import { and, eq } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { IPermissionRoleRepository } from "../../../domains/repositories/permission_role.repository";
import { permissionRoleTable } from "../schema/permission_role.pg.schema";
import { PermissionRoleEntity } from "../../../domains/entities/permission_role.entity";
import { AnyPgTransaction } from "../../../../../common/persistents/types";
import { PermissionEntity } from "../../../domains/entities/permission.entity";
import { permissionsTable } from "../schema/permission.pg.schema";

export class PermissionRolePgRepository implements IPermissionRoleRepository {
    constructor(private readonly db: PgDatabase<any, any, any>) { }
    async syncPermissions(props: { id: number, permissions: string[] | undefined, transaction: AnyPgTransaction }): Promise<PermissionEntity[]> {
        const { id, permissions, transaction } = props;
        const client = transaction || this.db;
        await client.delete(permissionRoleTable).where(eq(permissionRoleTable.role_id, id));
        if (permissions && permissions.length > 0) {
            await client.insert(permissionRoleTable).values(permissions.map(permission => ({
                permission_name: permission,
                role_id: id,
            })));
        }
        return this.findPermissionsByRoleId({ role_id: id, transaction });
    }



    async create(props: { entity: PermissionRoleEntity, transaction?: AnyPgTransaction }): Promise<PermissionRoleEntity> {
        const { entity, transaction } = props;
        const client = transaction || this.db;
        const [row] = await client.insert(permissionRoleTable).values(entity).returning();
        return row;
    }
    async delete(props: { permission_name: PermissionRoleEntity['permission_name'], role_id: PermissionRoleEntity['role_id'], transaction?: AnyPgTransaction }): Promise<PermissionRoleEntity> {
        const { permission_name, role_id, transaction } = props;
        const client = transaction || this.db;
        const [row] = await client.delete(permissionRoleTable).where(and(eq(permissionRoleTable.permission_name, permission_name), eq(permissionRoleTable.role_id, role_id))).returning();
        if (!row) {
            throw new Error("Permission role not found");
        }
        return row;
    }
    async findById(props: { permission_name: PermissionRoleEntity['permission_name'], role_id: PermissionRoleEntity['role_id'], transaction?: AnyPgTransaction }): Promise<PermissionRoleEntity | null> {
        const { permission_name, role_id, transaction } = props;
        const client = transaction || this.db;
        const [row] = await client.select().from(permissionRoleTable).where(and(eq(permissionRoleTable.permission_name, permission_name), eq(permissionRoleTable.role_id, role_id))).limit(1);
        if (!row) {
            return null;
        }
        return row;
    }
    async findAll(props?: { transaction?: AnyPgTransaction }): Promise<PermissionRoleEntity[]> {
        const transaction = props?.transaction;
        const client = transaction || this.db;
        const rows = await client.select().from(permissionRoleTable);
        return rows;
    }
    async findByPermissionName(props: { permission_name: PermissionRoleEntity['permission_name'], transaction?: AnyPgTransaction }): Promise<PermissionRoleEntity[]> {
        const { permission_name, transaction } = props;
        const client = transaction || this.db;
        const rows = await client.select().from(permissionRoleTable).where(eq(permissionRoleTable.permission_name, permission_name));
        return rows;
    }
    async findByRoleId(props: { role_id: PermissionRoleEntity['role_id'], transaction?: AnyPgTransaction }): Promise<PermissionRoleEntity[]> {
        const { role_id, transaction } = props;
        const client = transaction || this.db;
        const rows = await client.select().from(permissionRoleTable).where(eq(permissionRoleTable.role_id, role_id));
        return rows;
    }
    async deleteByPermissionName(props: { permission_name: PermissionRoleEntity['permission_name'], transaction?: AnyPgTransaction }): Promise<void> {
        const { permission_name, transaction } = props;
        const client = transaction || this.db;
        await client.delete(permissionRoleTable).where(eq(permissionRoleTable.permission_name, permission_name));
    }
    async deleteByRoleId(props: { role_id: PermissionRoleEntity['role_id'], transaction?: AnyPgTransaction }): Promise<void> {
        const { role_id, transaction } = props;
        const client = transaction || this.db;
        await client.delete(permissionRoleTable).where(eq(permissionRoleTable.role_id, role_id));
    }

    async findPermissionsByRoleId(props: { role_id: PermissionRoleEntity["role_id"], transaction?: AnyPgTransaction }): Promise<PermissionEntity[]> {
        const { role_id, transaction } = props;
        const client = transaction || this.db;
        const rows = await client.select().from(permissionRoleTable).innerJoin(permissionsTable, eq(permissionRoleTable.permission_name, permissionsTable.name)).where(eq(permissionRoleTable.role_id, role_id));
        return rows.map(r => {
            return {
                ...r.permissions,
                createdAt: new Date(r.permissions.createdAt),
                updatedAt: new Date(r.permissions.updatedAt),
            } as PermissionEntity
        });
    }
}
