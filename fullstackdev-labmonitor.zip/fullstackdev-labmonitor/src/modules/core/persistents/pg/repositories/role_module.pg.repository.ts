import { eq, inArray } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { AnyPgTransaction } from "../../../../../common/persistents/types";
import { ModuleEntity } from "../../../../config/domains/entities/module.enity";
import { modulesTable } from "../../../../config/persistents/pg/schema/module.pg.schema";
import { IRoleModuleRepository } from "../../../domains/repositories/role_module.repository";
import { roleModulesTable } from "../schema/role_module.pg.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";

export class RoleModulePgRepository implements IRoleModuleRepository {
    private db: PgDatabase<any, any, any>;

    constructor(db: PgDatabase<any, any, any>) {
        this.db = db;
    }

    private getClient(transaction?: AnyPgTransaction) {
        return transaction || this.db;
    }

    async getModulesByRoleId(props: { roleId: number, transaction?: AnyPgTransaction }): Promise<ModuleEntity[]> {
        const { roleId, transaction } = props;
        const client = this.getClient(transaction);
        const result = await client
            .select({
                module: modulesTable
            })
            .from(roleModulesTable)
            .innerJoin(modulesTable, eq(roleModulesTable.moduleId, modulesTable.id))
            .where(eq(roleModulesTable.roleId, roleId));

        return result.map(r => rowToEntity<ModuleEntity>(r.module));
    }

    async syncModules(props: { roleId: number, moduleKeys: string[], transaction?: AnyPgTransaction }): Promise<void> {
        const { roleId, moduleKeys, transaction } = props;
        const client = this.getClient(transaction);

        await client.delete(roleModulesTable).where(eq(roleModulesTable.roleId, roleId));

        if (moduleKeys.length > 0) {
            const modules = await client
                .select({ id: modulesTable.id })
                .from(modulesTable)
                .where(inArray(modulesTable.key, moduleKeys));

            if (modules.length > 0) {
                await client.insert(roleModulesTable).values(
                    modules.map(module => ({
                        roleId,
                        moduleId: module.id
                    }))
                );
            }
        }
    }
}
