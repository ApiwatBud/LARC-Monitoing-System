import { eq } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { AnyPgTransaction } from "../../../../../common/persistents/types";
import { GenericPgTransactionalRepository, } from "../../../../../common/repositories/generic.pg.repository";
import { RoleEntity } from "../../../domains/entities/role.entity";
import { IRoleRepository } from "../../../domains/repositories/role.repository";
import { rolesTable } from "../schema/role.pg.schema";
import { usersTable } from "../schema/user.pg.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";

export class RolePgRepository extends GenericPgTransactionalRepository<RoleEntity, typeof rolesTable> implements IRoleRepository {

    constructor(db: PgDatabase<any, any, any>) {
        super(db, "Role", rolesTable, "id", "deletedAt", usersTable);
    }

    async findByName(props: { name: string, transaction?: AnyPgTransaction }): Promise<RoleEntity | null> {
        const { name, transaction } = props;
        const client = transaction || this.db
        const [result] = await client.select().from(this.table).where(eq(this.table.name, name)).limit(1);
        if (!result) {
            return null;
        }
        return rowToEntity<RoleEntity>(result);
    }
}
