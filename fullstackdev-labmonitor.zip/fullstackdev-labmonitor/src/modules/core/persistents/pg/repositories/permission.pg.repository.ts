import { eq } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { PermissionEntity } from "../../../domains/entities/permission.entity";
import { IPermissionRepository } from "../../../domains/repositories/permission.repository";
import { permissionsTable } from "../schema/permission.pg.schema";
import { usersTable } from "../schema/user.pg.schema";
import { AnyPgTransaction } from "../../../../../common/persistents/types";
import { AuditEntity, TimestampEntity } from "../../../../../common/domains/baseEntity";
import { simplePgEntityPaginateFunction } from "../../../../../common/repositories/generic.pg.repository";
import { TPaginateQuery, TPaginateResult } from "../../../../../common/types";
import { rowToTimestampEntity } from "../../../../../common/repositories/mapper";

export class PermissionPgRepository implements IPermissionRepository {

    constructor(private readonly db: PgDatabase<any, any, any>) {
    }

    async transaction<ANY>(callback: (transaction: AnyPgTransaction) => Promise<ANY>): Promise<ANY> {
        return this.db.transaction(async tx => {
            return await callback(tx);
        }) as Promise<ANY>;
    }

    async create(props: { entity: Omit<PermissionEntity, keyof TimestampEntity | keyof AuditEntity>, transaction?: AnyPgTransaction, userId?: number }): Promise<PermissionEntity> {
        const { entity, transaction, userId } = props;
        const client = (transaction || this.db);
        const now = new Date();
        const payload = {
            ...entity,
            createdAt: now,
            updatedAt: now,
            createdBy: userId ?? null,
            updatedBy: userId ?? null,
        } as any;
        const [row] = await client.insert(permissionsTable).values(payload).returning();
        return rowToTimestampEntity(row) as PermissionEntity;
    }

    async update(props: { name: PermissionEntity["name"], entity: Partial<Omit<PermissionEntity, keyof TimestampEntity | keyof AuditEntity>>, transaction?: AnyPgTransaction, userId?: number }): Promise<PermissionEntity> {
        const { name, entity, transaction, userId } = props;
        const client = (transaction || this.db);
        const payload = {
            ...entity,
            updatedAt: new Date(),
            updatedBy: userId ?? null,
        } as any;
        const [row] = await client.update(permissionsTable).set(payload).where(eq(permissionsTable.name, name)).returning();
        if (!row) {
            throw new Error("Permission not found");
        }
        return rowToTimestampEntity(row) as PermissionEntity;
    }

    async delete(props: { name: PermissionEntity["name"], transaction?: AnyPgTransaction }): Promise<PermissionEntity> {
        const { name, transaction } = props;
        const client = (transaction || this.db);
        const [row] = await client.delete(permissionsTable).where(eq(permissionsTable.name, name)).returning();
        if (!row) {
            throw new Error("Permission not found");
        }
        return rowToTimestampEntity(row) as PermissionEntity;
    }

    async findById(props: { name: PermissionEntity["name"], transaction?: AnyPgTransaction }): Promise<PermissionEntity | null> {
        const { name, transaction } = props;
        const client = (transaction || this.db);
        const [row] = await client.select().from(permissionsTable).where(eq(permissionsTable.name, name)).limit(1);
        if (!row) {
            return null;
        }
        return rowToTimestampEntity(row) as PermissionEntity;
    }

    async findAll(props?: { transaction?: AnyPgTransaction }): Promise<PermissionEntity[]> {
        const transaction = props?.transaction;
        const client = (transaction || this.db);
        const rows = await client.select().from(permissionsTable);
        return rows.map(rowToTimestampEntity) as PermissionEntity[];
    }

    async paginate(props: { query: TPaginateQuery<PermissionEntity>, transaction?: AnyPgTransaction }): Promise<TPaginateResult<PermissionEntity>> {
        const { query, transaction } = props;
        const client = (transaction || this.db);
        const result = await simplePgEntityPaginateFunction(client, permissionsTable, query, usersTable);
        return {
            ...result,
            data: result.data.map(rowToTimestampEntity) as PermissionEntity[]
        };
    }
}
