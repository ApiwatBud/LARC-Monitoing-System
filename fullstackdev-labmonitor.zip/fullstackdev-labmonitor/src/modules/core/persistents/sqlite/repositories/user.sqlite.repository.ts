import { and, eq, isNull } from "drizzle-orm";
import { LibSQLDatabase } from "drizzle-orm/libsql";
import { GenericSqliteTransactionalRepository } from "../../../../../common/repositories/generic.sqlite.repository";
import { UserEntity } from "../../../domains/entities/user.entity";
import { IUserRepository } from "../../../domains/repositories/user.repository";
import { usersTable } from "../schema/user.sqlite.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";


export class UserSqliteRepository extends GenericSqliteTransactionalRepository<UserEntity, typeof usersTable> implements IUserRepository {

    constructor(db: LibSQLDatabase<any>) {
        super(db, "User", usersTable, "id", "deletedAt", usersTable);
    }

    async findByUsername(props: { username: string, transaction?: any }): Promise<UserEntity | null> {
        const { username, transaction } = props;
        const client = transaction || this.db;
        const result = await client.select().from(this.table).where(
            and(
                eq(this.table.username, username),
                isNull(this.table.deletedAt)
            )
        ).limit(1);
        return result[0] ? rowToEntity<UserEntity>(result[0]) : null;
    }

    async findByEmail(props: { email: string, transaction?: any }): Promise<UserEntity | null> {
        const { email, transaction } = props;
        const client = transaction || this.db;
        const result = await client.select().from(this.table)
            .where(and(
                eq(this.table.email, email),
                isNull(this.table.deletedAt)
            )).limit(1);
        return result[0] ? rowToEntity<UserEntity>(result[0]) : null;
    }
}
