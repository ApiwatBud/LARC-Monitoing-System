import { eq } from "drizzle-orm";
import { LibSQLDatabase } from "drizzle-orm/libsql";
import { AnySqliteTransaction } from "../../../../../common/persistents/types";
import { SessionEntity } from "../../../domains/entities/sessions.entity";
import { ISessionRepository } from "../../../domains/repositories/session.repository";
import { sessionTables } from "../schema/session.sqlite.schema";

export class SessionSqliteRepository implements ISessionRepository {
    constructor(private dbClient: LibSQLDatabase) { }

    async updateLastActive(props: { id: string, transaction?: AnySqliteTransaction }): Promise<SessionEntity> {
        const { id, transaction } = props;
        const client = transaction || this.dbClient
        const [result] = await client.update(sessionTables).set({ last_active: new Date().toISOString() }).where(eq(sessionTables.id, id)).returning()

        return {
            ...result,
            is_revoked: result.is_revoked === 1,
            expires_at: new Date(result.expires_at),
            created_at: new Date(result.created_at),
            last_active: result.last_active ? new Date(result.last_active) : new Date(),
        }
    }

    async findById(props: { id: string, transaction?: AnySqliteTransaction }): Promise<SessionEntity | null> {
        const { id, transaction } = props;
        const client = transaction || this.dbClient
        const [result] = await client.select().from(sessionTables).where(eq(sessionTables.id, id)).limit(1)
        return result ? {
            ...result,
            is_revoked: result.is_revoked === 1,
            expires_at: new Date(result.expires_at),
            created_at: new Date(result.created_at),
            last_active: result.last_active ? new Date(result.last_active) : new Date(),
        } : null
    }

    async create(props: { session: SessionEntity, transaction?: AnySqliteTransaction }): Promise<SessionEntity> {
        const { session, transaction } = props;
        const client = transaction || this.dbClient
        const insertSession = {
            ...session,
            is_revoked: session.is_revoked ? 1 : 0,
            created_at: new Date().toISOString(),
            expires_at: session.expires_at ? session.expires_at.toISOString() : null,
            last_active: session.last_active ? session.last_active.toISOString() : null,
        } as typeof sessionTables["$inferInsert"]

        const [result] = await client.insert(sessionTables).values(insertSession).returning()
        return {
            ...result,
            is_revoked: result.is_revoked === 1,
            expires_at: new Date(result.expires_at),
            created_at: new Date(result.created_at),
            last_active: result.last_active ? new Date(result.last_active) : new Date(),
        }
    }
    async delete(props: { id: string, transaction?: AnySqliteTransaction }): Promise<SessionEntity> {
        const { id, transaction } = props;
        const client = transaction || this.dbClient
        const [result] = await client.delete(sessionTables).where(eq(sessionTables.id, id)).returning()
        return {
            ...result,
            is_revoked: result.is_revoked === 1,
            expires_at: new Date(result.expires_at),
            created_at: new Date(result.created_at),
            last_active: result.last_active ? new Date(result.last_active) : new Date(),
        }
    }
    async findByRefreshToken(props: { refreshToken: string, transaction?: AnySqliteTransaction }): Promise<SessionEntity | null> {
        const { refreshToken, transaction } = props;
        const client = transaction || this.dbClient
        const [result] = await client.select().from(sessionTables).where(eq(sessionTables.refresh_token, refreshToken)).limit(1)
        return result ? {
            ...result,
            is_revoked: result.is_revoked === 1,
            expires_at: new Date(result.expires_at),
            created_at: new Date(result.created_at),
            last_active: result.last_active ? new Date(result.last_active) : new Date(),
        } : null
    }
    async findByUserId(props: { userId: number, transaction?: AnySqliteTransaction }): Promise<SessionEntity[]> {
        const { userId, transaction } = props;
        const client = transaction || this.dbClient
        const result = await client.select().from(sessionTables).where(eq(sessionTables.user_id, userId))
        return result.map((item) => {
            return {
                ...item,
                is_revoked: item.is_revoked === 1,
                expires_at: new Date(item.expires_at),
                created_at: new Date(item.created_at),
                last_active: item.last_active ? new Date(item.last_active) : new Date(),
            }
        })
    }
}