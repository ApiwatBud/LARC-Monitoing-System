import { eq } from "drizzle-orm";
import { LibSQLDatabase } from "drizzle-orm/libsql";
import { AnySqliteTransaction } from "../../../../../common/persistents/types";
import { GenericSqliteTransactionalRepository } from "../../../../../common/repositories/generic.sqlite.repository";
import { RoleEntity } from "../../../domains/entities/role.entity";
import { IRoleRepository } from "../../../domains/repositories/role.repository";
import { rolesTable } from "../schema/role.sqlite.schema";
import { usersTable } from "../schema/user.sqlite.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";

export class RoleSqliteRepository extends GenericSqliteTransactionalRepository<RoleEntity, typeof rolesTable> implements IRoleRepository {

    constructor(db: LibSQLDatabase<any>) {
        super(db, "Role", rolesTable, "id", "deletedAt", usersTable);
    }

    async findByName(props: { name: string, transaction?: AnySqliteTransaction }): Promise<RoleEntity | null> {
        const { name, transaction } = props;
        const client = transaction || this.db
        const result = await client.select().from(this.table).where(eq(this.table.name, name)).get();
        if (!result) {
            return null;
        }
        return rowToEntity<RoleEntity>(result);
    }
}
