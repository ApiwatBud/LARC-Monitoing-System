import { and, eq, isNull } from "drizzle-orm";
import { LibSQLDatabase } from "drizzle-orm/libsql";
import { AnySqliteTransaction } from "../../../../../common/persistents/types";
import { RoleEntity } from "../../../domains/entities/role.entity";
import { RoleUserEntity } from "../../../domains/entities/role_user.entity";
import { IRoleUserRepository } from "../../../domains/repositories/role_user.repository";
import { rolesTable } from "../schema/role.sqlite.schema";
import { roleUserTable } from "../schema/role_user.sqlite.schema";

export class RoleUserSqliteRepository implements IRoleUserRepository {

    private readonly table = roleUserTable;
    private readonly roleId = roleUserTable.role_id;
    private readonly userId = roleUserTable.user_id;
    private readonly entityName = "RoleUser"


    constructor(private readonly db: LibSQLDatabase<any>) { }
    async syncRoles(props: { user_id: number, userSelectedRoles: number[], transaction?: AnySqliteTransaction }): Promise<RoleUserEntity[]> {
        const { user_id, userSelectedRoles, transaction } = props;
        const client = transaction ?? this.db;
        //delete rolesusers by id
        await client.delete(this.table).where(eq(this.userId, user_id));

        if (userSelectedRoles.length === 0) {
            return [];
        }

        //create rolesusers by id
        const result = await client.insert(this.table).values(userSelectedRoles.map(role_id => ({
            user_id,
            role_id
        }))).returning();
        return result.map(row => ({
            ...row,
        })) as RoleUserEntity[];
    }


    async findRolesByUserId(props: { id: number, transaction?: AnySqliteTransaction }): Promise<RoleEntity[]> {
        const { id: user_id, transaction } = props;
        const client = transaction ?? this.db;
        const result = await client.select().from(this.table)
            .innerJoin(rolesTable, eq(this.roleId, rolesTable.id))
            .where(and(eq(this.userId, user_id), isNull(rolesTable.deletedAt)));
        return result.map(row => ({
            ...row.roles,
            createdAt: new Date(row.roles.createdAt),
            updatedAt: new Date(row.roles.updatedAt),
            deletedAt: row.roles.deletedAt ? new Date(row.roles.deletedAt) : null,
        })) as RoleEntity[];
    }

    async create(props: { entity: RoleUserEntity, transaction?: AnySqliteTransaction }): Promise<RoleUserEntity> {
        const { entity, transaction } = props;
        const client = transaction ?? this.db;
        const result = await client.insert(this.table).values(entity).returning();
        return {
            ...result[0],
        } as RoleUserEntity
    }
    async delete(props: { user_id: RoleUserEntity["user_id"], role_id: RoleUserEntity["role_id"], transaction?: AnySqliteTransaction }): Promise<RoleUserEntity> {
        const { user_id, role_id, transaction } = props;
        const client = transaction ?? this.db;
        const [result] = await client.delete(this.table).where(and(eq(this.userId, user_id), eq(this.roleId, role_id))).returning();

        if (!result) {
            throw new Error(`${this.entityName} not found`);
        }

        return {
            ...result,
        } as RoleUserEntity
    }
    async findById(props: { user_id: RoleUserEntity["user_id"], role_id: RoleUserEntity["role_id"], transaction?: AnySqliteTransaction }): Promise<RoleUserEntity | null> {
        const { user_id, role_id, transaction } = props;
        const client = transaction ?? this.db;
        const result = await client.select().from(this.table).where(and(eq(this.userId, user_id), eq(this.roleId, role_id)));
        if (!result[0]) {
            return null;
        }
        return {
            ...result[0],
        } as RoleUserEntity
    }
    async findAll(props?: { transaction?: AnySqliteTransaction }): Promise<RoleUserEntity[]> {
        const transaction = props?.transaction;
        const client = transaction ?? this.db;
        const result = await client.select().from(this.table);
        return result.map(row => ({
            ...row,
        })) as RoleUserEntity[];
    }
    async findByUserId(props: { user_id: RoleUserEntity["user_id"], transaction?: AnySqliteTransaction }): Promise<RoleUserEntity[]> {
        const { user_id, transaction } = props;
        const client = transaction ?? this.db;
        const result = await client.select().from(this.table).where(eq(this.userId, user_id));
        return result.map(row => ({
            ...row,
        })) as RoleUserEntity[];
    }
    async findByRoleId(props: { role_id: RoleUserEntity["role_id"], transaction?: AnySqliteTransaction }): Promise<RoleUserEntity[]> {
        const { role_id, transaction } = props;
        const client = transaction ?? this.db;
        const result = await client.select().from(this.table).where(eq(this.roleId, role_id));
        return result.map(row => ({
            ...row,
        })) as RoleUserEntity[];
    }
    async deleteByUserId(props: { user_id: RoleUserEntity["user_id"], transaction?: AnySqliteTransaction }): Promise<void> {
        const { user_id, transaction } = props;
        const client = transaction ?? this.db;
        await client.delete(this.table).where(eq(this.userId, user_id));
    }
    async deleteByRoleId(props: { role_id: RoleUserEntity["role_id"], transaction?: AnySqliteTransaction }): Promise<void> {
        const { role_id, transaction } = props;
        const client = transaction ?? this.db;
        await client.delete(this.table).where(eq(this.roleId, role_id));
    }
}