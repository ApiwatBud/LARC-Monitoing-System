import { isNull } from "drizzle-orm";
import { int, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
import { RoleEntity } from "../../../domains/entities/role.entity";
import { AuditorName } from "../../../../../common/persistents/types";


export const rolesTable = sqliteTable("roles", {
    id: int("id").primaryKey({ autoIncrement: true }),
    name: text("name").notNull(),
    description: text("description"),
    createdAt: text("created_at").notNull(),
    updatedAt: text("updated_at").notNull(),
    deletedAt: text("deleted_at"),
    createdBy: int("created_by"),
    updatedBy: int("updated_by"),
}, (table) => [
    uniqueIndex("roles_name_idx1").on(table.name).where(isNull(table.deletedAt)),
]) satisfies Record<keyof Omit<RoleEntity, AuditorName>, any>;
