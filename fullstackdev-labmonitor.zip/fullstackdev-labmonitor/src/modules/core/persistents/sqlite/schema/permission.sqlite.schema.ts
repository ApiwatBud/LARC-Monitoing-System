import { int, sqliteTable, text } from "drizzle-orm/sqlite-core";
import { PermissionEntity } from "../../../domains/entities/permission.entity";
import { AuditorName } from "../../../../../common/persistents/types";

export const permissionsTable = sqliteTable("permissions", {
    name: text("name").primaryKey(),
    description: text("description"),
    createdAt: text("created_at").notNull(),
    updatedAt: text("updated_at").notNull(),
    createdBy: int("created_by"),
    updatedBy: int("updated_by"),
}) satisfies Record<keyof Omit<PermissionEntity, AuditorName>, any>;