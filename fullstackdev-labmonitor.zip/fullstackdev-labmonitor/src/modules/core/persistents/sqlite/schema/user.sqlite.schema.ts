import { isNull } from "drizzle-orm";
import { int, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
import { UserEntity } from "../../../domains/entities/user.entity";
import { AuditorName } from "../../../../../common/persistents/types";


export const usersTable = sqliteTable("users", {
    id: int("id").primaryKey({ autoIncrement: true }),
    username: text("username").notNull(),
    email: text("email").notNull(),
    password: text("password").notNull(),
    createdAt: text("created_at").notNull(),
    updatedAt: text("updated_at").notNull(),
    deletedAt: text("deleted_at"),
    createdBy: int("created_by"),
    updatedBy: int("updated_by"),
}, (table) => [
    uniqueIndex("users_username_idx").on(table.username).where(isNull(table.deletedAt)),
    uniqueIndex("users_email_idx").on(table.email).where(isNull(table.deletedAt)),
]) satisfies Record<keyof Omit<UserEntity, AuditorName>, any>;
