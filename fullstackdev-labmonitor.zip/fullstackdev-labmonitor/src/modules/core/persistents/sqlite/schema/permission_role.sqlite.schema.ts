import { int, primaryKey, sqliteTable, text } from "drizzle-orm/sqlite-core";
import { permissionsTable } from "./permission.sqlite.schema";
import { rolesTable } from "./role.sqlite.schema";
import { PermissionRoleEntity } from "../../../domains/entities/permission_role.entity";

export const permissionRoleTable = sqliteTable("permission_role", {
    permission_name: text("permission_name").notNull().references(() => permissionsTable.name),
    role_id: int("role_id").notNull().references(() => rolesTable.id),
}, (table) => [
    primaryKey({ columns: [table.permission_name, table.role_id] })
]) satisfies Record<keyof PermissionRoleEntity, any>;