import { int, primaryKey, sqliteTable } from "drizzle-orm/sqlite-core";
import { rolesTable } from "./role.sqlite.schema";
import { usersTable } from "./user.sqlite.schema";
import { RoleUserEntity } from "../../../domains/entities/role_user.entity";

export const roleUserTable = sqliteTable("role_user", {
    role_id: int("role_id").notNull().references(() => rolesTable.id),
    user_id: int("user_id").notNull().references(() => usersTable.id),
}, (table) => [
    primaryKey({ columns: [table.role_id, table.user_id] })
]) satisfies Record<keyof RoleUserEntity, any>;