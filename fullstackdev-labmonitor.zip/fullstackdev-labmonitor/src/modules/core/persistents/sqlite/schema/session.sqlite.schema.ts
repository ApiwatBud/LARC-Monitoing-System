import { int, sqliteTable, text } from "drizzle-orm/sqlite-core";
import { SessionEntity } from "../../../domains/entities/sessions.entity";

export const sessionTables = sqliteTable("sessions", {
    id: text("id").primaryKey(),
    user_id: int("user_id").notNull(),
    refresh_token: text("refresh_token").notNull(),
    ip_address: text("ip_address"),
    user_agent: text("user_agent"),
    created_at: text("created_at").notNull(),
    expires_at: text("expires_at").notNull(),
    is_revoked: int("is_revoked").notNull(),
    last_active: text("last_active"),
} satisfies Record<keyof SessionEntity, any>)