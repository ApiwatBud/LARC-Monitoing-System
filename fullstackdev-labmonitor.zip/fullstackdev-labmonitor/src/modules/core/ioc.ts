import Elysia from "elysia";
import pgClient from "../../common/persistents/pgClient";
import { PermissionPgRepository } from "./persistents/pg/repositories/permission.pg.repository";
import { PermissionRolePgRepository } from "./persistents/pg/repositories/permission_role.pg.repository";
import { RolePgRepository } from "./persistents/pg/repositories/role.pg.repository";
import { RoleUserPgRepository } from "./persistents/pg/repositories/role_user.pg.repository";
import { RoleModulePgRepository } from "./persistents/pg/repositories/role_module.pg.repository";
import { SessionPgRepository } from "./persistents/pg/repositories/session.pg.repository";
import { UserPgRepository } from "./persistents/pg/repositories/user.pg.repository";
import { GetSystemStatus } from "./applications/usecases/system/getSystemStatus";
import { SocialAccountPgRepository } from "./persistents/pg/repositories/social_account.pg.repository";

export const CoreIoC = new Elysia()
    .decorate("dbClient", pgClient)
    .decorate("userRepository", new UserPgRepository(pgClient))
    .decorate("roleRepository", new RolePgRepository(pgClient))
    .decorate("roleUserRepository", new RoleUserPgRepository(pgClient))
    .decorate("roleModuleRepository", new RoleModulePgRepository(pgClient))
    .decorate("permissionRepository", new PermissionPgRepository(pgClient))
    .decorate("permissionRoleRepository", new PermissionRolePgRepository(pgClient))
    .decorate("sessionRepository", new SessionPgRepository(pgClient))
    .decorate("socialAccountRepository", SocialAccountPgRepository(pgClient))
    .decorate({
        getSystemStatus: GetSystemStatus({})
    });