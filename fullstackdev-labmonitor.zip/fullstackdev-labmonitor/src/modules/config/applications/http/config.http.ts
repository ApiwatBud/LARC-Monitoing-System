import { Elysia, t } from "elysia";
import { ConfigIoC } from "../../ioc";
import { SaveConfig } from "../usecases/config/saveConfig";
import { GetConfigByKey } from "../usecases/config/getConfigByKey";
import { SaveSMTPConfig } from "../usecases/config/saveSMTPConfig";
import { GetSMTPConfig } from "../usecases/config/getSMTPConfig";
import { GetActiveModulesUsecase } from "../usecases/module/getActiveModules";
import { SendTestEmail } from "../usecases/email/sendTestEmail";
import { ConfigCreateDto } from "../dtos/config.dto";
import { SMTPUpdateDto } from "../dtos/smtp.dto";
import { AuthMiddleware } from "../../../core/applications/http/middlewares/auth.middleware";
import { logger } from "../../../../common/utils/logger";

export const ConfigUseCase = new Elysia()
    .use(ConfigIoC)
    .decorate("saveConfig", SaveConfig({
        configRepository: ConfigIoC.decorator.configRepository
    }))
    .decorate("getConfigByKey", GetConfigByKey({
        configRepository: ConfigIoC.decorator.configRepository
    }))
    .decorate("saveSMTPConfig", SaveSMTPConfig({
        configRepository: ConfigIoC.decorator.configRepository
    }))
    .decorate("getSMTPConfig", GetSMTPConfig({
        configRepository: ConfigIoC.decorator.configRepository
    }))
    .decorate("getActiveModules", GetActiveModulesUsecase({
        moduleRepository: ConfigIoC.decorator.moduleRepository
    }))
    .decorate("sendTestEmail", SendTestEmail({
        configRepository: ConfigIoC.decorator.configRepository
    }));

export const ConfigHttp = new Elysia({
    detail: {
        tags: ['api.configs']
    }
})
    .use(ConfigUseCase)
    .group("/configs", (app) => app
        .use(AuthMiddleware)
        .get("/modules/active", async ({ getActiveModules, user, permissions }) => {
            return await getActiveModules({ context: { user, permissions: permissions as any || [] } });
        }, {
            permission: ["anyone"]
        })
        .post("", async ({ body, saveConfig, user, permissions }) => {
            logger.info({ action: 'save_config', config_key: body.key, performed_by: user?.email }, `Saving system config for key: ${body.key}`);
            const result = await saveConfig({
                dto: body,
                context: { user, permissions: permissions as any || [] }
            });
            logger.info({ action: 'save_config_success', config_key: body.key }, `System config for key: ${body.key} saved successfully`);
            return result
        }, {
            body: ConfigCreateDto,
            permission: ["anyone"]
        })
        .get("/:key", async ({ params, getConfigByKey, user, permissions }) => {
            return await getConfigByKey({
                key: params.key,
                context: { user, permissions: permissions as any || [] }
            });
        }, {
            permission: ["anyone"]
        })
        .group("/smtp", (app) => app
            .get("", async ({ getSMTPConfig, user, permissions }) => {
                return await getSMTPConfig({
                    maskPassword: true,
                    context: { user, permissions: permissions as any || [] }
                });
            }, {
                permission: ["anyone"]
            })
            .post("", async ({ body, saveSMTPConfig, user, permissions }) => {
                logger.info({ action: 'save_smtp_config', performed_by: user?.email }, `Saving SMTP configuration`);
                const result = await saveSMTPConfig({
                    dto: body,
                    context: { user, permissions: permissions as any || [] }
                });
                logger.info({ action: 'save_smtp_config_success' }, `SMTP configuration saved successfully`);
                return result
            }, {
                body: SMTPUpdateDto,
                permission: ["anyone"]
            })
            .post("/test", async ({ body, sendTestEmail, user, permissions }) => {
                logger.info({ action: 'send_test_email', to: body.to, performed_by: user?.email }, `Sending test email to: ${body.to}`);
                const result = await sendTestEmail({
                    to: body.to,
                    context: { user, permissions: permissions as any || [] }
                });
                logger.info({ action: 'send_test_email_success', to: body.to }, `Test email sent successfully to: ${body.to}`);
                return result
            }, {
                body: t.Object({
                    to: t.String({ format: 'email' })
                }),
                permission: ["anyone"]
            })
        )
    );
