import { Elysia, t } from "elysia";
import { CreateSocialProvider, DeleteSocialProvider, GetActiveSocialProviders, GetAllSocialProviders, GetSocialProvider, PaginateSocialProviders, UpdateSocialProvider } from "../usecases/social_provider.usecase";
import { ConfigIoC } from "../../ioc";
import { SocialProviderEntity } from "../../domains/entities/social_provider.entity";
import { PaginateQueryDto } from "../../../../common/types";

// Setup Dependencies
const socialProviderRepo = ConfigIoC.decorator.socialProviderRepository as any; // Cast to any or helper type if needed to avoid deep type issues temporarily
const createProvider = CreateSocialProvider(socialProviderRepo);
const updateProvider = UpdateSocialProvider(socialProviderRepo);
const deleteProvider = DeleteSocialProvider(socialProviderRepo);
const getProvider = GetSocialProvider(socialProviderRepo);
const getAllProviders = GetAllSocialProviders(socialProviderRepo);
const paginateProviders = PaginateSocialProviders(socialProviderRepo);

export const socialProviderHttp = new Elysia({ prefix: "/config/social-providers" })
    .get("/", async () => {
        return await getAllProviders();
    })
    .post("/filter", async ({ body }) => {
        const result = await paginateProviders(body as any);
        return result;
    }, {
        body: PaginateQueryDto
    })
    .get("/:id", async ({ params: { id }, set }) => {
        const provider = await getProvider(parseInt(id));
        if (!provider) {
            set.status = 404;
            return "Provider not found";
        }
        return provider;
    })
    .post("/", async ({ body, set }) => {
        const newProvider = await createProvider(body as SocialProviderEntity);
        set.status = 201;
        return newProvider;
    }, {
        body: t.Object({
            provider: t.String(),
            name: t.String(),
            clientId: t.String(),
            clientSecret: t.String(),
            scopes: t.Array(t.String()),
            isActive: t.Boolean(),
            redirectUri: t.Optional(t.String())
        })
    })
    .put("/:id", async ({ params: { id }, body }) => {
        const updated = await updateProvider({ ...body, id: parseInt(id) } as SocialProviderEntity);
        return updated;
    }, {
        body: t.Object({
            provider: t.Optional(t.String()),
            name: t.Optional(t.String()),
            clientId: t.Optional(t.String()),
            clientSecret: t.Optional(t.String()),
            scopes: t.Optional(t.Array(t.String())),
            isActive: t.Optional(t.Boolean()),
            redirectUri: t.Optional(t.String())
        })
    })
    .delete("/:id", async ({ params: { id } }) => {
        await deleteProvider(parseInt(id));
        return { message: "Provider deleted successfully" };
    });
