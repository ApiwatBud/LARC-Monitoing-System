import 'dotenv/config';
import * as p from '@clack/prompts';
import { SendTestEmail } from '../usecases/email/sendTestEmail';
import { ConfigIoC } from '../../ioc';

export async function main() {
    p.intro('Send Test Email CLI');

    const to = await p.text({
        message: 'Enter receiver email address',
        placeholder: 'test@example.com',
        validate: (value) => {
            if (!value) return 'Email is required';
            if (!value.includes('@')) return 'Invalid email address';
        }
    });

    if (p.isCancel(to)) {
        p.cancel('Operation cancelled');
        return;
    }

    const sendTestEmail = SendTestEmail({
        configRepository: ConfigIoC.decorator.configRepository
    });

    const s = p.spinner();
    s.start('Sending test email...');

    try {
        const result = await sendTestEmail({
            to: to as string,
            context: {
                user: null,
                permissions: ["system-config:read"]
            }
        });
        s.stop('Test email sent successfully!');
        p.note(`Message ID: ${result.messageId}\nResponse: ${result.response}`, 'Success');
    } catch (error: any) {
        s.stop('Failed to send test email');
        p.log.error(error.message);
    }

    p.outro('Finished');
}
