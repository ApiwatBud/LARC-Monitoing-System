import { z } from "zod";



export const SMTPResponseDto = z.object({
    host: z.string(),
    port: z.number(),
    secure: z.boolean(),
    auth: z.object({
        user: z.string(),
        pass: z.string()
    })
})

export const SMTPUpdateDto = z.object({
    host: z.string(),
    port: z.number(),
    secure: z.boolean(),
    auth: z.object({
        user: z.string(),
        pass: z.string(),
        password_confirmation: z.string().optional()
    }).refine((data) => {
        if (data.pass !== "********" && data.pass !== data.password_confirmation) {
            return false;
        }
        return true;
    }, {
        message: "Passwords do not match",
        path: ["password_confirmation"]
    })
})


