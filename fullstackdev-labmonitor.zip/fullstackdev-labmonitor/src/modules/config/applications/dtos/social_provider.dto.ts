import z, { ZodType } from "zod";
import { SocialProviderEntity } from "../../domains/entities/social_provider.entity";

export const SocialProviderCreateDto = z.object({
    provider: z.string().min(1, "Provider key is required"),
    name: z.string().min(1, "Display name is required"),
    clientId: z.string().min(1, "Client ID is required"),
    clientSecret: z.string().min(1, "Client Secret is required"),
    scopes: z.array(z.string()).default([]),
    isActive: z.boolean().default(true),
    redirectUri: z.string().optional(),
}) satisfies ZodType<Partial<SocialProviderEntity>>;

export const SocialProviderUpdateDto = z.object({
    provider: z.string().min(1, "Provider key is required"),
    name: z.string().min(1, "Display name is required"),
    clientId: z.string().min(1, "Client ID is required"),
    clientSecret: z.string().min(1, "Client Secret is required"),
    scopes: z.array(z.string()).default([]),
    isActive: z.boolean().default(true),
    redirectUri: z.string().optional(),
}) satisfies ZodType<Partial<SocialProviderEntity>>;

export type SocialProviderCreateDto = z.infer<typeof SocialProviderCreateDto>;
export type SocialProviderUpdateDto = z.infer<typeof SocialProviderUpdateDto>;
