import { z } from "zod";
import { ConfigTypeEnum } from "../../domains/valueObjects/config.type";

export const ConfigResponseDto = z.object({
    id: z.number(),
    key: z.string(),
    value: z.string(),
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullable().optional(),
    updaterName: z.string().nullable().optional(),
})

const validateConfigValue = (data: any) => {
    const { type, value } = data;
    switch (type) {
        case ConfigTypeEnum.STRING: return typeof value === "string";
        case ConfigTypeEnum.NUMBER: return typeof value === "number";
        case ConfigTypeEnum.BOOLEAN: return typeof value === "boolean";
        case ConfigTypeEnum.OBJECT: return typeof value === "object" && value !== null && !Array.isArray(value);
        case ConfigTypeEnum.ARRAY: return Array.isArray(value);
        default: return false;
    }
};

export const ConfigCreateDto = z.object({
    key: z.string().min(1, "key is required"),
    type: z.enum(ConfigTypeEnum).default(ConfigTypeEnum.STRING),
    value: z.any()
}).refine(validateConfigValue, {
    message: "Invalid value for type"
})

export const ConfigUpdateDto = z.object({
    key: z.string().min(1, "key is required"),
    type: z.enum(ConfigTypeEnum).default(ConfigTypeEnum.STRING),
    value: z.any(),
}).refine(validateConfigValue, {
    message: "Invalid value for type"
})



export type ConfigResponseDto = z.infer<typeof ConfigResponseDto>
export type ConfigCreateDto = z.infer<typeof ConfigCreateDto>
export type ConfigUpdateDto = z.infer<typeof ConfigUpdateDto>