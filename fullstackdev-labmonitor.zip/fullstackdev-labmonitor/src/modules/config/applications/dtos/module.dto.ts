import z from "zod";
import { ModuleEntity } from "../../domains/entities/module.enity";
import { AuditorName } from "../../../../common/persistents/types";

export const ModuleResponseDto = z.object({
    id: z.number(),
    key: z.string(),
    name: z.string(),
    description: z.string().nullable().optional(),
    icon: z.string().nullable().optional(),
    is_active: z.boolean(),
    createdAt: z.date(),
    updatedAt: z.date(),
    deletedAt: z.date().nullable(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
} satisfies Record<keyof Omit<ModuleEntity, AuditorName>, unknown>);

export type ModuleResponseDto = z.infer<typeof ModuleResponseDto>;
