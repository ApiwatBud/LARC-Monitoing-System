import { IModuleRepository } from "../../../domains/repositories/module.repository";

interface deps {
    moduleRepository: IModuleRepository;
}

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import ConfigPermissions from "../../../domains/permissions/config.permissions";

interface props {
    context: UsecaseContext;
}

export const DeactivateAllModulesUsecase = (deps: deps) => async (props: props) => {
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ModuleWrite);
    await deps.moduleRepository.resetActiveAllModule({});
}