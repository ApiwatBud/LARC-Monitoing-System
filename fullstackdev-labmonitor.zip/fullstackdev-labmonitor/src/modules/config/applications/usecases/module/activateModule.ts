import { IModuleRepository } from "../../../domains/repositories/module.repository";

interface deps {
    moduleRepository: IModuleRepository;
}

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import ConfigPermissions from "../../../domains/permissions/config.permissions";

interface props {
    key: string;
    transaction?: any;
    context: UsecaseContext;
}

export const ActivateModuleUsecase = (deps: deps) => async (props: props) => {
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ModuleWrite);
    await deps.moduleRepository.activateModuleByKey({
        key: props.key,
        transaction: props.transaction
    })
}   