import { ModulePgRepository } from "../../../persistents/pg/repositories/module.pg.repository";

import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import ConfigPermissions from "../../../domains/permissions/config.permissions";

interface Props {
    keys: string[];
    context: UsecaseContext;
}

interface Deps {
    moduleRepository: ModulePgRepository;
}

export const SyncModulesUsecase = (deps: Deps) => async (props: Props) => {
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ModuleWrite);
    return await deps.moduleRepository.syncActivateModules({ keys: props.keys });
}