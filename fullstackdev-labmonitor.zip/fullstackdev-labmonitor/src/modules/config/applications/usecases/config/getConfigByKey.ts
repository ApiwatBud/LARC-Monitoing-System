import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { ConfigResponseDto } from "../../dtos/config.dto";
import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";

interface GetConfigByKeyDeps {
    configRepository: IConfigRepository;
}

interface GetConfigByKeyProps {
    key: string;
    context: UsecaseContext;
}

import ConfigPermissions from "../../../domains/permissions/config.permissions";

export const GetConfigByKey = ({ configRepository }: GetConfigByKeyDeps) => async (props: GetConfigByKeyProps) => {
    const { key, context } = props;
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ConfigRead);
    const config = await configRepository.findByKey({ key });

    if (!config) {
        return null;
    }

    if (key === "SMTP") {
        try {
            const parsed = JSON.parse(config.value);
            if (parsed.auth?.pass) {
                parsed.auth.pass = "********";
            }
            config.value = JSON.stringify(parsed);
        } catch (e) {
            console.error("Failed to mask SMTP config in GetConfigByKey", e);
        }
    }

    return ConfigResponseDto.parse(config);
}
