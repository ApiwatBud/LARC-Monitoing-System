import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { ConfigCreateDto, ConfigResponseDto } from "../../dtos/config.dto";

interface SaveConfigDeps {
    configRepository: IConfigRepository;
}

interface SaveConfigProps {
    dto: ConfigCreateDto;
    context: UsecaseContext;
}

import ConfigPermissions from "../../../domains/permissions/config.permissions";

export const SaveConfig = ({ configRepository }: SaveConfigDeps) => async (props: SaveConfigProps) => {
    const { dto, context } = props;
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ConfigWrite);
    // Check if key already exists
    const existing = await configRepository.findByKey({ key: dto.key });

    const value = typeof dto.value === 'string' ? dto.value : JSON.stringify(dto.value);

    if (existing) {
        // Update
        const updated = await configRepository.update({
            id: existing.id,
            entity: {
                type: dto.type,
                value: value
            },
            userId: guard.user?.id
        });
        return ConfigResponseDto.parse(updated);
    } else {
        // Create
        const created = await configRepository.create({
            entity: {
                key: dto.key,
                type: dto.type,
                value: value
            },
            userId: guard.user?.id
        });
        return ConfigResponseDto.parse(created);
    }
}
