import { z } from "zod";
import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";
import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { ConfigTypeEnum } from "../../../domains/valueObjects/config.type";
import { SMTPUpdateDto } from "../../dtos/smtp.dto";
import { ConfigResponseDto } from "../../dtos/config.dto";

interface SaveSMTPConfigDeps {
    configRepository: IConfigRepository;
}

interface SaveSMTPConfigProps {
    dto: z.infer<typeof SMTPUpdateDto>;
    context: UsecaseContext;
}

import ConfigPermissions from "../../../domains/permissions/config.permissions";

export const SaveSMTPConfig = ({ configRepository }: SaveSMTPConfigDeps) => async (props: SaveSMTPConfigProps) => {
    const { dto, context } = props;
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ConfigWrite);
    const key = "SMTP";

    // Check if SMTP config already exists
    const existing = await configRepository.findByKey({ key });

    // Handle masked password
    if (existing && dto.auth?.pass === "********") {
        try {
            const existingValue = JSON.parse(existing.value);
            if (existingValue.auth?.pass) {
                dto.auth.pass = existingValue.auth.pass;
            }
        } catch (e) {
            console.error("Failed to parse existing SMTP config during save", e);
        }
    }

    const value = JSON.stringify({
        host: dto.host,
        port: dto.port,
        secure: dto.secure,
        auth: {
            user: dto.auth.user,
            pass: dto.auth.pass
        }
    });

    if (existing) {
        // Update
        const updated = await configRepository.update({
            id: existing.id,
            entity: {
                type: ConfigTypeEnum.OBJECT,
                value: value
            },
            userId: guard.user?.id
        });
        return ConfigResponseDto.parse(updated);
    } else {
        // Create
        const created = await configRepository.create({
            entity: {
                key: key,
                type: ConfigTypeEnum.OBJECT,
                value: value
            },
            userId: guard.user?.id
        });
        return ConfigResponseDto.parse(created);
    }
}
