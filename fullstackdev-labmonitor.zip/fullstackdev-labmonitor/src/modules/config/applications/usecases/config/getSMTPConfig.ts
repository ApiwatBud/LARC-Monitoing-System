import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { SMTPResponseDto } from "../../dtos/smtp.dto";
import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";

interface GetSMTPConfigDeps {
    configRepository: IConfigRepository;
}

interface GetSMTPConfigProps {
    maskPassword: boolean;
    context: UsecaseContext;
}

import ConfigPermissions from "../../../domains/permissions/config.permissions";

export const GetSMTPConfig = ({ configRepository }: GetSMTPConfigDeps) => async (props: GetSMTPConfigProps) => {
    const { maskPassword = true, context } = props;
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ConfigRead);
    const key = "SMTP";
    const config = await configRepository.findByKey({ key });

    if (!config) {
        return null;
    }

    try {
        const parsedValue = JSON.parse(config.value);
        const smtpConfig = SMTPResponseDto.parse(parsedValue);

        // Mask the password
        if (smtpConfig.auth && smtpConfig.auth.pass) {
            smtpConfig.auth.pass = maskPassword ? "********" : smtpConfig.auth.pass;
        }

        return smtpConfig;
    } catch (e) {
        console.error("Failed to parse SMTP configuration", e);
        return null;
    }
}
