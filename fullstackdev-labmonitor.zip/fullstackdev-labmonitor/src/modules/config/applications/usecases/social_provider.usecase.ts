import { ISocialProviderRepository } from "../../persistents/pg/repositories/social_provider.pg.repository";
import { SocialProviderEntity } from "../../domains/entities/social_provider.entity";
import { TPaginateQuery } from "../../../../common/types";

export const CreateSocialProvider = (socialProviderRepo: ISocialProviderRepository) => async (provider: SocialProviderEntity) => {
    return await socialProviderRepo.create(provider);
};

export const UpdateSocialProvider = (socialProviderRepo: ISocialProviderRepository) => async (provider: SocialProviderEntity) => {
    return await socialProviderRepo.update(provider);
};

export const DeleteSocialProvider = (socialProviderRepo: ISocialProviderRepository) => async (id: number) => {
    return await socialProviderRepo.delete(id);
};

export const GetSocialProvider = (socialProviderRepo: ISocialProviderRepository) => async (id: number) => {
    return await socialProviderRepo.findById(id);
};

export const GetActiveSocialProviders = (socialProviderRepo: ISocialProviderRepository) => async () => {
    return await socialProviderRepo.findAllActive();
};

export const GetAllSocialProviders = (socialProviderRepo: ISocialProviderRepository) => async () => {
    return await socialProviderRepo.findAll();
};

export const PaginateSocialProviders = (socialProviderRepo: ISocialProviderRepository) => async (query: TPaginateQuery<SocialProviderEntity>) => {
    return await socialProviderRepo.paginate(query);
};
