import nodemailer from "nodemailer";
import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { GetSMTPConfig } from "../config/getSMTPConfig";

interface SendEmailDeps {
    configRepository: IConfigRepository;
}

interface SendEmailProps {
    to: string | string[];
    subject: string;
    text?: string;
    html?: string;
    fromName?: string;
}

import ConfigPermissions from "../../../domains/permissions/config.permissions";

/**
 * Generic Send Email use case that uses SMTP configuration from database
 */
export const SendEmail = ({ configRepository }: SendEmailDeps) => async ({ to, subject, text, html, fromName = "Lab Monitor System" }: SendEmailProps) => {
    const getSMTP = GetSMTPConfig({ configRepository });
    const smtpSettings = await getSMTP({ maskPassword: false, context: { user: null, permissions: [ConfigPermissions.ConfigRead] } });

    if (!smtpSettings) {
        throw new Error("SMTP settings not found. Please configure SMTP first.");
    }

    const transporter = nodemailer.createTransport({
        host: smtpSettings.host,
        port: smtpSettings.port,
        secure: smtpSettings.port == 587 ? false : smtpSettings.secure,
        auth: {
            user: smtpSettings.auth.user,
            pass: smtpSettings.auth.pass,
        },
    });

    try {
        const info = await transporter.sendMail({
            from: `"${fromName}" <${smtpSettings.auth.user}>`,
            to: Array.isArray(to) ? to.join(", ") : to,
            subject: subject,
            text: text,
            html: html,
        });

        return {
            success: true,
            messageId: info.messageId,
            response: info.response,
        };
    } catch (error: any) {
        console.error("Failed to send email:", error);
        throw new Error(`Failed to send email: ${error.message}`);
    }
}
