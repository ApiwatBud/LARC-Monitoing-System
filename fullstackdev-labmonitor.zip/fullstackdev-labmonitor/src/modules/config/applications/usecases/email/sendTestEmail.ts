import nodemailer from "nodemailer";
import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { GetSMTPConfig } from "../config/getSMTPConfig";
import { createGuard, UsecaseContext } from "../../../../../common/utils/guard";

interface SendTestEmailDeps {
    configRepository: IConfigRepository;
}

interface SendTestEmailProps {
    to: string;
    context: UsecaseContext;
}

import ConfigPermissions from "../../../domains/permissions/config.permissions";

export const SendTestEmail = ({ configRepository }: SendTestEmailDeps) => async (props: SendTestEmailProps) => {
    const { to, context } = props;
    const guard = createGuard(props.context);
    guard.ensure(ConfigPermissions.ConfigWrite);

    const getSMTP = GetSMTPConfig({ configRepository });
    const smtpSettings = await getSMTP({ maskPassword: false, context });

    if (!smtpSettings) {
        throw new Error("SMTP settings not found. Please configure SMTP first.");
    }

    console.log(smtpSettings)

    const transporter = nodemailer.createTransport({
        host: smtpSettings.host,
        port: smtpSettings.port,
        // Office365 and many others use STARTTLS on port 587, which requires secure: false in Nodemailer
        secure: smtpSettings.port === 587 ? false : smtpSettings.secure,
        auth: {
            user: smtpSettings.auth.user,
            pass: smtpSettings.auth.pass,
        },
        tls: {
        }
    });

    try {
        const info = await transporter.sendMail({
            from: `"ZZBY System" <${smtpSettings.auth.user}>`,
            to: to,
            subject: "Test Email from ZZBY System",
            text: "This is a test email from your local system configuration. If you receive this, your SMTP settings are correct.",
            html: "<b>This is a test email from your local system configuration.</b><p>If you receive this, your SMTP settings are correct.</p>",
        });

        return {
            success: true,
            messageId: info.messageId,
            response: info.response,
        };
    } catch (error: any) {
        console.error("Failed to send test email:", error);
        // Provide more detailed error message if possible
        const errorMessage = error.code === 'ECONNREFUSED'
            ? `Connection refused to ${smtpSettings.host}:${smtpSettings.port}. Please check if the host and port are correct.`
            : error.message;
        throw new Error(`Failed to send test email: ${errorMessage}`);
    }
}
