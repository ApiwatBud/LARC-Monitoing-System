import { integer, pgEnum, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { ConfigEntity } from "../../../domains/entities/config.entity";
import { AuditorName } from "../../../../../common/persistents/types";
import { ConfigTypeEnum } from "../../../domains/valueObjects/config.type";
import { enumToPgEnum } from "../../../../../common/persistents/pgutils";

export const config_type_enum = pgEnum('config_type_enum', enumToPgEnum(ConfigTypeEnum))

export const configsTable = pgTable("configs", {
    id: serial("id").primaryKey(),
    key: varchar("key").notNull().unique(),
    type: config_type_enum("type").notNull().default(ConfigTypeEnum.STRING),
    value: text("value").notNull(),
    createdAt: timestamp("created_at").notNull(),
    updatedAt: timestamp("updated_at").notNull(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}) satisfies Record<keyof Omit<ConfigEntity, AuditorName>, any>;
