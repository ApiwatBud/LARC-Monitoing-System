import { boolean, integer, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { AuditorName } from "../../../../../common/persistents/types";
import { ModuleEntity } from "../../../domains/entities/module.enity";


export const modulesTable = pgTable("modules", {
    id: serial("id").primaryKey(),
    key: varchar("key").notNull().unique(),
    name: varchar("name").notNull(),
    description: text("description"),
    icon: varchar("icon"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
    is_active: boolean("is_active").notNull().default(true),
}) satisfies Record<keyof Omit<ModuleEntity, AuditorName>, any>;
