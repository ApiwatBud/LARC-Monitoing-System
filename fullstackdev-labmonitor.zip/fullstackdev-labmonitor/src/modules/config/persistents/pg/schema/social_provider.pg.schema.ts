import { boolean, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { AuditorName } from "../../../../../common/persistents/types";
import { SocialProviderEntity } from "../../../domains/entities/social_provider.entity";

export const socialProvidersTable = pgTable("social_providers", {
    id: serial("id").primaryKey(),
    provider: varchar("provider", { length: 50 }).notNull(),
    name: varchar("name", { length: 100 }).notNull(),
    clientId: text("client_id").notNull(),
    clientSecret: text("client_secret").notNull(),
    scopes: text("scopes").array().notNull().default([]), // Storing as array of text
    isActive: boolean("is_active").notNull().default(true),
    redirectUri: text("redirect_uri"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: serial("created_by"),
    updatedBy: serial("updated_by"),
}) satisfies Record<keyof Omit<SocialProviderEntity, AuditorName>, any>;
