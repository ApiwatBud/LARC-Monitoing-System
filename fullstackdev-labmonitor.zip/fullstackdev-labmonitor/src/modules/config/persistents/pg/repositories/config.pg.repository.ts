import { and, eq, isNull } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { GenericPgTransactionalRepository } from "../../../../../common/repositories/generic.pg.repository";
import { ConfigEntity } from "../../../domains/entities/config.entity";
import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { configsTable } from "../schema/config.pg.schema";
import { usersTable } from "../../../../core/persistents/pg/schema/user.pg.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";
import { AnyPgTransaction } from "../../../../../common/persistents/types";

export class ConfigPgRepository extends GenericPgTransactionalRepository<ConfigEntity, typeof configsTable> implements IConfigRepository {

    constructor(db: PgDatabase<any, any, any>) {
        super(db, "Config", configsTable, "id", "deletedAt", usersTable);
    }

    async findByKey(props: { key: string, transaction?: AnyPgTransaction }): Promise<ConfigEntity | null> {
        const { key, transaction } = props;
        const client = this.getClient(transaction);
        const result = await client.select().from(this.table).where(
            and(
                eq(this.table.key, key),
                isNull(this.table.deletedAt)
            )
        ).limit(1);
        return result[0] ? rowToEntity<ConfigEntity>(result[0]) : null;
    }
}
