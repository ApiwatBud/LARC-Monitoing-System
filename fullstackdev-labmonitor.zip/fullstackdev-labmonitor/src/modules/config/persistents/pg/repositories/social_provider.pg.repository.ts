import { eq } from "drizzle-orm";
import { PostgresJsDatabase } from "drizzle-orm/postgres-js";
import { SocialProviderEntity } from "../../../domains/entities/social_provider.entity";
import { socialProvidersTable } from "../schema/social_provider.pg.schema";
import { TPaginateQuery, TPaginateResult } from "../../../../../common/types";
import { pgPaginateFunction } from "../../../../../common/repositories/generic.pg.repository";

export interface ISocialProviderRepository {
    create(provider: SocialProviderEntity): Promise<SocialProviderEntity | null>;
    update(provider: SocialProviderEntity): Promise<SocialProviderEntity | null>;
    delete(id: number): Promise<boolean>;
    findById(id: number): Promise<SocialProviderEntity | null>;
    findByProvider(provider: string): Promise<SocialProviderEntity | null>;
    findAllActive(): Promise<SocialProviderEntity[]>;
    findAll(): Promise<SocialProviderEntity[]>;
    paginate(query: TPaginateQuery<SocialProviderEntity>): Promise<TPaginateResult<SocialProviderEntity>>;
}

export const SocialProviderPgRepository = (db: PostgresJsDatabase): ISocialProviderRepository => {
    return {
        async create(provider: SocialProviderEntity) {
            const payload = { ...provider } as any;
            if (payload.createdBy === null) delete payload.createdBy;
            if (payload.updatedBy === null) delete payload.updatedBy;
            const result = await db.insert(socialProvidersTable).values(payload).returning();
            return result[0] ? result[0] as SocialProviderEntity : null;
        },
        async update(provider: SocialProviderEntity) {
            if (!provider.id) return null;
            const payload = { ...provider } as any;
            if (payload.createdBy === null) delete payload.createdBy;
            if (payload.updatedBy === null) delete payload.updatedBy;
            const result = await db
                .update(socialProvidersTable)
                .set(payload)
                .where(eq(socialProvidersTable.id, provider.id))
                .returning();
            return result[0] ? result[0] as SocialProviderEntity : null;
        },
        async delete(id: number) {
            const result = await db.delete(socialProvidersTable).where(eq(socialProvidersTable.id, id));
            return true; // Drizzle delete returns result object, not boolean directly but usually successful
        },
        async findById(id: number) {
            const result = await db.select().from(socialProvidersTable).where(eq(socialProvidersTable.id, id));
            return result[0] ? result[0] as SocialProviderEntity : null;
        },
        async findByProvider(provider: string) {
            const result = await db.select().from(socialProvidersTable).where(eq(socialProvidersTable.provider, provider));
            return result[0] ? result[0] as SocialProviderEntity : null;
        },
        async findAllActive() {
            const result = await db.select().from(socialProvidersTable).where(eq(socialProvidersTable.isActive, true));
            return result as SocialProviderEntity[];
        },
        async findAll() {
            const result = await db.select().from(socialProvidersTable);
            return result as SocialProviderEntity[];
        },
        async paginate(query: TPaginateQuery<SocialProviderEntity>) {
            return pgPaginateFunction(db, socialProvidersTable, query);
        }
    };
};
