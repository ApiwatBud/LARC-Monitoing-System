import { and, eq, inArray, isNull } from "drizzle-orm";
import { PgDatabase } from "drizzle-orm/pg-core";
import { GenericPgTransactionalRepository } from "../../../../../common/repositories/generic.pg.repository";
import { ConfigEntity } from "../../../domains/entities/config.entity";
import { IConfigRepository } from "../../../domains/repositories/config.repository";
import { configsTable } from "../schema/config.pg.schema";
import { usersTable } from "../../../../core/persistents/pg/schema/user.pg.schema";
import { rowToEntity } from "../../../../../common/repositories/mapper";
import { AnyPgTransaction } from "../../../../../common/persistents/types";
import { IModuleRepository } from "../../../domains/repositories/module.repository";
import { ModuleEntity } from "../../../domains/entities/module.enity";
import { modulesTable } from "../schema/module.pg.schema";

export class ModulePgRepository extends GenericPgTransactionalRepository<ModuleEntity, typeof modulesTable> implements IModuleRepository {

    constructor(db: PgDatabase<any, any, any>) {
        super(db, "Module", modulesTable, "id", "deletedAt", usersTable);
    }

    async findByKey(props: { key: string, transaction?: AnyPgTransaction }): Promise<ModuleEntity | null> {
        const { key, transaction } = props;
        const client = this.getClient(transaction);
        const result = await client.select().from(this.table).where(
            and(
                eq(this.table.key, key),
                isNull(this.table.deletedAt)
            )
        ).limit(1);
        return result[0] ? rowToEntity<ModuleEntity>(result[0]) : null;
    }

    async resetActiveAllModule(props: { transaction?: AnyPgTransaction }): Promise<void> {
        const { transaction } = props;
        const client = this.getClient(transaction);
        await client.update(this.table).set({
            is_active: false,
            updatedAt: new Date(),
        });
    }

    async activateModuleByKey(props: { key: string, transaction?: AnyPgTransaction }): Promise<void> {
        const { key, transaction } = props;
        const client = this.getClient(transaction);
        await client.update(this.table).set({
            is_active: true,
            updatedAt: new Date(),
        }).where(eq(this.table.key, key));
    }

    async syncActivateModules(props: { keys: string[], transaction?: AnyPgTransaction }): Promise<void> {
        const { keys, transaction } = props;
        const client = this.getClient(transaction);
        //check if notexists insert
        const existingModules = await client.select().from(this.table).where(
            and(
                inArray(this.table.key, keys),
                isNull(this.table.deletedAt)
            )
        );
        const existingKeys = existingModules.map(row => row.key);
        const newKeys = keys.filter(key => !existingKeys.includes(key));
        for (const key of newKeys) {
            await client.insert(this.table).values({
                key,
                name: key,
                is_active: true,
                createdAt: new Date(),
                updatedAt: new Date(),
            }).onConflictDoNothing();
        }
        await client.update(this.table).set({
            is_active: false,
            updatedAt: new Date(),
        });
        await client.update(this.table).set({
            is_active: true,
            updatedAt: new Date(),
        }).where(inArray(this.table.key, keys));
    }

    async getActiveModules(props: { transaction?: AnyPgTransaction }): Promise<ModuleEntity[]> {
        const { transaction } = props;
        const client = this.getClient(transaction);
        const result = await client.select().from(this.table).where(
            and(
                eq(this.table.is_active, true),
                isNull(this.table.deletedAt)
            )
        );
        return result.map(row => rowToEntity<ModuleEntity>(row));
    }
}
