import { ITransactionalRepository } from "../../../../common/repositories/repository.interface";
import { ConfigEntity } from "../entities/config.entity";
import { AnyTransaction } from "../../../../common/persistents/types";

export interface IConfigRepository extends ITransactionalRepository<ConfigEntity> {
    findByKey(props: { key: string, transaction?: AnyTransaction }): Promise<ConfigEntity | null>;
}
