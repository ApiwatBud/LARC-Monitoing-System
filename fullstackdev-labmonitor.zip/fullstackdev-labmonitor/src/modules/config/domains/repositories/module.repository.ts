import { ModuleEntity } from "../entities/module.enity";
import { ITransactionalRepository } from "../../../../common/repositories/repository.interface";
import { AnyTransaction } from "../../../../common/persistents/types";

export interface IModuleRepository extends ITransactionalRepository<ModuleEntity> {
    getActiveModules(props: { transaction?: AnyTransaction }): Promise<ModuleEntity[]>;

    resetActiveAllModule(props: { transaction?: AnyTransaction }): Promise<void>;
    activateModuleByKey(props: { key: string, transaction?: AnyTransaction }): Promise<void>;
    syncActivateModules(props: { keys: string[], transaction?: AnyTransaction }): Promise<void>;
    findByKey(props: { key: string, transaction?: AnyTransaction }): Promise<ModuleEntity | null>;
}