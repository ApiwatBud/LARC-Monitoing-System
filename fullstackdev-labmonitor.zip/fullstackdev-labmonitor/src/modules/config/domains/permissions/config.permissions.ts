const ConfigPermissions = {
    ConfigRead: "config:read",
    ConfigWrite: "config:write",
    ModuleRead: "module:read",
    ModuleWrite: "module:write"
};

export default ConfigPermissions;
