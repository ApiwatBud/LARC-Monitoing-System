import { BaseEntity } from "../../../../common/domains/baseEntity";

export type ModuleEntity = BaseEntity & {
    key: string;
    name: string;
    description: string;
    icon: string;
    is_active: boolean;
}