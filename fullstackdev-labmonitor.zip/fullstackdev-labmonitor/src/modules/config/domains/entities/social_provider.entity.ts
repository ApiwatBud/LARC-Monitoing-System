import { BaseEntity } from "../../../../common/domains/baseEntity";

export type SocialProviderEntity = {
    provider: string; // e.g. 'google', 'line', 'microsoft'
    name: string; // Display name e.g. "Corporate Google"
    clientId: string;
    clientSecret: string;
    scopes: string[]; // List of scopes to request
    isActive: boolean;
    redirectUri?: string; // Optional override
} & BaseEntity
