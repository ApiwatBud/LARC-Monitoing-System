import { JustConfig } from "./config.entity"

export type SMTPEntity = {
    key: "SMTP",
    value: {
        host: string,
        port: number,
        secure: boolean,
        auth: {
            user: string,
            pass: string
        }
    }
} & JustConfig

