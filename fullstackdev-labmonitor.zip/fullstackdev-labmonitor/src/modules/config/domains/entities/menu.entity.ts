import React from "react";

export type ModuleMenu = {
    key: string
    name: string
    icon: React.ComponentType<{ size?: number; className?: string }> | string
    route?: string
    description?: string
    color?: string
    children?: ModuleMenu[]
    permissions?: string[]
    roles?: string[]
}
