import { BaseEntity } from "../../../../common/domains/baseEntity";
import { ConfigTypeEnum } from "../valueObjects/config.type";

export type JustConfig = {}

export type ConfigEntity = {
    key: string;
    type: ConfigTypeEnum;
    value: string;
} & BaseEntity

export type ConfigCreateEntity = Omit<ConfigEntity, keyof BaseEntity>
export type ConfigUpdateEntity = Partial<Omit<ConfigEntity, keyof BaseEntity>>

