import { ModuleMenu } from "./menu.entity";
import React from "react";

/**
 * Module metadata definition for module registry.
 * This interface standardizes how modules verify their identity, permissions, and UI structure.
 */
export interface IModuleMeta {
    /** Unique key for the module (e.g., 'labmonitor') */
    key: string;

    /** Display name of the module */
    name: string;

    /** Brief description of the module */
    description: string;

    /** Version string (semver) */
    version: string;

    /** Author or maintainer */
    author?: string;

    /** Main icon for the module */
    icon: any;

    /** 
     * Permission definitions for the module.
     * Can be an object (e.g. CorePermissions) 
     */
    permissions?: Record<string, string>;

    /**
     * Function to return the menu structure for this module.
     * This decouples the menu definition slightly, allowing for dynamic generation if needed.
     */
    menu: () => ModuleMenu;

    /**
     * Optional React Routes for the module.
     * This allows the module to define its own routing structure.
     */
    routes?: () => React.ReactNode;
}
