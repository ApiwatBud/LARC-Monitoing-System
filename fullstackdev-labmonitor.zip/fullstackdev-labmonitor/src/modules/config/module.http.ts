import Elysia from "elysia";
import { ConfigHttp } from "./applications/http/config.http";
import { ConfigIoC } from "./ioc";
import { SystemHttp } from "../core/applications/http/system.http";
import { socialProviderHttp } from "./applications/http/social_provider.http";

export const ConfigModule = new Elysia({
    detail: {
        tags: ["module"]
    }
})
    .use(ConfigIoC)
    .use(ConfigHttp)
    .use(SystemHttp)
    .use(socialProviderHttp)
