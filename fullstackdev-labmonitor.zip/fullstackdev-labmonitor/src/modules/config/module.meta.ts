import { FiActivity, FiBarChart2, FiBox, FiKey, FiMail, FiSettings, FiShield, FiUsers } from "react-icons/fi";
import ConfigPermissions from "./domains/permissions/config.permissions";
import { IModuleMeta } from "./domains/entities/module.meta";
import { CorePermissions } from "../core/domains/permissions";
import SystemRoutes from "../../public/pages/backoffice/system/routes";

/**
 * Metadata for the Config/System module.
 * Incorporates permissions from both Config module and Core module (users/roles/permissions)
 * as they are currently grouped under "System".
 */
export const ConfigMeta: IModuleMeta = {
    key: "system",
    name: "System",
    description: "Configure users, roles, permissions, and monitor system health.",
    version: "1.0.0",
    icon: FiSettings,
    permissions: {
        ...ConfigPermissions,
        // Since System menu includes Users/Roles/Permissions which are Core domains,
        // we might reference them here or keep them separate. 
        // For registry purposes, listing module-specific permissions is best.
    },
    menu: () => ({
        key: "system",
        name: "System",
        description: "Configure users, roles, permissions, and monitor system health.",
        color: "purple",
        icon: FiSettings,
        children: [
            {
                key: "dashboard",
                name: "Dashboard",
                icon: FiBarChart2,
                route: "/backoffice/system"
            },
            {
                key: "monitor",
                name: "System Monitor",
                icon: FiActivity,
                route: "/backoffice/system/monitor",
                permissions: ["anyone", CorePermissions.SystemRead]
            },
            {
                key: "users",
                name: "Users",
                icon: FiUsers,
                route: "/backoffice/system/users",
                permissions: [CorePermissions.UsersRead]
            },
            {
                key: "roles",
                name: "Roles",
                icon: FiShield,
                route: "/backoffice/system/roles",
                permissions: [CorePermissions.RolesRead]
            },
            {
                key: "permissions",
                name: "Permissions",
                icon: FiKey,
                route: "/backoffice/system/permissions",
                permissions: [CorePermissions.PermissionsRead]
            },
            {
                key: "configuration",
                name: "Configuration",
                icon: FiSettings,
                children: [
                    {
                        key: "smtp",
                        name: "SMTP Settings",
                        icon: FiMail,
                        route: "/backoffice/system/config/smtp",
                        permissions: [ConfigPermissions.ConfigRead]
                    },
                    {
                        key: "modules",
                        name: "Modules",
                        icon: FiBox,
                        route: "/backoffice/system/config/modules",
                        permissions: [ConfigPermissions.ModuleRead]
                    },
                    {
                        key: "social-providers",
                        name: "Social Providers",
                        icon: FiUsers, // Or generic icon
                        route: "/backoffice/system/config/social-providers",
                        permissions: [ConfigPermissions.ConfigRead]
                    }
                ]
            }
        ]
    }),
    routes: SystemRoutes
};
