import Elysia from "elysia";
import pgClient from "../../common/persistents/pgClient";
import { ConfigPgRepository } from "./persistents/pg/repositories/config.pg.repository";
import { ModulePgRepository } from "./persistents/pg/repositories/module.pg.repository";
import { ActivateModuleUsecase } from "./applications/usecases/module/activateModule";
import { DeactivateAllModulesUsecase } from "./applications/usecases/module/deactivateAllModules";
import { GetActiveModulesUsecase } from "./applications/usecases/module/getActiveModules";
import { SyncModulesUsecase } from "./applications/usecases/module/syncModule";

import { SocialProviderPgRepository } from "./persistents/pg/repositories/social_provider.pg.repository";

const configRepository = new ConfigPgRepository(pgClient);
const moduleRepository = new ModulePgRepository(pgClient);
const socialProviderRepository = SocialProviderPgRepository(pgClient);

const activateModuleUsecase = ActivateModuleUsecase({ moduleRepository });
const deactivateAllModulesUsecase = DeactivateAllModulesUsecase({ moduleRepository });
const getActiveModulesUsecase = GetActiveModulesUsecase({ moduleRepository });
const syncModulesUsecase = SyncModulesUsecase({ moduleRepository });
export const ConfigIoC = new Elysia()
    .decorate("configRepository", configRepository)
    .decorate("moduleRepository", moduleRepository)
    .decorate("socialProviderRepository", socialProviderRepository)
    .decorate("activateModuleUsecase", activateModuleUsecase)
    .decorate("deactivateAllModulesUsecase", deactivateAllModulesUsecase)
    .decorate("getActiveModulesUsecase", getActiveModulesUsecase)
    .decorate("syncModulesUsecase", syncModulesUsecase)