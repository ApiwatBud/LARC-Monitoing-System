import { Elysia } from "elysia";
import { BusinessValidationError, ForbiddenError, UnauthorizedError } from "./common/errors";
import { LogMiddleware } from "./common/utils/logger";
import { AIMoudle } from "../modules/ai/applications/http/ai.http";
import { ConfigModule } from "./modules/config/module.http";
import { CoreModule } from "./modules/core/module.http";
import { IS_DEV } from "./server_config";
import { LabmonitorModule } from "../modules/labmonitor/module.http";
import { ConfigIoC } from "./modules/config/ioc";
import ConfigPermissions from "./modules/config/domains/permissions/config.permissions";

const api = new Elysia({
    prefix: "/api",
    cookie: {
        httpOnly: true,
        secure: !IS_DEV,
        sameSite: 'lax'
    }
})
    .use(LogMiddleware)
    .error({
        BUSINESS_VALIDATION_ERROR: BusinessValidationError,
        UNAUTHORIZED: UnauthorizedError,
        FORBIDDEN: ForbiddenError
    })
    .onError(({ code, error, set }) => {
        if (code === 'BUSINESS_VALIDATION_ERROR') {
            set.status = 422
            return {
                status: 422,
                name: error.name,
                message: error.message,
                all: error.issues
            }
        }
        if (code === 'UNAUTHORIZED') {
            set.status = 401
            return {
                status: 401,
                name: error.name,
                message: error.message
            }
        }
        if (code === 'FORBIDDEN') {
            set.status = 403
            return {
                status: 403,
                name: error.name,
                message: error.message
            }
        }
    })
    .onStart(() => {
        console.log("API started");
        //deactivate all modules
        ConfigIoC.decorator.deactivateAllModulesUsecase({
            context: {
                user: { id: 1, username: "superadmin", email: "" },
                permissions: [ConfigPermissions.ModuleWrite]
            }
        }).then(() => {
            ConfigIoC.decorator.syncModulesUsecase({
                keys: ["core", "labmonitor", "ai"], context: {
                    permissions: [ConfigPermissions.ModuleWrite],
                    user: { id: 1, username: "superadmin", email: "" },

                }
            });
        });

    })
    .get("/health", () => {
        return {
            status: "online",
            timestamp: new Date().toISOString()
        }
    }, {
        log: false
    })
    .use(ConfigModule)
    .use(CoreModule)
    .use(LabmonitorModule)
    .use(AIMoudle)
    .group('/v1', (app) => app.use(LabmonitorModule))

export default api

export type Api = typeof api
