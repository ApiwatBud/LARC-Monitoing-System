import z from "zod";

export type TPaginateResult<T> = {
    data: T[];
    page: number;
    limit: number;
    total: number;
    totalPages: number;
}

export type TFilterOperator = "=" | "!=" | ">" | "<" | ">=" | "<=" | "like" | "ilike" | "in" | "not in" | "between"

export const TFilterOperatorList = [
    "=",
    "!=",
    ">",
    "<",
    ">=",
    "<=",]

//filter query support key,operator,value
export type TFilterQuery<T> = Array<{
    key: keyof T;
    operator: TFilterOperator;
    value: any;
}>;

export type TSortOrder = 'asc' | 'desc';

//sort query 
export type TSortQuery<T> = Array<{
    key: keyof T;
    order: TSortOrder;
}>;

export type TPaginateQuery<T> = {
    page: number;
    limit: number;
    filter: TFilterQuery<T>;
    sort: TSortQuery<T>;
    withAudit: boolean;
}

export type TPaginateQueryForm<T> = {
    page: number;
    limit: number;
    withAudit: boolean;
    filter: {
        [key: string]: {
            key: keyof T;
            operator: TFilterOperator;
            value: any;
        }
    };
    sort: TSortQuery<T>;
}



export const PaginateQueryDto = z.object({
    page: z.number().default(1),
    limit: z.number().default(20),
    filter: z.array(z.object({
        key: z.string(),
        operator: z.enum(["=", "!=", ">", "<", ">=", "<=", "like", "ilike", "in", "not in", "between"]),
        value: z.any()
    })).optional().default([]),
    sort: z.array(z.object({
        key: z.string(),
        order: z.enum(['asc', 'desc'])
    })).optional().default([]),
    withAudit: z.boolean().default(false)
});

export type TUsecase<D, P, R> = (deps: D) => (props: P) => Promise<R>