import { LibSQLDatabase } from "drizzle-orm/libsql";
import { BaseEntity } from "../domains/baseEntity";
import { TPaginateQuery, TPaginateResult } from "../types";
import { IRepository, ITransactionalRepository } from "./repository.interface";
import { SQLiteTransaction } from "drizzle-orm/sqlite-core";
import { AnyTransaction } from "../persistents/types";

export class GenericTransactionalMemoryRepository<AE extends BaseEntity> implements ITransactionalRepository<AE> {
    protected data: AE[] = [];
    protected nextId = 1;

    constructor(protected readonly entityName: string) {

    }
    transaction<T>(callback: (transaction: AnyTransaction) => Promise<T>): Promise<T> {
        throw new Error("Method not implemented.");
    }

    async create(props: { entity: Omit<AE, keyof BaseEntity>, transaction?: AnyTransaction, userId?: number }): Promise<AE> {
        const { entity, userId } = props;
        const row: AE = {
            ...entity,
            id: this.nextId++,
            createdAt: new Date(),
            updatedAt: new Date(),
            deletedAt: null,
            createdBy: userId ?? null,
            updatedBy: userId ?? null
        } as AE
        this.data.push(row);
        return row;
    }
    async update(props: { id: AE['id'], entity: Partial<Omit<AE, keyof BaseEntity>>, transaction?: AnyTransaction, userId?: number }): Promise<AE> {
        const { id, entity, userId } = props;
        const user = this.data.find(user => user.id === id);
        if (!user) {
            throw new Error(`${this.entityName} not found`);
        }
        let updatedUser: AE = { ...user };
        updatedUser = { ...updatedUser, ...entity };
        updatedUser.updatedAt = new Date();
        updatedUser.updatedBy = userId ?? user.updatedBy;
        this.data = this.data.map(user => user.id === id ? updatedUser : user);
        return updatedUser;
    }
    async delete(props: { id: AE['id'], transaction?: AnyTransaction }): Promise<AE> {
        const { id } = props;
        const user = this.data.find(user => user.id === id);
        if (!user) {
            throw new Error(`${this.entityName} not found`);
        }
        user.deletedAt = new Date();
        this.data = this.data.map(user => user.id === id ? user : user);
        return user;
    }
    async findById(props: { id: AE['id'], transaction?: AnyTransaction }): Promise<AE | null> {
        const { id } = props;
        const user = this.data.find(user => user.id === id);
        if (!user) {
            return null;
        }
        return user;
    }
    async findAll(props?: { transaction?: AnyTransaction }): Promise<AE[]> {
        return this.data;
    }
    async paginate(props: { query: TPaginateQuery<AE>, transaction?: AnyTransaction }): Promise<TPaginateResult<AE>> {
        const { query } = props;
        return paginateFunction(this.data, query);
    }
}

//AE = AnyEntity
export class GenericMemoryRepository<AE extends BaseEntity> extends GenericTransactionalMemoryRepository<AE> implements IRepository<AE> {
    constructor(entityName: string) {
        super(entityName);
    }

    async create(props: { entity: Omit<AE, keyof BaseEntity>, userId?: number }): Promise<AE> {
        return super.create(props);
    }
    async update(props: { id: AE['id'], entity: Partial<Omit<AE, keyof BaseEntity>>, userId?: number }): Promise<AE> {
        return super.update(props);
    }
    async delete(props: { id: AE['id'] }): Promise<AE> {
        return super.delete(props);
    }
    async findById(props: { id: AE['id'] }): Promise<AE | null> {
        return super.findById(props);
    }
    async findAll(): Promise<AE[]> {
        return super.findAll();
    }
    async paginate(props: { query: TPaginateQuery<AE> }): Promise<TPaginateResult<AE>> {
        return super.paginate(props);
    }
}

export function paginateFunction<AE>(dataStore: AE[], query: TPaginateQuery<AE>) {
    const { page = 1, limit = 10 } = query;
    const offset = (page - 1) * limit;
    let data: AE[] = dataStore;
    //filter data via query.filters
    if (query.filter) {
        data = data.filter(row => {
            return query.filter!.every(filter => {
                const rowValue = row[filter.key as keyof AE];
                if (filter.operator === "=") {
                    return rowValue === filter.value;
                } else if (filter.operator === "!=") {
                    return rowValue !== filter.value;
                } else if (filter.operator === ">") {
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue > filter.value;
                } else if (filter.operator === "<") {
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue < filter.value;
                } else if (filter.operator === ">=") {
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue >= filter.value;
                } else if (filter.operator === "<=") {
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue <= filter.value;
                } else if (filter.operator === "like") {
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue.toString().includes(filter.value);
                } else if (filter.operator === "ilike") {
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue.toString().toLowerCase().includes(filter.value.toLowerCase());
                } else if (filter.operator === "in") {
                    //filter values should be array
                    if (!Array.isArray(filter.value)) return false;
                    return filter.value.includes(rowValue);
                } else if (filter.operator === "not in") {
                    if (!Array.isArray(filter.value)) return false;
                    return !filter.value.includes(rowValue);
                } else if (filter.operator === "between") {
                    if (!Array.isArray(filter.value)) return false;
                    if (rowValue === null || rowValue === undefined) return false;
                    return rowValue >= filter.value[0] && rowValue <= filter.value[1];
                }
            })
        })
    }

    //order by query.sort by
    if (query.sort) {
        //sort is array of key and order
        data = data.sort((a, b) => {
            for (const sort of query.sort!) {
                const aValue = a[sort.key as keyof AE];
                const bValue = b[sort.key as keyof AE];
                if (sort.order === "asc") {
                    if (aValue < bValue) return -1;
                    if (aValue > bValue) return 1;
                } else {
                    if (aValue < bValue) return 1;
                    if (aValue > bValue) return -1;
                }
            }
            return 0;
        })
    }


    const total = data.length;
    data = data.slice(offset, offset + limit);
    const totalPages = Math.ceil(total / limit);


    return { data, page, limit, total, totalPages };
}