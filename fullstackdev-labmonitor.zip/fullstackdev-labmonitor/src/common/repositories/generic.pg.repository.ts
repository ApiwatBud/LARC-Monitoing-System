import { SQL, and, asc, between, count, desc, eq, getTableColumns, gt, gte, ilike, inArray, isNull, like, lt, lte, ne, notInArray, or } from "drizzle-orm";
import { PgDatabase, PgTable, alias } from "drizzle-orm/pg-core";
import { BaseEntity } from "../domains/baseEntity";
import { AnyPgTransaction, AnyTransaction } from "../persistents/types";
import { TPaginateQuery, TPaginateResult } from "../types";
import { rowToEntity } from "./mapper";
import { ITransactionalRepository } from "./repository.interface";

/**
 * Internal helper to build the data and count queries for pagination/export.
 */
export function pgBuildPaginationQuery<AE, TB extends PgTable>(
    client: PgDatabase<any, any, any> | AnyPgTransaction,
    table: TB,
    query: TPaginateQuery<AE>,
    options: {
        auditTable?: PgTable,
        deletedAtColumn?: keyof TB,
    } = {}
) {
    const { withAudit = false } = query;
    const { auditTable, deletedAtColumn } = options;

    const conditions: SQL[] = [];

    // Filter Logic
    if (query.filter) {
        query.filter.forEach(filter => {
            const cols = (filter.key as string).split("|");
            const orConditions: SQL[] = [];
            cols.forEach(col => {
                const column = table[col as keyof TB] as any;
                if (!column) return;

                const val = filter.value;
                switch (filter.operator) {
                    case "=": orConditions.push(eq(column, val)); break;
                    case "!=": orConditions.push(ne(column, val)); break;
                    case ">": orConditions.push(gt(column, val)); break;
                    case "<": orConditions.push(lt(column, val)); break;
                    case ">=": orConditions.push(gte(column, val)); break;
                    case "<=": orConditions.push(lte(column, val)); break;
                    case "like": orConditions.push(like(column, `%${val}%`)); break;
                    case "ilike": orConditions.push(ilike(column, `%${val}%`)); break;
                    case "in": orConditions.push(inArray(column, val)); break;
                    case "not in":
                        if (Array.isArray(val)) orConditions.push(notInArray(column, val));
                        break;
                    case "between":
                        if (Array.isArray(val) && val.length === 2) {
                            orConditions.push(between(column, val[0], val[1]));
                        }
                        break;
                }
            });

            if (orConditions.length > 0) {
                conditions.push(orConditions.length > 1 ? or(...orConditions)! : orConditions[0]);
            }
        });
    }

    // Soft Delete Logic
    if (deletedAtColumn) {
        conditions.push(isNull(table[deletedAtColumn] as any));
    }

    // Sort Logic
    const orderBy: SQL[] = [];
    if (query.sort) {
        query.sort.forEach(sort => {
            const col = table[sort.key as keyof TB] as any;
            if (col) {
                orderBy.push(sort.order === "asc" ? asc(col) : desc(col));
            }
        });
    }

    // Build Queries
    let countQuery = client.select({ count: count() }).from(table as any).$dynamic();
    let baseQuery: any;

    if (withAudit && auditTable) {
        const creator = alias(auditTable, "creator");
        const updater = alias(auditTable, "updater");
        baseQuery = client.select({
            ...getTableColumns(table as any),
            creatorName: (creator as any).username,
            updaterName: (updater as any).username,
        }).from(table as any)
            .leftJoin(creator, eq((table as any).createdBy, (creator as any).id))
            .leftJoin(updater, eq((table as any).updatedBy, (updater as any).id))
            .$dynamic();
    } else {
        baseQuery = client.select().from(table as any).$dynamic();
    }

    if (conditions.length > 0) {
        const whereClause = and(...conditions);
        baseQuery = baseQuery.where(whereClause);
        countQuery = countQuery.where(whereClause);
    }

    if (orderBy.length > 0) {
        baseQuery = baseQuery.orderBy(...orderBy);
    }

    return { baseQuery, countQuery };
}

/**
 * Generic PostgreSQL Pagination Helper
 */
export async function pgPaginateCore<AE, TB extends PgTable>(
    client: PgDatabase<any, any, any> | AnyPgTransaction,
    table: TB,
    query: TPaginateQuery<AE>,
    options: {
        auditTable?: PgTable,
        deletedAtColumn?: keyof TB,
        mapper?: (row: any) => AE
    } = {}
): Promise<TPaginateResult<AE>> {
    const { page = 1, limit = 10 } = query;
    const { mapper = (row: any) => row as AE } = options;

    const { baseQuery, countQuery } = pgBuildPaginationQuery(client, table, query, options);

    // Execute
    let dataQuery = baseQuery;
    const isNoLimit = limit === -1;

    if (!isNoLimit) {
        dataQuery = dataQuery.limit(limit).offset((page - 1) * limit);
    }

    const [data, [{ count: totalCount }]] = await Promise.all([
        dataQuery,
        countQuery
    ]);

    const total = Number(totalCount);

    return {
        data: data.map(mapper),
        page,
        limit,
        total,
        totalPages: isNoLimit ? 1 : Math.ceil(total / limit)
    };
}

export class GenericPgTransactionalRepository<AE extends BaseEntity, TB extends PgTable<any>> implements ITransactionalRepository<AE> {
    constructor(
        protected db: PgDatabase<any, any, any>,
        protected entityName: string,
        protected table: TB,
        protected idColumn: keyof TB,
        protected deletedAtColumn: keyof TB,
        protected auditTable?: PgTable
    ) { }

    protected getClient(transaction?: AnyPgTransaction) {
        return transaction || this.db;
    }

    async transaction<ANY>(callback: (transaction: AnyTransaction) => Promise<ANY>): Promise<ANY> {
        return this.db.transaction(async tx => {
            return await callback(tx);
        }) as Promise<ANY>;
    }

    async create(props: { entity: Omit<AE, keyof BaseEntity>, transaction?: AnyPgTransaction, userId?: number }): Promise<AE> {
        const { entity, transaction, userId } = props;
        const now = new Date();
        const payload = {
            ...entity,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            createdBy: userId ?? null,
            updatedBy: userId ?? null
        } as any;
        const [result] = await this.getClient(transaction).insert(this.table).values(payload).returning();
        return rowToEntity<AE>(result);
    }

    async update(props: { id: number, entity: Partial<Omit<AE, keyof BaseEntity>>, transaction?: AnyPgTransaction, userId?: number }): Promise<AE> {
        const { id, entity, transaction, userId } = props;
        const payload = {
            ...entity,
            updatedAt: new Date(),
            updatedBy: userId ?? null
        } as any;
        const [result] = await this.getClient(transaction).update(this.table)
            .set(payload)
            .where(eq(this.table[this.idColumn] as any, id))
            .returning();

        if (!result) {
            throw new Error(`${this.entityName} not found`);
        }

        return rowToEntity<AE>(result);
    }

    async delete(props: { id: number, transaction?: AnyPgTransaction }): Promise<AE> {
        const { id, transaction } = props;
        const [result] = await this.getClient(transaction).update(this.table)
            .set({ [this.deletedAtColumn]: new Date() } as any)
            .where(eq(this.table[this.idColumn] as any, id))
            .returning();

        if (!result) {
            throw new Error(`${this.entityName} not found`);
        }

        return rowToEntity<AE>(result);
    }

    async findById(props: { id: number, transaction?: AnyPgTransaction }): Promise<AE | null> {
        const { id, transaction } = props;
        const [result] = await this.getClient(transaction).select()
            .from(this.table as any)
            .where(and(
                eq(this.table[this.idColumn] as any, id),
                isNull(this.table[this.deletedAtColumn] as any)
            ))
            .limit(1);

        return result ? rowToEntity<AE>(result) : null;
    }

    async findAll(props?: { transaction?: AnyPgTransaction }): Promise<AE[]> {
        const result = await this.getClient(props?.transaction).select()
            .from(this.table as any)
            .where(isNull(this.table[this.deletedAtColumn] as any));
        return result.map(rowToEntity<AE>);
    }

    async paginate(props: { query: TPaginateQuery<AE>, transaction?: AnyPgTransaction }): Promise<TPaginateResult<AE>> {
        return pgPaginateCore<AE, TB>(this.getClient(props.transaction), this.table, props.query, {
            auditTable: this.auditTable,
            deletedAtColumn: this.deletedAtColumn,
            mapper: rowToEntity<AE>
        });
    }
}

/**
 * Legacy Pagination Function (Maintains backward compatibility)
 */
export async function pgPaginateFunction<AE extends BaseEntity, TB extends PgTable>(
    db: PgDatabase<any, any, any>,
    table: TB,
    query: TPaginateQuery<AE>,
    auditTable?: PgTable
): Promise<TPaginateResult<AE>> {
    return pgPaginateCore<AE, TB>(db, table, query, {
        auditTable,
        mapper: rowToEntity<AE>
    });
}

/**
 * Simple Entity Pagination Function (Maintains backward compatibility)
 */
export async function simplePgEntityPaginateFunction<AE, TB extends PgTable>(
    db: PgDatabase<any, any, any>,
    table: TB,
    query: TPaginateQuery<AE>,
    auditTable?: PgTable
): Promise<TPaginateResult<AE>> {
    return pgPaginateCore<AE, TB>(db, table, query, {
        auditTable,
        mapper: (row: any) => row as unknown as AE
    });
}
