import { LibSQLDatabase } from "drizzle-orm/libsql";
import { BaseEntity, AuditEntity } from "../domains/baseEntity";
import { TPaginateQuery, TPaginateResult } from "../types";
import { SQLiteTransaction } from "drizzle-orm/sqlite-core";
import { AnyTransaction } from "../persistents/types";

export interface IRepository<AnyEntity extends BaseEntity> {
    create(props: { entity: Omit<AnyEntity, keyof BaseEntity>, userId?: number }): Promise<AnyEntity>;
    update(props: { id: AnyEntity['id'], entity: Partial<Omit<AnyEntity, keyof BaseEntity>>, userId?: number }): Promise<AnyEntity>;
    delete(props: { id: AnyEntity['id'] }): Promise<AnyEntity>;
    findById(props: { id: AnyEntity['id'] }): Promise<AnyEntity | null>;
    findAll(): Promise<AnyEntity[]>;
    paginate(props: { query: TPaginateQuery<AnyEntity> }): Promise<TPaginateResult<AnyEntity>>;
}

export interface ITransactionalRepository<AnyEntity extends BaseEntity> {
    create(props: { entity: Omit<AnyEntity, keyof BaseEntity>, transaction?: AnyTransaction, userId?: number }): Promise<AnyEntity>;
    update(props: { id: AnyEntity['id'], entity: Partial<Omit<AnyEntity, keyof BaseEntity>>, transaction?: AnyTransaction, userId?: number }): Promise<AnyEntity>;
    delete(props: { id: AnyEntity['id'], transaction?: AnyTransaction }): Promise<AnyEntity>;
    findById(props: { id: AnyEntity['id'], transaction?: AnyTransaction }): Promise<AnyEntity | null>;
    findAll(props?: { transaction?: AnyTransaction }): Promise<AnyEntity[]>;
    paginate(props: { query: TPaginateQuery<AnyEntity>, transaction?: AnyTransaction }): Promise<TPaginateResult<AnyEntity>>;

    transaction<ANY>(callback: (transaction: AnyTransaction) => Promise<ANY>): Promise<ANY>;
}


export interface ITransactionalChildTableRepository<AnyEntity extends BaseEntity> {
    create(props: { parentId: AnyEntity[any], entity: Omit<AnyEntity, keyof BaseEntity | 'id'>, transaction?: AnyTransaction, userId?: number }): Promise<AnyEntity>;
    update(props: { id: AnyEntity['id'], parentId: AnyEntity[any], entity: Partial<Omit<AnyEntity, keyof BaseEntity | 'id'>>, transaction?: AnyTransaction, userId?: number }): Promise<AnyEntity>;
    delete(props: { id: AnyEntity['id'], parentId: AnyEntity[any], transaction?: AnyTransaction }): Promise<AnyEntity>;
    findById(props: { id: AnyEntity['id'], parentId: AnyEntity[any], transaction?: AnyTransaction }): Promise<AnyEntity | null>;
    findAll(props?: { parentId: AnyEntity[any], transaction?: AnyTransaction }): Promise<AnyEntity[]>;
    // paginate(props: { query: TPaginateQuery<AnyEntity>, parentId: AnyEntity[any], transaction?: AnyTransaction }): Promise<TPaginateResult<AnyEntity>>;
    transaction<ANY>(callback: (transaction: AnyTransaction) => Promise<ANY>): Promise<ANY>;
}

export interface ExportExportRepository<AnyEntity extends BaseEntity> {
    exportExcel(props: { query: TPaginateQuery<AnyEntity>, transaction?: AnyTransaction }): Promise<Buffer>;
}