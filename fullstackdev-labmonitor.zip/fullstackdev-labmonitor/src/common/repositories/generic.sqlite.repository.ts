import { SQL, SQL as SQLDrizzle, and, asc, between, count, desc, eq, getTableColumns, gt, gte, ilike, inArray, isNull, like, lt, lte, ne, notInArray, or } from "drizzle-orm";
import { LibSQLDatabase } from "drizzle-orm/libsql";
import { SQLiteTable, alias } from "drizzle-orm/sqlite-core";
import { BaseEntity } from "../domains/baseEntity";
import { AnySqliteTransaction, AnyTransaction } from "../persistents/types";
import { TPaginateQuery, TPaginateResult } from "../types";
import { rowToEntity } from "./mapper";
import { ITransactionalRepository } from "./repository.interface";



export class GenericSqliteTransactionalRepository<AE extends BaseEntity, TB extends SQLiteTable> implements ITransactionalRepository<AE> {
    constructor(protected db: LibSQLDatabase<any>,
        protected entityName: string,
        protected table: TB,
        protected idColumn: keyof TB,
        protected deletedAtColumn: keyof TB,
        protected auditTable?: SQLiteTable
    ) { }

    async transaction<ANY>(callback: (transaction: AnyTransaction) => Promise<ANY>): Promise<ANY> {
        return this.db.transaction(async tx => {
            return await callback(tx);
        }) as Promise<ANY>;
    }

    async create(props: { entity: Omit<AE, keyof BaseEntity>, transaction?: AnySqliteTransaction, userId?: number }): Promise<AE> {
        const { entity, transaction, userId } = props;
        const now = new Date().toISOString();
        const payload = {
            ...entity,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            createdBy: userId ?? null,
            updatedBy: userId ?? null
        } as TB["$inferInsert"];
        const client = transaction || this.db;
        const [result] = await client.insert(this.table).values(payload).returning();
        return rowToEntity<AE>(result);
    }

    async update(props: { id: number, entity: Partial<Omit<AE, keyof BaseEntity>>, transaction?: AnySqliteTransaction, userId?: number }): Promise<AE> {
        const { id, entity, transaction, userId } = props;
        const client = transaction || this.db;
        const payload = {
            ...entity,
            updatedAt: new Date().toISOString(),
            updatedBy: userId ?? null
        } as TB["$inferSelect"];
        const [result] = await client.update(this.table).set(payload).where(
            eq(this.table[this.idColumn] as any, id)).returning();

        if (!result) {
            throw new Error(`${this.entityName} not found`);
        }

        return rowToEntity<AE>(result);
    }
    async delete(props: { id: number, transaction?: AnySqliteTransaction }): Promise<AE> {
        const { id, transaction } = props;
        const client = transaction || this.db;
        const [result] = await client.update(this.table).set(
            { [this.deletedAtColumn]: new Date().toISOString() } as any
        ).where(eq(this.table[this.idColumn] as any, id)).returning();

        if (!result) {
            throw new Error(`${this.entityName} not found`);
        }

        return rowToEntity<AE>(result);
    }
    async findById(props: { id: number, transaction?: AnySqliteTransaction }): Promise<AE | null> {
        const { id, transaction } = props;
        const client = transaction || this.db;
        const [result] = await client.select().from(this.table).where(
            and(
                eq(this.table[this.idColumn] as any, id),
                isNull(this.table[this.deletedAtColumn] as any)
            )
        );
        if (!result) {
            return null;
        }
        return rowToEntity<AE>(result);
    }
    async findAll(props?: { transaction?: AnySqliteTransaction }): Promise<AE[]> {
        const transaction = props?.transaction;
        const client = transaction || this.db;
        const result = await client.select().from(this.table).where(
            isNull(this.table[this.deletedAtColumn] as any)
        );
        return result.map(rowToEntity<AE>);
    }
    async paginate(props: { query: TPaginateQuery<AE>, transaction?: AnySqliteTransaction }): Promise<TPaginateResult<AE>> {
        const { query, transaction } = props;
        const client = transaction || this.db;
        const { page = 1, limit = 10, withAudit = false } = query;
        const offset = (page - 1) * limit;

        let conditions: SQLDrizzle[] = []

        if (query.filter) {
            query.filter.forEach(filter => {
                let cols = (filter.key as string).split("|")
                let orCondition = [] as SQLDrizzle[]
                cols.forEach(col => {
                    if (filter.operator === "=") {
                        orCondition.push(eq(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === "!=") {
                        orCondition.push(ne(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === ">") {
                        orCondition.push(gt(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === "<") {
                        orCondition.push(lt(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === ">=") {
                        orCondition.push(gte(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === "<=") {
                        orCondition.push(lte(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === "like") {
                        orCondition.push(like(this.table[col as keyof TB] as any, `%${filter.value}%`));
                    } else if (filter.operator === "ilike") {
                        orCondition.push(ilike(this.table[col as keyof TB] as any, `%${filter.value}%`));
                    } else if (filter.operator === "in") {
                        orCondition.push(inArray(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === "not in") {
                        if (!Array.isArray(filter.value)) {
                            return;
                        }
                        orCondition.push(notInArray(this.table[col as keyof TB] as any, filter.value));
                    } else if (filter.operator === "between") {
                        orCondition.push(between(this.table[col as keyof TB] as any, filter.value[0], filter.value[1]));
                    }

                })

                if (orCondition.length > 1) {
                    const combined = or(...orCondition);
                    if (combined) {
                        conditions.push(combined);
                    }
                } else {
                    conditions.push(...orCondition);
                }
            })
        }

        //add deletedAt filter
        if (true) {
            conditions.push(isNull(this.table[this.deletedAtColumn] as any));
        }

        let orderBy: SQL[] = []

        if (query.sort) {
            query.sort.forEach(sort => {
                const col = this.table[sort.key as keyof TB] as any;
                if (sort.order === "asc") {
                    orderBy.push(asc(col));
                } else {
                    orderBy.push(desc(col));
                }
            })
        }

        let baseQuery: any;
        let countQuery = client.select({ count: count() }).from(this.table).$dynamic();

        if (withAudit && this.auditTable) {
            const creator = alias(this.auditTable, "creator");
            const updater = alias(this.auditTable, "updater");
            baseQuery = client.select({
                ...getTableColumns(this.table as any),
                creatorName: (creator as any).username,
                updaterName: (updater as any).username,
            }).from(this.table)
                .leftJoin(creator, eq((this.table as any).createdBy, (creator as any).id))
                .leftJoin(updater, eq((this.table as any).updatedBy, (updater as any).id))
                .$dynamic();
        } else {
            baseQuery = client.select().from(this.table).$dynamic();
        }

        if (query.filter) {
            baseQuery = baseQuery.where(and(...conditions));
            countQuery = countQuery.where(and(...conditions));
        }

        if (query.sort) {
            baseQuery = baseQuery.orderBy(...orderBy);
        }

        baseQuery = baseQuery.limit(limit).offset(offset);

        const [data, [{ count: totalCount }]] = await Promise.all([
            baseQuery,
            countQuery
        ]);

        return {
            data: data.map(rowToEntity<AE>),
            page,
            limit,
            total: totalCount,
            totalPages: Math.ceil(totalCount / limit)
        };
    }
}


export async function sqlitePaginateFunction<AE extends BaseEntity, TB extends SQLiteTable>(db: LibSQLDatabase<any>, table: TB, query: TPaginateQuery<AE>, auditTable?: SQLiteTable): Promise<TPaginateResult<AE>> {

    const client = db;
    const { page = 1, limit = 10, withAudit = false } = query;
    const offset = (page - 1) * limit;

    let conditions: SQLDrizzle[] = []

    if (query.filter) {
        query.filter.forEach(filter => {
            let cols = (filter.key as string).split("|")
            let orCondition = [] as SQLDrizzle[]
            cols.forEach(col => {
                if (filter.operator === "=") {
                    orCondition.push(eq(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "!=") {
                    orCondition.push(ne(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === ">") {
                    orCondition.push(gt(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "<") {
                    orCondition.push(lt(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === ">=") {
                    orCondition.push(gte(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "<=") {
                    orCondition.push(lte(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "like") {
                    orCondition.push(like(table[col as keyof TB] as any, `%${filter.value}%`));
                } else if (filter.operator === "ilike") {
                    orCondition.push(ilike(table[col as keyof TB] as any, `%${filter.value}%`));
                } else if (filter.operator === "in") {
                    orCondition.push(inArray(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "not in") {
                    if (!Array.isArray(filter.value)) {
                        return;
                    }
                    orCondition.push(notInArray(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "between") {
                    orCondition.push(between(table[col as keyof TB] as any, filter.value[0], filter.value[1]));
                }

            })

            if (orCondition.length > 1) {
                const combined = or(...orCondition);
                if (combined) {
                    conditions.push(combined);
                }
            } else {
                conditions.push(...orCondition);
            }
        })
    }

    let orderBy: SQL[] = []

    if (query.sort) {
        query.sort.forEach(sort => {
            const col = table[sort.key as keyof TB] as any;
            if (sort.order === "asc") {
                orderBy.push(asc(col));
            } else {
                orderBy.push(desc(col));
            }
        })
    }

    let baseQuery: any;
    let countQuery = client.select({ count: count() }).from(table).$dynamic();

    if (withAudit && auditTable) {
        const creator = alias(auditTable, "creator");
        const updater = alias(auditTable, "updater");
        baseQuery = client.select({
            ...getTableColumns(table as any),
            creatorName: (creator as any).username,
            updaterName: (updater as any).username,
        }).from(table)
            .leftJoin(creator, eq((table as any).createdBy, (creator as any).id))
            .leftJoin(updater, eq((table as any).updatedBy, (updater as any).id))
            .$dynamic();
    } else {
        baseQuery = client.select().from(table).$dynamic();
    }

    if (query.filter) {
        baseQuery = baseQuery.where(and(...conditions));
        countQuery = countQuery.where(and(...conditions));
    }

    if (query.sort) {
        baseQuery = baseQuery.orderBy(...orderBy);
    }

    baseQuery = baseQuery.limit(limit).offset(offset);

    const [data, [{ count: totalCount }]] = await Promise.all([
        baseQuery,
        countQuery
    ]);

    return {
        data: data.map(rowToEntity<AE>),
        page,
        limit,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limit)
    };
}

export async function simpleEntityPaginateFunction<AE, TB extends SQLiteTable>(db: LibSQLDatabase<any>, table: TB, query: TPaginateQuery<AE>, auditTable?: SQLiteTable): Promise<TPaginateResult<AE>> {

    const { page = 1, limit = 10, withAudit = false } = query;
    const offset = (page - 1) * limit;

    let conditions: SQL[] = []

    if (query.filter) {
        query.filter.forEach(filter => {
            let cols = (filter.key as string).split("|")
            let orCondition = [] as SQLDrizzle[]
            cols.forEach(col => {
                if (filter.operator === "=") {
                    orCondition.push(eq(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "!=") {
                    orCondition.push(ne(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === ">") {
                    orCondition.push(gt(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "<") {
                    orCondition.push(lt(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === ">=") {
                    orCondition.push(gte(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "<=") {
                    orCondition.push(lte(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "like") {
                    orCondition.push(like(table[col as keyof TB] as any, `%${filter.value}%`));
                } else if (filter.operator === "ilike") {
                    orCondition.push(ilike(table[col as keyof TB] as any, `%${filter.value}%`));
                } else if (filter.operator === "in") {
                    orCondition.push(inArray(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "not in") {
                    if (!Array.isArray(filter.value)) {
                        return;
                    }
                    orCondition.push(notInArray(table[col as keyof TB] as any, filter.value));
                } else if (filter.operator === "between") {
                    orCondition.push(between(table[col as keyof TB] as any, filter.value[0], filter.value[1]));
                }

            })

            if (orCondition.length > 1) {
                const combined = or(...orCondition);
                if (combined) {
                    conditions.push(combined);
                }
            } else {
                conditions.push(...orCondition);
            }
        })
    }

    let orderBy: SQL[] = []

    if (query.sort) {
        query.sort.forEach(sort => {
            const col = table[sort.key as keyof TB] as any;
            if (sort.order === "asc") {
                orderBy.push(asc(col));
            } else {
                orderBy.push(desc(col));
            }
        })
    }

    let baseQuery: any;
    let countQuery = db.select({ count: count() }).from(table).$dynamic();

    if (withAudit && auditTable) {
        const creator = alias(auditTable, "creator");
        const updater = alias(auditTable, "updater");
        baseQuery = db.select({
            ...getTableColumns(table as any),
            creatorName: (creator as any).username,
            updaterName: (updater as any).username,
        }).from(table)
            .leftJoin(creator, eq((table as any).createdBy, (creator as any).id))
            .leftJoin(updater, eq((table as any).updatedBy, (updater as any).id))
            .$dynamic();
    } else {
        baseQuery = db.select().from(table).$dynamic();
    }

    if (query.filter) {
        baseQuery = baseQuery.where(and(...conditions));
        countQuery = countQuery.where(and(...conditions));
    }

    if (query.sort) {
        baseQuery = baseQuery.orderBy(...orderBy);
    }

    baseQuery = baseQuery.limit(limit).offset(offset);

    const [data, [{ count: totalCount }]] = await Promise.all([
        baseQuery,
        countQuery
    ]);

    return {
        data: data.map((row: any) => row as unknown as AE),
        page,
        limit,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limit)
    };
}