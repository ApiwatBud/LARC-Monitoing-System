import { AuditEntity, BaseEntity, TimestampEntity } from "../domains/baseEntity";

export const rowToEntity = <AnyEntity extends BaseEntity>(row: any): AnyEntity => {
    return {
        ...row,
        createdAt: new Date(row.createdAt),
        updatedAt: new Date(row.updatedAt),
        deletedAt: row.deletedAt ? new Date(row.deletedAt) : null,
        createdBy: row.createdBy,
        updatedBy: row.updatedBy,
        creatorName: row.creatorName,
        updaterName: row.updaterName,
    };
}

export const rowToTimestampEntity = <AnyEntity extends TimestampEntity & AuditEntity>(row: any): AnyEntity => {
    return {
        ...row,
        createdAt: new Date(row.createdAt),
        updatedAt: new Date(row.updatedAt),
        createdBy: row.createdBy,
        updatedBy: row.updatedBy,
        creatorName: row.creatorName,
        updaterName: row.updaterName,
    };
}