import { and, eq, isNull } from "drizzle-orm";
import { PgDatabase, PgTable } from "drizzle-orm/pg-core";
import { BaseEntity } from "../../domains/baseEntity";
import { AnyPgTransaction } from "../../persistents/types";
import { rowToEntity } from "../mapper";
import { ITransactionalChildTableRepository } from "../repository.interface";

export class GenericChildPgTransactionalRepository<AE extends BaseEntity, TB extends PgTable<any>> implements ITransactionalChildTableRepository<AE> {
    constructor(protected db: PgDatabase<any, any, any>,
        protected entityName: string,
        protected table: TB,
        protected idColumn: keyof TB,
        protected parentIdColumn: keyof TB,
        protected deletedAtColumn?: keyof TB,
        protected auditTable?: PgTable
    ) { }

    async create(props: { parentId: AE[keyof AE], entity: Omit<AE, keyof BaseEntity | 'id'>, transaction?: AnyPgTransaction, userId?: number }): Promise<AE> {
        const { parentId, entity, transaction, userId } = props;
        const now = new Date();
        const payload = {
            ...entity,
            [this.parentIdColumn]: parentId,
            createdAt: now,
            updatedAt: now,
            deletedAt: null,
            createdBy: userId ?? null,
            updatedBy: userId ?? null
        } as any;
        const client = transaction || this.db;
        const [result] = await client.insert(this.table).values(payload).returning();
        return rowToEntity<AE>(result);
    }
    async update(props: { id: AE['id'], parentId: AE[keyof AE], entity: Partial<Omit<AE, keyof BaseEntity | 'id'>>, transaction?: AnyPgTransaction, userId?: number }): Promise<AE> {
        const { id, parentId, entity, transaction, userId } = props;
        const client = transaction || this.db;
        const payload = {
            ...entity,
            updatedAt: new Date(),
            updatedBy: userId ?? null
        } as any;
        const [result] = await client.update(this.table).set(payload).where(
            and(
                eq(this.table[this.idColumn] as any, id),
                eq(this.table[this.parentIdColumn] as any, parentId)
            )).returning();

        if (!result) {
            throw new Error(`${this.entityName} not found`);
        }

        return rowToEntity<AE>(result);
    }
    async delete(props: { id: AE['id'], parentId: AE[keyof AE], transaction?: AnyPgTransaction }): Promise<AE> {
        const { id, parentId, transaction } = props;
        const client = transaction || this.db;
        if (this.deletedAtColumn) {
            const [result] = await client.update(this.table).set(
                { [this.deletedAtColumn]: new Date() } as any
            ).where(and(
                eq(this.table[this.idColumn] as any, id),
                eq(this.table[this.parentIdColumn] as any, parentId)
            )).returning();

            if (!result) {
                throw new Error(`${this.entityName} not found`);
            }

            return rowToEntity<AE>(result);
        } else {
            const [result] = await client.delete(this.table).where(and(
                eq(this.table[this.idColumn] as any, id),
                eq(this.table[this.parentIdColumn] as any, parentId)
            )).returning();

            if (!result) {
                throw new Error(`${this.entityName} not found`);
            }

            return rowToEntity<AE>(result);
        }
    }
    async findById(props: { id: AE['id'], parentId: AE[keyof AE], transaction?: AnyPgTransaction }): Promise<AE | null> {
        const { id, parentId, transaction } = props;
        const client = transaction || this.db;
        const [result] = await client.select().from(this.table as any).where(
            and(
                eq(this.table[this.idColumn] as any, id),
                eq(this.table[this.parentIdColumn] as any, parentId),
                this.deletedAtColumn ? isNull(this.table[this.deletedAtColumn] as any) : undefined
            )
        ).limit(1);
        if (!result) {
            return null;
        }
        return rowToEntity<AE>(result);
    }

    async findAll(props?: { parentId: AE[keyof AE] }): Promise<AE[]> {
        const { parentId } = props || {};
        const client = this.db;
        const result = await client.select().from(this.table as any).where(
            and(
                eq(this.table[this.parentIdColumn] as any, parentId),
                this.deletedAtColumn ? isNull(this.table[this.deletedAtColumn] as any) : undefined
            )
        );
        return result.map(rowToEntity<AE>);
    }
    transaction<ANY>(callback: (transaction: AnyPgTransaction) => Promise<ANY>): Promise<ANY> {
        return this.db.transaction(callback);
    }
}