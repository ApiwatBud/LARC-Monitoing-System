export type TimestampEntity = {
    createdAt: Date;
    updatedAt: Date;
}

export type SoftDeleteEntity = {
    deletedAt: Date | null;
}

export type IdentityEntity = {
    id: number;
}

export type PublicIdentityEntity = {
    publicId: string;
}

export type AuditEntity = {
    createdBy: number | null;
    updatedBy: number | null;
    creatorName?: string | null;
    updaterName?: string | null;
}

export type JustEntity = {}
export type BaseEntity = JustEntity & TimestampEntity & SoftDeleteEntity & IdentityEntity & AuditEntity;
