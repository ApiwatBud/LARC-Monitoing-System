import { ResultSet } from "@libsql/client";
import { ExtractTablesWithRelations } from "drizzle-orm";
import { LibSQLDatabase } from "drizzle-orm/libsql";
import { PgDatabase, PgTransaction } from "drizzle-orm/pg-core";
import { BaseSQLiteDatabase, SQLiteTransaction } from "drizzle-orm/sqlite-core";

export type AnyDatabase = PgDatabase<any, any, any> | LibSQLDatabase<any>;


export type AnyPgTransaction = PgTransaction<any, any, any>;
export type AnySqliteTransaction = SQLiteTransaction<"async", ResultSet, any, ExtractTablesWithRelations<any>>;

export type AnyTransaction = AnyPgTransaction | AnySqliteTransaction

export type AuditorName = 'creatorName' | 'updaterName'
