import z from "zod";

export class BusinessValidationError extends Error {
    constructor(public issues: z.core.$ZodSuperRefineIssue[]) {
        super(issues[0]?.message || "Validation Failed");
        this.name = "BusinessValidationError";
    }
}

export class UnauthorizedError extends Error {
    constructor(message: string = "Unauthorized") {
        super(message);
        this.name = "UnauthorizedError";
    }
}

export class ForbiddenError extends Error {
    constructor(message: string = "Forbidden: You do not have permission") {
        super(message);
        this.name = "ForbiddenError";
    }
}
