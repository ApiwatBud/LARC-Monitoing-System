export let isNullOrUndefined = (x: any) => x === null || x === undefined
