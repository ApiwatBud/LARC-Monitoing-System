import { UnauthorizedError, ForbiddenError } from "../errors";
import { BackgroundTasks } from "elysia-background";
export interface UsecaseContext {
    user: {
        id: number | undefined;
        username: string;
        email: string;
    } | null;
    permissions: string[];
    backgroundTasks?: BackgroundTasks
}

export function ensurePermission(context: UsecaseContext, required: string | string[]) {
    const requiredList = Array.isArray(required) ? required : [required];

    // 1. ถ้าเป็น guest ให้ผ่าน (เผื่อ route สาธารณะ)
    if (requiredList.includes('guest')) return;

    // 2. ต้อง Login เสมอสำหรับสิทธิ์อื่นๆ
    if (!context.user) {
        throw new UnauthorizedError();
    }

    // 3. ถ้าเป็น anyone (แค่ login ก็ได้) ให้ผ่าน
    if (requiredList.includes('anyone')) return;

    // 4. Superadmin ให้ผ่านทุกอย่าง
    if (context.user.username === 'superadmin') return;

    // 5. เช็คว่ามี Permission ที่ต้องการอย่างน้อยหนึ่งอย่างหรือไม่
    const hasPermission = requiredList.some(p => context.permissions.includes(p));

    if (hasPermission) return;

    // 6. ถ้าสิทธิ์พิเศษ "self" จะต้องไปเช็คใน UseCase เองต่อ (Ownership check)
    if (requiredList.includes('role:self')) return;

    // 7. ถ้าไม่เข้าเงื่อนไขใดเลย ให้ Forbidden
    throw new ForbiddenError("You do not have permission to perform this action");
}

export function createGuard(context: UsecaseContext) {
    return {
        ensure: (required: string | string[]) => ensurePermission(context, required),
        user: context.user
    };
}
