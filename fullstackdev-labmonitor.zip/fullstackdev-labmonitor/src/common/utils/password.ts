import { PASSWORD_SECRET_KEY } from "../../server_config"

const internalHashAlgorithm = {
    algorithm: "argon2id",
    memoryCost: 65536,
    timeCost: 4,
} as Bun.Password.Argon2Algorithm

export const hashPassword = async (password: string) => {
    return await Bun.password.hash(password + PASSWORD_SECRET_KEY, internalHashAlgorithm)
}

export const verifyPassword = async (password: string, hash: string) => {
    return await Bun.password.verify(password + PASSWORD_SECRET_KEY, hash, internalHashAlgorithm.algorithm)
}

