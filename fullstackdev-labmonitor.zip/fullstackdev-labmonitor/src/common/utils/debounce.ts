export function debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
): (...args: Parameters<T>) => void {
    let timeout: ReturnType<typeof setTimeout> | null = null;
    return (...args: Parameters<T>) => {
        const next = () => func(...args);
        if (timeout) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(next, wait);
    };
}
