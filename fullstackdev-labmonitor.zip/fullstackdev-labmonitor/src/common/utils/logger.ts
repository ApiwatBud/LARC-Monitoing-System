import { Elysia } from 'elysia';
import pino from 'pino';
import path from 'path';

const logDir = path.join(process.cwd(), 'logs');

export const logger = pino({
    level: process.env.LOG_LEVEL || 'info',
}, pino.transport({
    targets: [
        {
            target: 'pino-pretty',
            level: 'info',
            options: {
                colorize: true,
                ignore: 'pid,hostname',
                translateTime: 'SYS:standard',
            }
        },
        {
            target: 'pino-roll',
            level: 'info',
            options: {
                file: path.join(logDir, 'app.log'),
                frequency: 'daily',
                mkdir: true,
                size: '10m', // Rotate when file size exceeds 10MB
                limit: {
                    count: 7 // Keep 7 logs
                }
            }
        }
    ]
}));

export const LogMiddleware = new Elysia({ name: 'log-middleware' })
    .macro({
        log(enabled: boolean) {
            return {
                resolve() {
                    return {
                        isLogEnabled: enabled
                    }
                }
            }
        }
    })
    .derive({ as: 'global' }, () => ({
        _startTime: Date.now(),
        isLogEnabled: true as boolean
    }))
    .onAfterHandle({ as: 'global' }, ({ request, set, _startTime, isLogEnabled }) => {
        if (isLogEnabled === false) {
            return;
        }

        const { method, url } = request;
        const duration = Date.now() - (_startTime || Date.now());

        logger.info({
            method,
            url,
            status: set.status,
            duration: `${duration}ms`,
        }, `[HTTP] ${method} ${url} ${set.status}`);
    })
    .onError({ as: 'global' }, ({ request, error, set, _startTime, isLogEnabled }) => {
        if (isLogEnabled === false) return;

        const { method, url } = request;
        const errorMsg = error instanceof Error ? error.message : String(JSON.stringify(error));
        const errorStack = error instanceof Error ? error.stack : undefined;
        const duration = Date.now() - (_startTime || Date.now());

        logger.error({
            method,
            url,
            status: set.status,
            error: errorMsg,
            stack: errorStack,
            duration: `${duration}ms`,
        }, `[HTTP Error] ${method} ${url} ${errorMsg}`);
    });

export const logRequest = LogMiddleware;
