import { DeviceCron } from "../modules/labmonitor/applications/http/device.worker";
import { Elysia } from "elysia";

import { SERVER_HOST } from "./server_config";

const app = new Elysia()
  .use(DeviceCron)
  .listen({
    port: 30001,
    hostname: SERVER_HOST
  });

console.log(
  `🦊 Cron is running at http://${app.server?.hostname}:${app.server?.port}`
);