export const APP_ENV = process.env.APP_ENV || "development"
export const IS_DEV = APP_ENV === "development"
export const SERVER_PORT = process.env.SERVER_PORT || 3000
export const SERVER_HOST = process.env.SERVER_HOST || "localhost"
export const SERVER_PROTOCOL = process.env.SERVER_PROTOCOL || "http"
export const SERVER_URL = `${SERVER_PROTOCOL}://${SERVER_HOST}:${SERVER_PORT}`
export const AUTH_SESSION_EXPIRES_IN_DAYS = Number(process.env.AUTH_SESSION_EXPIRES_IN_DAYS || 7)
export const PASSWORD_SECRET_KEY = process.env.PASSWORD_SECRET_KEY || "default-secret-key"
