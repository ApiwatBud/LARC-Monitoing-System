import { treaty, edenFetch } from '@elysiajs/eden'
import type { Api } from './api'

const API_URL = typeof window !== 'undefined' 
    ? (import.meta.env?.VITE_API_URL || window.location.origin) 
    : (process.env.PUBLIC_API_URL || 'http://localhost:3000');


export const client = treaty<Api>(API_URL, {
    fetch: {
        credentials: 'include' // Ensures cookies/auth headers are sent
    }
})

export const fetcher = edenFetch<Api>(API_URL, {
    fetcher: ((url, init) => {
        return fetch(url, {
            ...init,
            credentials: 'include',
        })
    }) as typeof fetch
})
