import { HeroUIProvider, Image, Navbar, NavbarBrand } from "@heroui/react";
import ReactDOM from "react-dom/client";

import uptilogo from "./assets/uptilogo.png";
import selogo from "./assets/selogo.png"
import ictlogo from "./assets/ictlogo.png"
import DeviceOverview from "../backoffice/overview";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

const queryClient = new QueryClient()

function App() {
    return (
        <QueryClientProvider client={queryClient}>
            <HeroUIProvider>
                <Navbar maxWidth="full" classNames={{
                    base: "bg-purple-400 p-0 h-24",
                    wrapper: "p-0 m-3 max-w-full",
                    content: "p-0 m-0"
                }}>
                    <NavbarBrand className="gap-1">
                        <Image className="h-20 p-1 bg-white  border-2 border-white" src={uptilogo} alt="UPTI Logo" />
                        <Image className="h-20 p-1 bg-white  border-2 border-white" src={ictlogo} alt="ICT Logo" />
                        <Image className="h-20 p-1 bg-white  border-2 border-white" src={selogo} alt="SE Logo" />
                    </NavbarBrand>
                </Navbar>
                <div className="p-3">
                    <DeviceOverview />
                </div>
            </HeroUIProvider>
        </QueryClientProvider>
    );
}


const root = document.getElementById("root");
ReactDOM.createRoot(root!).render(<App />);
