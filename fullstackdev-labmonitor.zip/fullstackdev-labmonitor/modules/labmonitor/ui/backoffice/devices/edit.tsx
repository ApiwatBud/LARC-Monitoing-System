import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardFooter, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Input, Modal, ModalBody, ModalContent, ModalFooter, ModalHeader, Select, SelectItem, Tab, Table, TableBody, TableCell, TableColumn, TableHeader, TableRow, Tabs, useDisclosure } from "@heroui/react";
import { ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FaEdit, FaPlus, FaTrash } from "react-icons/fa";
import { useNavigate, useParams } from "react-router";
import { client, fetcher } from "../../../../../src/client";
import { DeviceCreateDTO } from "../../../../../modules/labmonitor/applications/dtos/device.dto";
import { DeviceAggsCreateDTO, DeviceAggsUpdateDTO } from "../../../../../modules/labmonitor/applications/dtos/device.dto.aggs";
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DEVICE_METADATA_TYPE, DEVICE_SENSOR_TYPE, DEVICE_STATUS, DeviceSensorTypeMap } from "../../../../../modules/labmonitor/domains/valueObject";
import { DeleteDropdownItem } from "../../../../../src/public/components/Datatables/deleteDropdownItem";
import { ZZBYFieldSelect, ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../../src/public/components/ZZBYForm";
import { createColumnHelper, getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { flexRender } from "@tanstack/react-table";
import { useField, useStore } from "@tanstack/react-form";
import { PageContainer } from "../../../../../src/public/components/PageContainer";


export interface DeviceFormProps {
    form: any;
    mode: "CREATE" | "EDIT";
}
export function DeviceForm({ form, mode }: DeviceFormProps) {

    const connectionStatusOptions = Object.values(DEVICE_CONNECTION_STATUS).map(v => ({ label: v.toUpperCase(), value: v }));
    const dangerStatusOptions = Object.values(DEVICE_DANGER_STATUS).map(v => ({ label: v.toUpperCase(), value: v }));
    const statusOptions = Object.values(DEVICE_STATUS).map(v => ({ label: v.toUpperCase(), value: v }));

    return (<>
        <Tabs className="pt-3">
            <Tab key={'basic'} title="Basic Information" >
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                        <Card>
                            <CardHeader className="font-bold">
                                Device Identification
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFormFieldInput
                                    name="name"
                                    form={form}
                                    label="Device Name"
                                    placeholder="Enter device name"
                                />

                                <ZZBYFormFieldInput
                                    name="description"
                                    form={form}
                                    label="Description"
                                    placeholder="Enter description" />

                                <ZZBYFormFieldInput
                                    name="raw_id"
                                    form={form}
                                    label="Raw ID"
                                    placeholder="Enter raw hardware ID"
                                    type="number" />
                            </CardBody>
                        </Card>

                        <Card>
                            <CardHeader className="font-bold">
                                Status & Connectivity
                            </CardHeader>
                            <CardBody className="flex flex-col gap-3">
                                <ZZBYFieldSelect
                                    name="status"
                                    form={form}
                                    label="Operational Status"
                                    options={statusOptions}
                                />

                                <ZZBYFieldSelect
                                    name="connection_status"
                                    form={form}
                                    label="Connection Status"
                                    options={connectionStatusOptions}
                                />

                                <ZZBYFieldSelect
                                    name="danger_status"
                                    form={form}
                                    label="Danger Level"
                                    options={dangerStatusOptions}
                                />
                            </CardBody>
                        </Card>
                    </div>
                </div>
            </Tab>
            <Tab key={"device_env"} title="Device Environment">
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                        <DeviceEnvChildTable form={form} />
                    </div>
                </div>
            </Tab>

            <Tab key={"device_sensor"} title="Device Sensor">
                <div className='grid grid-cols-1 gap-3'>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                        <DeviceSensorChildTable form={form} />
                    </div>
                </div>
            </Tab>
        </Tabs >


    </>
    )
}
function DeviceEnvChildTable({ form }: any) {
    const addModal = useDisclosure();
    const columnHelper = createColumnHelper<any>();

    return (
        <Card>
            <CardHeader className="font-bold">
                Device Environment
            </CardHeader>
            <CardBody className="flex flex-col gap-3">
                <BasicChildTable

                    modalForm={(newEnv, setNewEnv, modalBodyRef) => (<>
                        <Input label="Key" value={newEnv.key} onChange={(e) => setNewEnv({ ...newEnv, key: e.target.value })} />
                        <Select
                            aria-label="Select Metadata"
                            label="Type"
                            selectedKeys={[newEnv.type]}
                            onChange={(e) => setNewEnv({ ...newEnv, type: e.target.value })}
                        >
                            <SelectItem aria-label="Text" key={DEVICE_METADATA_TYPE.TEXT}>Text</SelectItem>
                            <SelectItem aria-label="Number" key={DEVICE_METADATA_TYPE.NUMBER}>Number</SelectItem>
                            <SelectItem aria-label="Boolean" key={DEVICE_METADATA_TYPE.BOOLEAN}>Boolean</SelectItem>
                        </Select>
                        <Input label="Value" value={newEnv.value} onChange={(e) => setNewEnv({ ...newEnv, value: e.target.value })} />
                    </>)}

                    form={form} name="device_envs" addModal={addModal}
                    initialValue={{ key: '', type: DEVICE_METADATA_TYPE.TEXT as string, value: '' }}
                    columns={
                        [
                            columnHelper.accessor("key", { header: "Key" }),
                            columnHelper.accessor("type", { header: "Type" }),
                            columnHelper.accessor("value", { header: "Value" }),
                        ]
                    } />
            </CardBody>
            <CardFooter>
                <Button onPress={addModal.onOpen}>
                    <FaPlus />
                    Add Environment
                </Button>
            </CardFooter>
        </Card>
    )
}

function DeviceSensorChildTable({ form }: any) {
    const addModal = useDisclosure();
    const columnHelper = createColumnHelper<any>();

    const dangerStatusOptions = Object.values(DEVICE_DANGER_STATUS).map(v => ({ label: v.toUpperCase(), value: v }));
    const sensorTypeOptions = Object.values(DEVICE_SENSOR_TYPE).map(v => ({ label: DeviceSensorTypeMap[v], value: v }));

    return (
        <Card>
            <CardHeader className="font-bold">
                Device Sensors
            </CardHeader>
            <CardBody className="flex flex-col gap-3">
                <BasicChildTable
                    modalForm={(newSensor, setNewSensor, modalBodyRef) => (<>
                        <Input
                            label="Sensor ID"
                            placeholder="e.g. DHT11_1"
                            value={newSensor.sensor_id}
                            onChange={(e) => setNewSensor({ ...newSensor, sensor_id: e.target.value })}
                        />
                        <Select
                            label="Sensor Type"
                            selectedKeys={[newSensor.sensor_type]}
                            onChange={(e) => setNewSensor({ ...newSensor, sensor_type: e.target.value })}
                        >
                            {sensorTypeOptions.map((opt) => (
                                <SelectItem key={opt.value}>{opt.label}</SelectItem>
                            ))}
                        </Select>

                        <Select
                            label="Danger Status"
                            selectedKeys={[newSensor.danger_status]}
                            onChange={(e) => setNewSensor({ ...newSensor, danger_status: e.target.value })}
                        >
                            {dangerStatusOptions.map((opt) => (
                                <SelectItem key={opt.value}>{opt.label}</SelectItem>
                            ))}
                        </Select>

                        <div className="grid grid-cols-2 gap-3">
                            <Input
                                label="Normal Min"
                                placeholder="Min value"
                                type="number"
                                value={newSensor.normalMin?.toString() ?? ''}
                                onChange={(e) => setNewSensor({
                                    ...newSensor,
                                    normalMin: e.target.value ? parseFloat(e.target.value) : null
                                })}
                            />
                            <Input
                                label="Normal Max"
                                placeholder="Max value"
                                type="number"
                                value={newSensor.normalMax?.toString() ?? ''}
                                onChange={(e) => setNewSensor({
                                    ...newSensor,
                                    normalMax: e.target.value ? parseFloat(e.target.value) : null
                                })}
                            />
                        </div>
                    </>)}

                    form={form} name="device_sensors" addModal={addModal}
                    initialValue={{
                        sensor_id: '',
                        sensor_type: DEVICE_SENSOR_TYPE.TEMP,
                        danger_status: DEVICE_DANGER_STATUS.NORMAL,
                        normalMin: null,
                        normalMax: null
                    }}
                    columns={
                        [
                            columnHelper.accessor("sensor_id", { header: "Sensor ID" }),
                            columnHelper.accessor("sensor_type", {
                                header: "Type",
                                cell: (cell) => DeviceSensorTypeMap[cell.getValue() as DEVICE_SENSOR_TYPE] || cell.getValue()
                            }),

                            columnHelper.accessor("danger_status", {
                                header: "Status",
                                cell: (cell) => (
                                    <span className={`capitalize ${cell.getValue() === DEVICE_DANGER_STATUS.DANGER ? 'text-danger font-bold' : cell.getValue() === DEVICE_DANGER_STATUS.WARNING ? 'text-warning' : ''}`}>
                                        {cell.getValue()}
                                    </span>
                                )
                            }),
                            columnHelper.accessor("normalMin", {
                                header: "Min",
                                cell: (cell) => <span className="font-mono text-sm">{cell.getValue() ?? '-'}</span>
                            }),
                            columnHelper.accessor("normalMax", {
                                header: "Max",
                                cell: (cell) => <span className="font-mono text-sm">{cell.getValue() ?? '-'}</span>
                            }),
                        ]
                    } />
            </CardBody>
            <CardFooter>
                <Button onPress={addModal.onOpen}>
                    <FaPlus />
                    Add Sensor
                </Button>
            </CardFooter>
        </Card>
    )
}

interface BasicChildTableProps {
    form: any;
    name: string;
    addModal: ReturnType<typeof useDisclosure>;
    columns: any[];
    initialValue: any;
    modalForm: (newEnv: any, setNewEnv: (newEnv: any) => void, modalBodyRef: React.RefObject<HTMLDivElement | null>) => ReactNode
}
export function BasicChildTable({ form, name, addModal, columns, initialValue, modalForm }: BasicChildTableProps) {
    const { isOpen, onOpen, onOpenChange, onClose } = addModal;
    const [newEnv, setNewEnv] = useState(initialValue);
    const [editingIndex, setEditingIndex] = useState<number | null>(null);
    const modalBodyRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (!isOpen) {
            setNewEnv(initialValue);
            setEditingIndex(null);
        }
    }, [isOpen]);

    // 1. Get the field instance
    const field: any = useField({ form, name });

    // 2. Subscribe to the data reactively for the table
    const tableData = useStore(form.store, (state: any) => state.values[name]) || [];

    const handleEdit = (index: number) => {
        setEditingIndex(index);
        setNewEnv(tableData[index]); // Get from reactive data
        onOpen();
    };

    const handleDelete = (index: number) => {
        field.removeValue(index);
    };

    // 3. Memoize columns so they don't recreate on every form state change
    const tableColums = useMemo(() => {
        const columnHelper = createColumnHelper<any>();
        return [
            ...columns,
            columnHelper.display({
                id: "actions",
                header: "Actions",
                cell: (cell) => (
                    <div className="flex items-center gap-2">
                        <Button isIconOnly size="sm" color="primary" onPress={() => handleEdit(cell.row.index)}>
                            <FaEdit />
                        </Button>
                        <Button isIconOnly size="sm" color="danger" onPress={() => handleDelete(cell.row.index)}>
                            <FaTrash />
                        </Button>
                    </div>
                ),
            }),
        ];
    }, [tableData]); // Re-memoize if data length changes to update indices if needed

    const table = useReactTable({
        data: tableData,
        columns: tableColums,
        getCoreRowModel: getCoreRowModel(),
    });

    const getFieldError = (form: any, key: string, id?: number) => {
        const field = form.getAllErrors().fields;
        return field[`${name}[${id}].${key}`]?.errors[0].message
    };


    return (
        <form.Field name={name} mode="array">
            <div className="flex flex-col gap-2">
                {/* Validation Display */}
                {field.state.meta.isTouched && field.state.meta.errors.length > 0 && (
                    <p className="text-danger text-sm">{field.state.meta.errors.map((e: any) => e.message).join(', ')}</p>
                )}



                <Table aria-label={name} removeWrapper>
                    <TableHeader>
                        {table.getFlatHeaders().map(header => (
                            <TableColumn key={header.id}>
                                {flexRender(header.column.columnDef.header, header.getContext())}
                            </TableColumn>
                        ))}
                    </TableHeader>
                    <TableBody emptyContent={`No ${name} added`}>
                        {table.getRowModel().rows.map(row => (
                            <TableRow key={row.id}>
                                {row.getVisibleCells().map(cell => (
                                    <TableCell key={cell.id}>
                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}

                                        {
                                            getFieldError(form, cell.column.id, row.index) && (
                                                <p className="text-danger text-sm">{getFieldError(form, cell.column.id, row.index)}</p>
                                            )
                                        }

                                    </TableCell>
                                ))}
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>

            <Modal isOpen={isOpen} onOpenChange={onOpenChange} disableAnimation>
                <ModalContent>
                    {(onClose) => (
                        <>
                            <ModalHeader>{editingIndex !== null ? 'Edit' : 'Add'} Environment</ModalHeader>
                            <ModalBody>
                                <div ref={modalBodyRef} className="flex flex-col gap-3">
                                    {modalForm(newEnv, setNewEnv, modalBodyRef)}
                                </div>
                            </ModalBody>
                            <ModalFooter>
                                <Button color="danger" variant="light" onPress={onClose}>Close</Button>
                                <Button color="primary" onPress={() => {
                                    if (editingIndex !== null) {
                                        field.replaceValue(editingIndex, newEnv)
                                    } else {
                                        field.pushValue(newEnv)
                                    }
                                    setEditingIndex(null);
                                    field.handleBlur()
                                    field.validate('submit');
                                    onClose();
                                }}>
                                    Save
                                </Button>
                            </ModalFooter>
                        </>
                    )}
                </ModalContent>
            </Modal>
        </form.Field>
    );
}


export default function DeviceEdit() {
    const routeParams = useParams();
    const navigate = useNavigate();

    const idStr = routeParams.id as string;
    const id = idStr ? parseInt(idStr) : undefined;
    const mode: "EDIT" | "CREATE" = id ? "EDIT" : "CREATE"

    let formProps: ZZBYFormGeneratorWrapperProps<any>
    let queryKey = mode === "EDIT" ? ['device', id] : ['devices']
    let entityName = "Device"
    let validatorsOnSubmit = mode === "EDIT" ? DeviceAggsUpdateDTO : DeviceAggsCreateDTO

    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => mode === "EDIT" ? client.api.devices({ id: id! }).get() : null,
        enabled: mode === "EDIT" && !!id
    })

    if (mode === "EDIT") {
        if (itemQuery.isLoading) {
            return <div className="p-3">Loading...</div>
        }

        if (itemQuery.error) {
            throw itemQuery.error
        }

        if (!itemQuery.data?.data) {
            return (
                <div className="p-3">
                    <div className="mb-4">Device not found</div>
                    <Button color="primary" onPress={() => window.history.back()}>
                        Back
                    </Button>
                </div>
            )
        }

        const deviceData = itemQuery.data.data as any;

        formProps = {
            mode: mode,
            defaultValues: {
                name: deviceData.name,
                description: deviceData.description ?? '',
                status: deviceData.status,
                connection_status: deviceData.connection_status,
                danger_status: deviceData.danger_status,
                raw_id: deviceData.raw_id,
                device_envs: deviceData.device_envs,
                device_sensors: deviceData.device_sensors
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/devices/:id", {
                method: "PUT",
                body: value as any,
                params: { id: id!.toString() },
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/devices/${id}`)
        }

    } else {

        formProps = {
            mode: mode,
            defaultValues: {
                name: '',
                description: '',
                status: DEVICE_STATUS.ACTIVE,
                connection_status: DEVICE_CONNECTION_STATUS.OFFLINE,
                danger_status: DEVICE_DANGER_STATUS.NORMAL,
                raw_id: null,
                device_envs: [],
                device_sensors: []
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/devices", {
                method: "POST",
                body: value as any,
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/devices/${id}`, { replace: true })
        }
    }

    const backRoute = '/backoffice/labmonitor/devices';
    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{mode === "CREATE" ? "Create Device" : `Device Edit : ${id}`} </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/labmonitor/devices">Devices</BreadcrumbItem>
                                {
                                    mode === "CREATE"
                                        ? <BreadcrumbItem>Create Device</BreadcrumbItem>
                                        : <BreadcrumbItem href={`/backoffice/labmonitor/devices/${id}`}>Device Edit : {id}</BreadcrumbItem>
                                }
                            </Breadcrumbs>

                        </div>

                        <div className="flex flex-row gap-3">
                            {(
                                <Dropdown>
                                    <DropdownTrigger>
                                        <Button isIconOnly>
                                            <span className="text-lg font-bold">...</span>
                                        </Button>
                                    </DropdownTrigger>
                                    <DropdownMenu aria-label="Device Actions">
                                        {mode == "EDIT" ? DeleteDropdownItem({
                                            entityName: entityName,
                                            id: id!.toString(),
                                            backRoute: backRoute,
                                            deleteFn: () => fetcher("/api/devices/:id", {
                                                method: "DELETE",
                                                params: { id: id!.toString() },
                                                headers: {},
                                                body: {}
                                            })
                                        }) : null}

                                        <DropdownItem
                                            key="cancel"
                                            onPress={() => navigate(backRoute)}
                                        >
                                            Cancel
                                        </DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            )}

                            <Button color="primary" onPress={() => {
                                form.handleSubmit()
                            }}>
                                Save
                            </Button>
                        </div>

                    </div>
                    <DeviceForm form={form} mode={mode} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )

}
