import { BreadcrumbItem, Breadcrumbs, Button, Chip } from '@heroui/react'
import { client } from '../../../../../src/client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../src/common/types'
import { DeviceEntity } from "../../../../../modules/labmonitor/domains/entities/device.entity"
import { FilterFormDefs } from '../../../../../src/public/components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../../src/public/components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import { useNavigate } from 'react-router'
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DEVICE_STATUS } from '../../../../../modules/labmonitor/domains/valueObject'

export default function DeviceIndex() {
    const deviceColDefs: EntityColumn<DeviceEntity>[] = [
        {
            key: "id",
            header: "ID",
            cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
        },
        {
            key: "name",
            header: "Device Name",
            meta: { isTitle: true },
            cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
        },
        {
            key: "connection_status",
            header: "Connection",
            cell: (info) => {
                const status = info.getValue() as DEVICE_CONNECTION_STATUS
                return (
                    <Chip
                        size="sm"
                        variant="flat"
                        color={status === DEVICE_CONNECTION_STATUS.ONLINE ? "success" : "danger"}
                    >
                        {status.toUpperCase()}
                    </Chip>
                )
            },
        },
        {
            key: "danger_status",
            header: "Danger Status",
            cell: (info) => {
                const status = info.getValue() as DEVICE_DANGER_STATUS
                let color: "default" | "warning" | "danger" | "success" = "default"
                if (status === DEVICE_DANGER_STATUS.WARNING) color = "warning"
                if (status === DEVICE_DANGER_STATUS.DANGER) color = "danger"
                if (status === DEVICE_DANGER_STATUS.NORMAL) color = "success"
                return <Chip size="sm" variant="dot" color={color}>{status.toUpperCase()}</Chip>
            },
        },
        {
            key: "status",
            header: "Status",
            cell: (info) => {
                const status = info.getValue() as DEVICE_STATUS
                return <Chip size="sm" variant="bordered" color={status === DEVICE_STATUS.ACTIVE ? "primary" : "default"}>{status.toUpperCase()}</Chip>
            },
        },
        {
            key: "last_seen",
            header: "Last Seen",
            cell: (info) => <span className="text-gray-500">{info.getValue() ? new Date(info.getValue()).toLocaleString() : "Never"}</span>,
        },
    ]

    const deviceDefaultFilter: TPaginateQueryForm<DeviceEntity> = {
        page: 1,
        limit: 20,
        withAudit: true,
        filter: {
            keyword: {
                key: 'name' as keyof DeviceEntity,
                operator: 'ilike' as TFilterOperator,
                value: ''
            },
        },
        sort: [{ key: 'id', order: 'desc' as TSortOrder }]
    }

    const deviceFilterForm: FilterFormDefs[] = [
        {
            widget: 'text',
            label: 'Device Name',
            name: 'keyword'
        }
    ]

    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Devices Management</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor/devices">Devices</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <Button color="primary" onPress={() => navigate('/backoffice/labmonitor/devices/create')}>
                    Add Device
                </Button>
            </div>
            <GenericDataTable<DeviceEntity>
                queryKey={['devices']}
                queryFn={client.api.devices.filter.post}
                viewRoute="/backoffice/labmonitor/devices/:id"
                colDefs={deviceColDefs}
                defaultFilter={deviceDefaultFilter}
                filterFormDefs={deviceFilterForm}
            />
        </PageContainer>
    )
}
