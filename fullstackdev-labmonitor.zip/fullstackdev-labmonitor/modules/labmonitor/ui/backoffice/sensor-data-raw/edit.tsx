import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger, Textarea } from '@heroui/react'
import { useQuery } from '@tanstack/react-query'
import { useNavigate, useParams } from 'react-router'
import { client, fetcher } from "../../../../../src/client"
import { DeviceSensorDataRawCreateDTO, DeviceSensorDataRawUpdateDTO } from "../../../../../modules/labmonitor/applications/dtos/device_sensor_data_raw.dto"
import { PROCESS_STATUS } from '../../../../../modules/labmonitor/domains/valueObject'
import { DeleteDropdownItem } from '../../../../../src/public/components/Datatables/deleteDropdownItem'
import { ZZBYFieldAutocomplete, ZZBYFieldSelect, ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper, ZZBYJsonTextarea } from '../../../../../src/public/components/ZZBYForm'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import DynamicReactJsonView from '@microlink/react-json-view'
import { useField } from '@tanstack/react-form'
import { useEffect, useState } from "react"

const ReactJsonView: any = (DynamicReactJsonView as any).default || DynamicReactJsonView;

export function DeviceSensorDataRawForm({ form, isEdit }: { form: any, isEdit: boolean }) {
    const statusOptions = Object.values(PROCESS_STATUS).map(v => ({ label: v.toUpperCase(), value: v }));

    const deviceNameField = useField({
        form, // ส่ง form instance ที่คุณมีเข้าไป
        name: 'device_name',
    })

    const processLogField = useField({
        form,
        name: 'process_log',
    })

    const [isClient, setIsClient] = useState(false)
    useEffect(() => {
        setIsClient(true)
    }, [])

    useEffect(() => {
        if (isEdit) {
            return
        }
        else if (deviceNameField.state.value && !isEdit) {
            client.api.devices.byName({ name: deviceNameField.state.value as string }).deviceSensors.get().then(
                (r: any) => {
                    console.log(r)
                    const sensors = r.data.reduce((acc: any, sensor: any) => {
                        acc[sensor.sensor_id] = ""
                        return acc
                    }, {})
                    form.setFieldValue('values', JSON.stringify(sensors, null, 2))
                }
            )
        } else {
            form.setFieldValue('values', JSON.stringify({}, null, 2))
        }
    }, [deviceNameField.state.value]);

    const getProcessLogObj = () => {
        const val = processLogField.state.value
        if (!val) return {}
        try {
            return typeof val === 'string' ? JSON.parse(val) : val
        } catch (e) {
            return { error: "Failed to parse process log", raw: val }
        }
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            <Card>
                <CardHeader className="font-bold">Identification</CardHeader>
                <CardBody className="flex flex-col gap-3">

                    {isEdit ? (
                        <ZZBYFormFieldInput
                            name="device_name"
                            form={form}
                            label="Device Name"
                            type="text"
                            isReadOnly={true}
                        />
                    ) : (
                        <ZZBYFieldAutocomplete
                            name="device_name"
                            form={form}
                            label="Device Name"
                            isReadOnly={isEdit}
                            queryFn={(s) => client.api.devices.filter.post({ page: 1, limit: 100, filter: s ? [{ key: 'name', operator: 'ilike', value: s }] : [], sort: [], withAudit: false })}
                            mapFn={(item: any) => ({ label: item.name, value: item.name })}
                        />
                    )}
                </CardBody>
            </Card>

            <div className="md:col-span-2">
                <Card>
                    <CardHeader className="font-bold">Payload (JSON)</CardHeader>
                    <CardBody>
                        <ZZBYJsonTextarea
                            name="values"
                            form={form}
                            label="Payload"
                            isReadOnly={isEdit}
                        />
                    </CardBody>
                </Card>

                <Card>
                    <CardHeader className="font-bold">Process Log</CardHeader>
                    <CardBody>


                        {isClient && (
                            <ReactJsonView
                                src={getProcessLogObj()}
                                name={false}
                                collapsed={2}
                                displayDataTypes={false}
                                theme="monokai"
                            />
                        )}
                    </CardBody>
                </Card>
            </div>
        </div>
    )
}

export default function DeviceSensorDataRawEdit() {
    const { id } = useParams()
    const navigate = useNavigate()
    const isEdit = id !== undefined && id !== 'create'
    const entityName = "Raw Sensor Data"
    const queryKey = ['device-sensor-data-raw', id]
    const backRoute = '/backoffice/labmonitor/sensor-data-raw'

    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => isEdit ? client.api["device-sensor-data-raw"]({ id: Number(id) }).get() : null,
        enabled: isEdit
    })

    if (isEdit && itemQuery.isLoading) return <div className="p-3">Loading...</div>

    const formProps: ZZBYFormGeneratorWrapperProps<any> = isEdit ? {
        mode: "EDIT",
        defaultValues: {
            ...itemQuery.data?.data,
            values: JSON.stringify(itemQuery.data?.data?.values, null, 2)
        } as any,
        validators: {
            onSubmit: DeviceSensorDataRawUpdateDTO
        },
        apiSubmit: (value: any) => {
            let parsedValues = value.values;
            try {
                parsedValues = typeof value.values === 'string' ? JSON.parse(value.values) : value.values;
            } catch (e) {
                // if invalid json, we might want to alert here, but usually DTO or backend will catch
            }
            return fetcher("/api/device-sensor-data-raw/:id", {
                method: "PUT",
                body: { ...value, values: parsedValues },
                params: { id: id! },
                headers: {}
            })
        },
        entityName,
        queryKey: ['device-sensor-data-raw'],
        redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/sensor-data-raw/${id}`)
    } : {
        mode: "CREATE",
        defaultValues: {
            device_id: 0,
            device_name: '',
            process_status: PROCESS_STATUS.PENDING,
            values: '{}'
        },
        validators: {
            onSubmit: DeviceSensorDataRawCreateDTO
        },
        apiSubmit: (value: any) => {
            let parsedValues = value.values;
            try {
                parsedValues = typeof value.values === 'string' ? JSON.parse(value.values) : value.values;
            } catch (e) {
                // fallback or let backend catch
            }
            return fetcher("/api/device-sensor-data-raw", {
                method: "POST",
                body: { ...value, values: parsedValues },
                headers: {}
            })
        },
        entityName,
        queryKey: ['device-sensor-data-raw'],
        redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/sensor-data-raw/${id}`, { replace: true })
    }

    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">
                                {isEdit ? `View Raw Data: #${id}` : 'Create Raw Data'}
                            </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/labmonitor/sensor-data-raw">Raw Sensor Data</BreadcrumbItem>
                                <BreadcrumbItem>{isEdit ? `View : ${id}` : 'Create'}</BreadcrumbItem>
                            </Breadcrumbs>
                        </div>

                        <div className="flex gap-3">
                            <Dropdown>
                                <DropdownTrigger>
                                    <Button isIconOnly>
                                        <span className="text-lg font-bold">...</span>
                                    </Button>
                                </DropdownTrigger>
                                <DropdownMenu aria-label="Actions">
                                    {isEdit ? DeleteDropdownItem({
                                        entityName,
                                        id: id!,
                                        backRoute,
                                        deleteFn: () => fetcher("/api/device-sensor-data-raw/:id", {
                                            method: "DELETE",
                                            params: { id: id! },
                                            headers: {},
                                            body: {}
                                        })
                                    }) : null}
                                    <DropdownItem key="cancel" onPress={() => navigate(backRoute)}>
                                        Cancel
                                    </DropdownItem>
                                </DropdownMenu>
                            </Dropdown>

                            {!isEdit && (
                                <Button color="primary" onPress={() => form.handleSubmit()}>
                                    Save
                                </Button>
                            )}
                        </div>
                    </div>

                    <DeviceSensorDataRawForm form={form} isEdit={isEdit} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )
}
