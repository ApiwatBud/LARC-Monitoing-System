import { BreadcrumbItem, Breadcrumbs, Button, Chip } from '@heroui/react'
import { client } from '../../../../../src/client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../src/common/types'
import { DeviceSensorDataRawEntity } from "../../../../../modules/labmonitor/domains/entities/device_sensor_data_raw.entity"
import { FilterFormDefs } from '../../../../../src/public/components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../../src/public/components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import { PROCESS_STATUS } from '../../../../../modules/labmonitor/domains/valueObject'
import { useNavigate } from 'react-router'

export default function DeviceSensorDataRawIndex() {
    const colDefs: EntityColumn<DeviceSensorDataRawEntity>[] = [
        {
            key: "id",
            header: "ID",
            cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
        },
        {
            key: "device_id",
            header: "Device ID",
            cell: (info) => <span className="font-mono text-gray-600">#{info.getValue()}</span>,
        },
        {
            key: "device_name",
            header: "Device Name",
            meta: { isTitle: true },
            cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
        },
        {
            key: "process_status",
            header: "Process Status",
            cell: (info) => {
                const status = info.getValue() as PROCESS_STATUS
                let color: "default" | "success" | "danger" | "warning" = "default"
                if (status === PROCESS_STATUS.COMPLETED) color = "success"
                if (status === PROCESS_STATUS.FAILED) color = "danger"
                if (status === PROCESS_STATUS.PENDING) color = "warning"
                return (
                    <Chip
                        size="sm"
                        variant="flat"
                        color={color}
                    >
                        {status.toUpperCase()}
                    </Chip>
                )
            },
        },
        {
            key: "values",
            header: "Values",
            cell: (info) => {
                const values = info.getValue()
                const jsonStr = JSON.stringify(values)
                return <div className="text-xs max-w-md truncate font-mono text-gray-500" title={jsonStr}>{jsonStr}</div>
            },
        },
        {
            key: "createdAt",
            header: "Created At",
            cell: (info) => <span className="text-gray-500">{new Date(info.getValue()).toLocaleString()}</span>,
        },
    ]

    const defaultFilter: TPaginateQueryForm<DeviceSensorDataRawEntity> = {
        page: 1,
        limit: 20,
        withAudit: true,
        filter: {
            device_name: {
                key: 'device_name' as keyof DeviceSensorDataRawEntity,
                operator: 'ilike' as TFilterOperator,
                value: ''
            },
        },
        sort: [{ key: 'createdAt', order: 'desc' as TSortOrder }]
    }

    const filterForm: FilterFormDefs[] = [
        {
            widget: 'text',
            label: 'Device Name',
            name: 'device_name'
        },
    ]

    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Raw Sensor Data</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor/sensor-data-raw">Raw Sensor Data</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <Button color="primary" onPress={() => navigate('/backoffice/labmonitor/sensor-data-raw/create')}>
                    Add Raw Data
                </Button>
            </div>
            <GenericDataTable<DeviceSensorDataRawEntity>
                queryKey={['device-sensor-data-raw']}
                queryFn={client.api["device-sensor-data-raw"].filter.post}
                viewRoute="/backoffice/labmonitor/sensor-data-raw/:id"
                colDefs={colDefs}
                defaultFilter={defaultFilter}
                filterFormDefs={filterForm}
            />
        </PageContainer>
    )
}
