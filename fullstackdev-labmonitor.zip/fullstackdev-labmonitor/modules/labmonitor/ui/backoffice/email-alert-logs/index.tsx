import { BreadcrumbItem, Breadcrumbs, Chip, Tooltip } from '@heroui/react'
import { client } from '../../../../../src/client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../src/common/types'
import { EmailAlertLogEntity } from "../../../../../modules/labmonitor/domains/entities/email_alert_log.entity"
import { FilterFormDefs } from '../../../../../src/public/components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../../src/public/components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import { FiMail, FiInfo } from 'react-icons/fi'

const colDefs: EntityColumn<EmailAlertLogEntity>[] = [
    {
        key: "id",
        header: "ID",
        cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
    },
    {
        key: "sent_at",
        header: "Sent At",
        cell: (info) => <span className="text-gray-900 font-medium">{new Date(info.getValue()).toLocaleString('th-TH')}</span>,
    },
    {
        key: "device_name",
        header: "Device",
        meta: { isTitle: true },
        cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
    },
    {
        key: "alert_type",
        header: "Type",
        cell: (info) => {
            const type = info.getValue() as string;
            return (
                <Chip
                    size="sm"
                    variant="flat"
                    color={type.includes('warning') ? 'warning' : 'default'}
                >
                    {type.replace('_', ' ').toUpperCase()}
                </Chip>
            );
        },
    },
    {
        key: "recipients",
        header: "Recipients",
        cell: (info) => (
            <Tooltip content={info.getValue()}>
                <div className="flex items-center gap-1 text-gray-600 max-w-[150px] truncate cursor-help">
                    <FiMail className="shrink-0" />
                    <span>{info.getValue()}</span>
                </div>
            </Tooltip>
        ),
    },
    {
        key: "subject",
        header: "Subject",
        cell: (info) => (
            <Tooltip content={info.getValue()}>
                <span className="text-gray-700 block max-w-[200px] truncate cursor-help italic">
                    {info.getValue()}
                </span>
            </Tooltip>
        ),
    },
    {
        key: "message_id",
        header: "Message ID",
        cell: (info) => info.getValue() ? (
            <Tooltip content={info.getValue()}>
                <span className="text-xs text-gray-400 font-mono truncate block max-w-[100px]">
                    {info.getValue()}
                </span>
            </Tooltip>
        ) : '-',
    }
]

const defaultFilter: TPaginateQueryForm<EmailAlertLogEntity> = {
    page: 1,
    limit: 10,
    withAudit: false,
    filter: {
        device_name: {
            key: 'device_name' as keyof EmailAlertLogEntity,
            operator: 'ilike' as TFilterOperator,
            value: ''
        }
    },
    sort: [{ key: 'sent_at', order: 'desc' as TSortOrder }]
}

const filterForm: FilterFormDefs[] = [
    {
        widget: 'text',
        label: 'Device Name',
        name: 'device_name'
    },
    {
        widget: 'select',
        label: 'Alert Type',
        name: 'alert_type',
        options: [
            { label: 'Device Warning', value: 'device_warning' },
            { label: 'Summary Warning', value: 'summary_warning' },
            { label: 'Sensor Warning', value: 'sensor_warning' },
        ]
    }
]

export default function EmailAlertLogIndex() {
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Email Alert History</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor">Lab Monitor</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor/email-alert-logs">Alert History</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
            </div>
            <GenericDataTable<EmailAlertLogEntity>
                queryKey={['email-alert-logs']}
                queryFn={client.api['email-alert-logs'].filter.post}
                colDefs={colDefs}
                defaultFilter={defaultFilter}
                filterFormDefs={filterForm}
            />
        </PageContainer>
    )
}
