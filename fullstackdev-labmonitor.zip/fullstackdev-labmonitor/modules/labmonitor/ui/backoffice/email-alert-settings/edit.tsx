import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router";
import { client, fetcher } from "../../../../../src/client";
import { EmailAlertSettingCreateDto, EmailAlertSettingUpdateDto } from "../../../../../modules/labmonitor/applications/dtos/email_alert_setting.dto";
import { DeleteDropdownItem } from "../../../../../src/public/components/Datatables/deleteDropdownItem";
import { ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../../src/public/components/ZZBYForm";
import { PageContainer } from "../../../../../src/public/components/PageContainer";

export interface EmailAlertSettingFormProps {
    form: any;
    mode: "CREATE" | "EDIT";
}

export function EmailAlertSettingForm({ form, mode }: EmailAlertSettingFormProps) {
    return (
        <div className='grid grid-cols-1 gap-3 pt-3'>
            <Card>
                <CardHeader className="font-bold">
                    Email Alert Recipient
                </CardHeader>
                <CardBody className="flex flex-col gap-3">
                    <ZZBYFormFieldInput
                        name="recipientEmail"
                        form={form}
                        label="Recipient Email"
                        placeholder="Enter email address"
                        type="email"
                    />
                </CardBody>
            </Card>
        </div>
    )
}

export default function EmailAlertSettingEdit() {
    const routeParams = useParams();
    const navigate = useNavigate();

    const idStr = routeParams.id as string;
    const id = idStr ? parseInt(idStr) : undefined;
    const mode: "EDIT" | "CREATE" = id ? "EDIT" : "CREATE"

    let formProps: ZZBYFormGeneratorWrapperProps<any>
    let queryKey = mode === "EDIT" ? ['email-alert-setting', id] : ['email-alert-settings']
    let entityName = "Email Alert Setting"
    let validatorsOnSubmit = mode === "EDIT" ? EmailAlertSettingUpdateDto : EmailAlertSettingCreateDto

    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => mode === "EDIT" ? client.api["email-alert-settings"]({ id: id! }).get() : null,
        enabled: mode === "EDIT" && !!id
    })

    if (mode === "EDIT") {
        if (itemQuery.isLoading) {
            return <div className="p-3">Loading...</div>
        }

        if (itemQuery.error) {
            throw itemQuery.error
        }

        if (!itemQuery.data?.data) {
            return (
                <div className="p-3">
                    <div className="mb-4">Email Alert Setting not found</div>
                    <Button color="primary" onPress={() => window.history.back()}>
                        Back
                    </Button>
                </div>
            )
        }

        const settingData = itemQuery.data.data as any;

        formProps = {
            mode: mode,
            defaultValues: {
                recipientEmail: settingData.recipientEmail
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/email-alert-settings/:id", {
                method: "PATCH",
                body: value as any,
                params: { id: id!.toString() },
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/email-alert-settings/${id}`)
        }

    } else {

        formProps = {
            mode: mode,
            defaultValues: {
                recipientEmail: ''
            },
            validators: {
                onSubmit: validatorsOnSubmit
            },
            apiSubmit: (value: any) => fetcher("/api/email-alert-settings", {
                method: "POST",
                body: value as any,
                headers: {}
            }),
            entityName: entityName,
            queryKey: queryKey,
            redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/email-alert-settings/${id}`, { replace: true })
        }
    }

    const backRoute = '/backoffice/labmonitor/email-alert-settings';
    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{mode === "CREATE" ? "Add Email Recipient" : `Edit Email Recipient : ${id}`} </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/labmonitor/email-alert-settings">Email Alerts</BreadcrumbItem>
                                {
                                    mode === "CREATE"
                                        ? <BreadcrumbItem>Add Recipient</BreadcrumbItem>
                                        : <BreadcrumbItem href={`/backoffice/labmonitor/email-alert-settings/${id}`}>Edit : {id}</BreadcrumbItem>
                                }
                            </Breadcrumbs>

                        </div>

                        <div className="flex flex-row gap-3">
                            {(
                                <Dropdown>
                                    <DropdownTrigger>
                                        <Button isIconOnly>
                                            <span className="text-lg font-bold">...</span>
                                        </Button>
                                    </DropdownTrigger>
                                    <DropdownMenu aria-label="Email Alert Setting Actions">
                                        {mode == "EDIT" ? DeleteDropdownItem({
                                            entityName: entityName,
                                            id: id!.toString(),
                                            backRoute: backRoute,
                                            deleteFn: () => fetcher("/api/email-alert-settings/:id", {
                                                method: "DELETE",
                                                params: { id: id!.toString() },
                                                headers: {},
                                                body: {}
                                            })
                                        }) : null}

                                        <DropdownItem
                                            key="cancel"
                                            onPress={() => navigate(backRoute)}
                                        >
                                            Cancel
                                        </DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            )}

                            <Button color="primary" onPress={() => {
                                form.handleSubmit()
                            }}>
                                Save
                            </Button>
                        </div>

                    </div>
                    <EmailAlertSettingForm form={form} mode={mode} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )

}
