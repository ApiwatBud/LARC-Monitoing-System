import { BreadcrumbItem, Breadcrumbs, Button } from '@heroui/react'
import { client } from '../../../../../src/client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../src/common/types'
import { EmailAlertSetting } from "../../../../../modules/labmonitor/domains/entities/email_alert_setting.entity"
import { FilterFormDefs } from '../../../../../src/public/components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../../src/public/components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import { useNavigate } from 'react-router'

const colDefs: EntityColumn<EmailAlertSetting>[] = [
    {
        key: "id",
        header: "ID",
        cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
    },
    {
        key: "recipientEmail",
        header: "Recipient Email",
        meta: { isTitle: true },
        cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
    },
    {
        key: "createdAt",
        header: "Created At",
        cell: (info) => <span className="text-gray-500">{new Date(info.getValue()).toLocaleString()}</span>,
    }
]

const defaultFilter: TPaginateQueryForm<EmailAlertSetting> = {
    page: 1,
    limit: 20,
    withAudit: true,
    filter: {
        recipientEmail: {
            key: 'recipientEmail' as keyof EmailAlertSetting,
            operator: 'ilike' as TFilterOperator,
            value: ''
        }
    },
    sort: [{ key: 'createdAt', order: 'desc' as TSortOrder }]
}

const filterForm: FilterFormDefs[] = [
    {
        widget: 'text',
        label: 'Email',
        name: 'recipientEmail'
    }
]



export default function EmailAlertSettingIndex() {
    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Email Alert Settings</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor/email-alert-settings">Email Alerts</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <div className='flex flex-row gap-1'>
                    <Button color="primary" onPress={() => navigate('/backoffice/labmonitor/email-alert-settings/create')}>
                        Add Recipient
                    </Button>
                </div>
            </div>
            <GenericDataTable<EmailAlertSetting>
                queryKey={['email-alert-settings']}
                queryFn={client.api['email-alert-settings'].filter.post}
                viewRoute="/backoffice/labmonitor/email-alert-settings/:id"
                colDefs={colDefs}
                defaultFilter={defaultFilter}
                filterFormDefs={filterForm}
            />
        </PageContainer>
    )
}
