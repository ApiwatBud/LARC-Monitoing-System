import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Dropdown, DropdownItem, DropdownMenu, DropdownTrigger } from '@heroui/react'
import { useQuery } from '@tanstack/react-query'
import { useNavigate, useParams } from 'react-router'
import { client, fetcher } from "../../../../../src/client"
import { DeviceSensorDataCreateDTO, DeviceSensorDataUpdateDTO } from "../../../../../modules/labmonitor/applications/dtos/device_sensor_data.dto"
import { DEVICE_SENSOR_TYPE } from '../../../../../modules/labmonitor/domains/valueObject'
import { ZZBYFieldAutocomplete, ZZBYFieldSelect, ZZBYFormFieldInput, ZZBYFormFieldTextarea, ZZBYFormWrapper, ZZBYFormGeneratorWrapperProps, ZZBYFieldAsyncSelect, ZZBYFormFieldDatePicker } from '../../../../../src/public/components/ZZBYForm'
import { DeleteDropdownItem } from '../../../../../src/public/components/Datatables/deleteDropdownItem'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import { ReactNode } from "react";

export function DeviceSensorDataForm({ form, isEdit }: { form: any, isEdit: boolean }) {
    const sensorTypeOptions = Object.values(DEVICE_SENSOR_TYPE).map(v => ({ label: v.toUpperCase(), value: v }));

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
                <CardHeader className="font-bold">Identification</CardHeader>
                <CardBody className="flex flex-col gap-3">
                    <ZZBYFieldAsyncSelect
                        name="device_name"
                        form={form}
                        label="Device Name"
                        placeholder="Select Device"
                        queryFn={() => client.api.devices.filter.post({ page: 1, limit: 1000, filter: [], sort: [{ key: 'name', order: 'asc' }], withAudit: false })}
                        mapFn={(item: any) => ({ label: item.name, value: item.name })}
                        afterSelectFn={() => form.setFieldValue("sensor_id", "")}
                    />

                    <form.Subscribe
                        selector={(state: any) => ({
                            device_name: state.values.device_name,
                        })}
                        children={(value: any) => {

                            return (
                                <ZZBYFieldAsyncSelect
                                    name="sensor_id"
                                    form={form}
                                    label="Sensor ID"
                                    placeholder="Select Sensor"
                                    queryFn={(params: any) => client.api.devices.byName({ name: params }).deviceSensors.get()}
                                    mapFn={(item: any) => ({ label: item.sensor_id, value: item.sensor_id, meta: item })}
                                    afterSelectFn={(item: any) => {
                                        console.log('after select', item)
                                        if (!item) return
                                        form.setFieldValue("sensor_id", item.sensor_id)
                                        form.setFieldValue("sensor_type", item.sensor_type)
                                    }}
                                    queryFnParams={value.device_name}
                                />

                            )
                        }}
                    />
                </CardBody>
            </Card>

            <Card>
                <CardHeader className="font-bold">Sensor Properties</CardHeader>
                <CardBody className="flex flex-col gap-3">
                    <ZZBYFieldSelect
                        name="sensor_type"
                        form={form}
                        label="Sensor Type"
                        options={sensorTypeOptions}
                    />

                    <ZZBYFormFieldDatePicker
                        name="sensor_timestamp"
                        form={form}
                        label="Timestamp"
                    />
                </CardBody>
            </Card>

            <Card className="md:col-span-2">
                <CardHeader className="font-bold">Processed Values</CardHeader>
                <CardBody className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="md:col-span-2">
                        <ZZBYFormFieldTextarea
                            form={form}
                            name="raw_value"
                            label="Raw Value (Text)"
                            placeholder="Enter raw sensor data here..."
                        />
                    </div>
                    <ZZBYFormFieldInput
                        name="process_value_number"
                        form={form}
                        label="Processed Number"
                        type="number"
                        isReadOnly
                    />
                    <ZZBYFormFieldInput
                        name="process_value_text"
                        form={form}
                        label="Processed Text"
                        isReadOnly
                    />

                </CardBody>
            </Card>
        </div>
    )
}

export default function DeviceSensorDataEdit() {
    const { id } = useParams()
    const navigate = useNavigate()
    const isEdit = id !== undefined && id !== 'create'
    const entityName = "Processed Sensor Data"
    const queryKey = ['device-sensor-data', id]
    const backRoute = '/backoffice/labmonitor/sensor-data'

    const itemQuery = useQuery({
        queryKey: queryKey,
        queryFn: () => isEdit ? client.api["device-sensor-data"]({ id: Number(id) }).get() : null,
        enabled: isEdit
    })

    if (isEdit && itemQuery.isLoading) return <div className="p-3">Loading...</div>
    let defaultValues = DeviceSensorDataUpdateDTO.parse({
        ...itemQuery.data?.data,
        sensor_timestamp: itemQuery.data?.data?.sensor_timestamp ? itemQuery.data.data.sensor_timestamp.toISOString() : undefined
    })
    const formProps: ZZBYFormGeneratorWrapperProps<any> = isEdit ? {
        mode: "EDIT",
        defaultValues: {
            ...defaultValues,
        } as any,
        validators: {
            onSubmit: DeviceSensorDataUpdateDTO
        },
        apiSubmit: (value: any) => fetcher("/api/device-sensor-data/:id", {
            method: "PUT",
            body: value,
            params: { id: id! },
            headers: {}
        }),
        entityName,
        queryKey: ['device-sensor-data'],
        redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/sensor-data`)
    } : {
        mode: "CREATE",
        defaultValues: {
            device_name: '',
            sensor_id: '',
            sensor_type: DEVICE_SENSOR_TYPE.TEMP,
            sensor_timestamp: new Date().toISOString(),
            raw_value: '',
        },
        validators: {
            onSubmit: DeviceSensorDataCreateDTO
        },
        apiSubmit: (value: any) => fetcher("/api/device-sensor-data", {
            method: "POST",
            body: value,
            headers: {}
        }),
        entityName,
        queryKey: ['device-sensor-data'],
        redirectEdit: (id: string) => navigate(`/backoffice/labmonitor/sensor-data`, { replace: true })
    }

    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">
                                {isEdit ? `View/Edit Processed Data: #${id}` : 'Create Processed Data'}
                            </h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem href="/backoffice/labmonitor/sensor-data">Sensor Data</BreadcrumbItem>
                                <BreadcrumbItem>{isEdit ? `Edit : ${id}` : 'Create'}</BreadcrumbItem>
                            </Breadcrumbs>
                        </div>

                        <div className="flex gap-3">
                            <Dropdown>
                                <DropdownTrigger>
                                    <Button isIconOnly>
                                        <span className="text-lg font-bold">...</span>
                                    </Button>
                                </DropdownTrigger>
                                <DropdownMenu aria-label="Actions">
                                    {isEdit ? DeleteDropdownItem({
                                        entityName,
                                        id: id!,
                                        backRoute,
                                        deleteFn: () => fetcher("/api/device-sensor-data/:id", {
                                            method: "DELETE",
                                            params: { id: id! },
                                            headers: {},
                                            body: {}
                                        })
                                    }) : null}
                                    <DropdownItem key="cancel" onPress={() => navigate(backRoute)}>
                                        Cancel
                                    </DropdownItem>
                                </DropdownMenu>
                            </Dropdown>

                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save
                            </Button>
                        </div>
                    </div>

                    <DeviceSensorDataForm form={form} isEdit={isEdit} />
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )
}
