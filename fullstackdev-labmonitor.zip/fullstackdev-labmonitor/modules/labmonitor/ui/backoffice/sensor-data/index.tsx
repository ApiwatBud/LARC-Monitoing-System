import { BreadcrumbItem, Breadcrumbs, Button, Chip } from '@heroui/react'
import { client } from '../../../../../src/client'
import { TFilterOperator, TPaginateQueryForm, TSortOrder } from '../../../../../src/common/types'
import { DeviceSensorDataEntity } from "../../../../../modules/labmonitor/domains/entities/device_sensor_data.entity"
import { FilterFormDefs } from '../../../../../src/public/components/Datatables/filterForm'
import { EntityColumn, GenericDataTable } from '../../../../../src/public/components/Datatables/zzbyDatatable'
import { PageContainer } from '../../../../../src/public/components/PageContainer'
import { DEVICE_SENSOR_TYPE, DeviceSensorTypeMap } from '../../../../../modules/labmonitor/domains/valueObject'
import { useNavigate } from 'react-router'
import { transformFilterFormToQuery } from '../../../../../src/public/utils/filterUtils'
import { downloadExcelResponse } from '../../../../../src/public/utils/exportUtils'

const colDefs: EntityColumn<DeviceSensorDataEntity>[] = [
    {
        key: "id",
        header: "ID",
        cell: (info) => <span className="font-mono text-blue-600 font-medium">#{info.getValue()}</span>,
    },
    {
        key: "device_name",
        header: "Device Name",
        meta: { isTitle: true },
        cell: (info) => <span className="font-medium text-gray-900">{info.getValue()}</span>,
    },
    {
        key: "sensor_id",
        header: "Sensor ID",
        cell: (info) => <span className="font-mono text-gray-600">{info.getValue()}</span>,
    },
    {
        key: "sensor_type",
        header: "Type",
        cell: (info) => <Chip size="sm" variant="flat">{info.getValue()}</Chip>,
    },
    {
        key: "dangerStatus",
        header: "Status",
        cell: (info) => {
            const status = info.getValue();
            const colorMap = {
                'normal': 'success',
                'warning': 'warning',
                'danger': 'danger'
            } as const;
            return <Chip size="sm" color={colorMap[status as keyof typeof colorMap] || 'default'} variant="flat" className="capitalize">{status}</Chip>;
        },
    },

    {
        key: "process_value_number",
        header: "Value (Num)",
        cell: (info) => <span className="font-mono">{info.getValue() ?? '-'}</span>,
    },
    {
        key: "process_value_text",
        header: "Value (Text)",
        cell: (info) => <span className="text-gray-600 italic">{info.getValue() ?? '-'}</span>,
    },
    {
        key: "sensor_timestamp",
        header: "Timestamp",
        cell: (info) => <span className="text-gray-500">{new Date(info.getValue()).toLocaleString()}</span>,
    },
]

const defaultFilter: TPaginateQueryForm<DeviceSensorDataEntity> = {
    page: 1,
    limit: 20,
    withAudit: true,
    filter: {
        device_name: {
            key: 'device_name' as keyof DeviceSensorDataEntity,
            operator: 'ilike' as TFilterOperator,
            value: ''
        },
        sensor_type: {
            key: 'sensor_type' as keyof DeviceSensorDataEntity,
            operator: '=' as TFilterOperator,
            value: ''
        },
        process_value_number: {
            key: "process_value_number" as keyof DeviceSensorDataEntity,
            operator: '=' as TFilterOperator,
            value: null
        }
    },
    sort: [{ key: 'sensor_timestamp', order: 'desc' as TSortOrder }]
}

const filterForm: FilterFormDefs[] = [
    {
        widget: 'text',
        label: 'Device Name',
        name: 'device_name'
    },
    {
        widget: 'select',
        label: 'Sensor Type',
        name: 'sensor_type',
        options: Object.values(DEVICE_SENSOR_TYPE).map((value) => ({
            label: DeviceSensorTypeMap[value as DEVICE_SENSOR_TYPE] || value,
            value: value
        }))
    },
    {
        widget: 'numberCompound',
        label: 'Value (Number)',
        name: 'process_value_number',
    }
]

export default function DeviceSensorDataIndex() {

    const navigate = useNavigate()
    return (
        <PageContainer>
            <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Processed Sensor Data</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor/sensor-data">Sensor Data</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
                <div className='flex flex-row gap-1'>
                    <Button color="primary" onPress={() => navigate('/backoffice/labmonitor/sensor-data/create')}>
                        Add Manual Data
                    </Button>
                </div>
            </div>
            <GenericDataTable<DeviceSensorDataEntity>
                queryKey={['device-sensor-data']}
                queryFn={client.api["device-sensor-data"].filter.post}
                viewRoute="/backoffice/labmonitor/sensor-data/:id"
                colDefs={colDefs}
                defaultFilter={defaultFilter}
                filterFormDefs={filterForm}
                exportFn={async (filter) => {
                    const query = transformFilterFormToQuery(filter)
                    const response = await client.api['device-sensor-data'].export.post({
                        ...query,
                        limit: -1, // Export all
                    })
                    await downloadExcelResponse(response, 'device-sensor-data.xlsx')
                }}
            />
        </PageContainer>
    )
}
