import { Route } from "react-router";
import DeviceIndex from "./devices/index";
import DeviceEdit from "./devices/edit";
import DeviceSensorDataRawIndex from "./sensor-data-raw/index";
import DeviceSensorDataRawEdit from "./sensor-data-raw/edit";
import DeviceSensorDataIndex from "./sensor-data/index";
import DeviceSensorDataEdit from "./sensor-data/edit";
import LabMonitorDashboard from "./dashboard";
import EmailAlertSettingIndex from "./email-alert-settings";
import EmailAlertSettingEdit from "./email-alert-settings/edit";
import EmailAlertLogIndex from "./email-alert-logs";
import EmailAlertConfigPage from "./email-alert-config";
import DeviceOverview from "./overview";

export default function LabMonitorRoutes() {
    return (
        <Route path="labmonitor">
            <Route index element={<LabMonitorDashboard />} />
            <Route path="overview" element={<DeviceOverview />} />
            <Route path="devices">
                <Route index element={<DeviceIndex />} />
                <Route path="create" element={<DeviceEdit />} />
                <Route path=":id" element={<DeviceEdit />} />
            </Route>
            <Route path="sensor-data-raw">
                <Route index element={<DeviceSensorDataRawIndex />} />
                <Route path="create" element={<DeviceSensorDataRawEdit />} />
                <Route path=":id" element={<DeviceSensorDataRawEdit />} />
            </Route>
            <Route path="sensor-data">
                <Route index element={<DeviceSensorDataIndex />} />
                <Route path="create" element={<DeviceSensorDataEdit />} />
                <Route path=":id" element={<DeviceSensorDataEdit />} />
            </Route>
            <Route path="email-alert-settings">
                <Route index element={<EmailAlertSettingIndex />} />
                <Route path="create" element={<EmailAlertSettingEdit />} />
                <Route path=":id" element={<EmailAlertSettingEdit />} />
            </Route>
            <Route path="email-alert-logs">
                <Route index element={<EmailAlertLogIndex />} />
            </Route>
            <Route path="email-alert-config" element={<EmailAlertConfigPage />} />
        </Route>
    )
}
