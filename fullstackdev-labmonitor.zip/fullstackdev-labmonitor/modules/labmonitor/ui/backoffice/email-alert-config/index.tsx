import { BreadcrumbItem, Breadcrumbs, Button, Card, CardBody, CardHeader, Checkbox } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { client, fetcher } from "../../../../../src/client";
import { EmailAlertConfigDto } from "../../../applications/dtos/email_alert_config.dto";
import { ZZBYFieldSelect, ZZBYFormFieldInput, ZZBYFormGeneratorWrapperProps, ZZBYFormWrapper } from "../../../../../src/public/components/ZZBYForm";
import { PageContainer } from "../../../../../src/public/components/PageContainer";

const UNIT_LABELS: Record<string, string> = {
    minutes: "Minutes",
    hours: "Hours",
    days: "Days",
};

const DEFAULT_STAGES = [
    { value: 30, unit: "minutes" },
    { value: 4, unit: "hours" },
    { value: 1, unit: "days" },
];

export default function EmailAlertConfigPage() {
    const queryKey = ['email-alert-config']
    const entityName = "Email Alert Configuration"

    const configQuery = useQuery({
        queryKey: queryKey,
        queryFn: async () => {
            const res = await client.api['email-alert-config'].get();
            return res.data;
        },
    })

    if (configQuery.isLoading) {
        return <div className="p-3">Loading...</div>
    }

    const data = configQuery.data;
    const defaultValues = {
        enable: data?.enable ?? true,
        minLevel: data?.minLevel ?? "warning",
        fromName: data?.fromName ?? "Lab Monitor System",
        sendOnFirstWarning: data?.sendOnFirstWarning ?? true,
        rateLimitStages: data?.rateLimitStages?.length ? data.rateLimitStages : DEFAULT_STAGES,
        resetOnSensorChange: data?.resetOnSensorChange ?? true,
        clearOnNormal: data?.clearOnNormal ?? true,
    };

    const formProps: ZZBYFormGeneratorWrapperProps<any> = {
        mode: "EDIT",
        defaultValues: defaultValues,
        validators: {
            onSubmit: EmailAlertConfigDto
        },
        apiSubmit: (value: any) => fetcher("/api/email-alert-config", {
            method: "POST",
            body: value,
            headers: {}
        }),
        entityName: entityName,
        queryKey: queryKey,
    }

    return (
        <ZZBYFormWrapper formProps={formProps}>
            {(form: any) => (
                <PageContainer>
                    <div className="mb-3 flex justify-between items-end sticky top-0 z-20 bg-white/80 backdrop-blur-md py-3 -mt-3">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Email Alert Configuration</h1>
                            <Breadcrumbs size="sm" className="mt-1.5">
                                <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                                <BreadcrumbItem>Lab Monitor</BreadcrumbItem>
                                <BreadcrumbItem>Email Alert Configuration</BreadcrumbItem>
                            </Breadcrumbs>
                        </div>

                        <div className="flex flex-row gap-3">
                            <Button color="primary" onPress={() => form.handleSubmit()}>
                                Save Settings
                            </Button>
                        </div>
                    </div>

                    <div className='grid grid-cols-1 gap-4 max-w-2xl'>
                        <Card shadow="sm">
                            <CardHeader className="font-bold px-4 pt-4 text-gray-800">
                                Email Alert Settings
                            </CardHeader>
                            <CardBody className="flex flex-col gap-4 p-4">
                                <form.Field
                                    name="enable"
                                    children={(field: any) => (
                                        <Checkbox
                                            isSelected={field.state.value}
                                            onValueChange={field.handleChange}
                                        >
                                            Enable email alerts
                                        </Checkbox>
                                    )}
                                />

                                <ZZBYFieldSelect
                                    form={form}
                                    name="minLevel"
                                    label="Minimum Alert Level"
                                    placeholder="Select minimum alert level"
                                    options={[
                                        { label: "Warning", value: "warning" },
                                        { label: "Danger", value: "danger" }
                                    ]}
                                />

                                <ZZBYFormFieldInput
                                    form={form}
                                    name="fromName"
                                    label="Sender Name"
                                    placeholder="Lab Monitor System"
                                />
                            </CardBody>
                        </Card>

                        <Card shadow="sm">
                            <CardHeader className="font-bold px-4 pt-4 text-gray-800">
                                Rate Limit Rules
                            </CardHeader>
                            <CardBody className="flex flex-col gap-4 p-4">
                                <form.Field
                                    name="sendOnFirstWarning"
                                    children={(field: any) => (
                                        <Checkbox
                                            isSelected={field.state.value}
                                            onValueChange={field.handleChange}
                                        >
                                            Send immediately on first warning
                                        </Checkbox>
                                    )}
                                />

                                <div className="flex flex-col gap-2 border rounded-xl p-3 bg-gray-50/50">
                                    <span className="text-sm font-medium text-gray-700">
                                        Re-send interval (escalates while warning persists)
                                    </span>
                                    <form.Field
                                        name="rateLimitStages"
                                        children={(field: any) => {
                                            const stages = field.state.value || [];
                                            return (
                                                <div className="flex flex-col gap-2">
                                                    {stages.map((stage: any, idx: number) => (
                                                        <div key={idx} className="flex items-end gap-2">
                                                            <div className="flex items-center gap-2">
                                                                <span className="text-xs text-gray-500 w-14">Stage {idx + 1}</span>
                                                                <input
                                                                    type="number"
                                                                    min={1}
                                                                    className="border rounded-lg px-3 py-2 w-24 text-sm"
                                                                    value={stage.value}
                                                                    onChange={(e) => {
                                                                        const next = [...stages];
                                                                        next[idx] = { ...stage, value: Number(e.target.value) };
                                                                        field.handleChange(next);
                                                                    }}
                                                                />
                                                                <select
                                                                    className="border rounded-lg px-2 py-2 text-sm"
                                                                    value={stage.unit}
                                                                    onChange={(e) => {
                                                                        const next = [...stages];
                                                                        next[idx] = { ...stage, unit: e.target.value };
                                                                        field.handleChange(next);
                                                                    }}
                                                                >
                                                                    {Object.keys(UNIT_LABELS).map(u => (
                                                                        <option key={u} value={u}>{UNIT_LABELS[u]}</option>
                                                                    ))}
                                                                </select>
                                                            </div>
                                                            {stages.length > 1 && (
                                                                <Button
                                                                    size="sm"
                                                                    color="danger"
                                                                    variant="light"
                                                                    onPress={() => {
                                                                        field.handleChange(stages.filter((_: any, i: number) => i !== idx));
                                                                    }}
                                                                >
                                                                    Remove
                                                                </Button>
                                                            )}
                                                        </div>
                                                    ))}
                                                    <div className="flex gap-2 mt-1">
                                                        <Button
                                                            size="sm"
                                                            variant="flat"
                                                            color="primary"
                                                            onPress={() => {
                                                                field.handleChange([...stages, { value: 4, unit: "hours" }]);
                                                            }}
                                                        >
                                                            + Add Stage
                                                        </Button>
                                                        <Button
                                                            size="sm"
                                                            variant="flat"
                                                            onPress={() => {
                                                                field.handleChange(DEFAULT_STAGES.map(s => ({ ...s })));
                                                            }}
                                                        >
                                                            Example: 30min/4hr/1day
                                                        </Button>
                                                    </div>
                                                    <p className="text-xs text-gray-500">
                                                        Example: send immediately on first warning → Stage 1 re-sends every 30 minutes → Stage 2 every 4 hours → Stage 3+ every 1 day (while warning persists)
                                                    </p>
                                                </div>
                                            );
                                        }}
                                    />
                                </div>

                                <form.Field
                                    name="resetOnSensorChange"
                                    children={(field: any) => (
                                        <Checkbox
                                            isSelected={field.state.value}
                                            onValueChange={field.handleChange}
                                        >
                                            Send immediately when warning sensors change (reset rate limit)
                                        </Checkbox>
                                    )}
                                />

                                <form.Field
                                    name="clearOnNormal"
                                    children={(field: any) => (
                                        <Checkbox
                                            isSelected={field.state.value}
                                            onValueChange={field.handleChange}
                                        >
                                            Clear rate limit when device returns to NORMAL
                                        </Checkbox>
                                    )}
                                />
                            </CardBody>
                        </Card>
                    </div>
                </PageContainer>
            )}
        </ZZBYFormWrapper>
    )
}