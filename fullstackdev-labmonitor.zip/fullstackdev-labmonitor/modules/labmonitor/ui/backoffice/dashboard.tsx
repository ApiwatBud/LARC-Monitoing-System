import { BreadcrumbItem, Breadcrumbs, Card, CardBody, Chip, Spinner, Table, TableBody, TableCell, TableColumn, TableHeader, TableRow } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { client } from "../../../../src/client";
import { FiActivity, FiBox, FiCheckCircle, FiAlertTriangle, FiRefreshCw } from "react-icons/fi";
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DeviceSensorTypeMap } from "../../../../modules/labmonitor/domains/valueObject/index";
import { formatDistanceToNow } from "date-fns";
import { DeviceEntity } from "../../../../modules/labmonitor/domains/entities/device.entity";
import { DeviceSensorDataEntity } from "../../../../modules/labmonitor/domains/entities/device_sensor_data.entity";
import { PageContainer } from "../../../../src/public/components/PageContainer";

export default function LabMonitorDashboard() {
    // 1. Fetch Devices for Overview
    const devicesQuery = useQuery({
        queryKey: ['labmonitor-dashboard-devices'],
        queryFn: () => client.api.devices.filter.post({
            page: 1, limit: 1000, withAudit: false, filter: [], sort: []
        })
    });

    // 2. Fetch Latest Sensor Data
    const sensorDataQuery = useQuery({
        queryKey: ['labmonitor-dashboard-latest-data'],
        queryFn: () => client.api["device-sensor-data"].filter.post({
            page: 1,
            limit: 10,
            sort: [{ key: 'sensor_timestamp', order: 'desc' }],
            filter: [],
            withAudit: false

        })
    });

    const devices = (devicesQuery.data?.data?.data || []) as DeviceEntity[];
    const latestData = (sensorDataQuery.data?.data?.data || []) as DeviceSensorDataEntity[];

    const stats = {
        total: devices.length,
        online: devices.filter((d: DeviceEntity) => d.connection_status === DEVICE_CONNECTION_STATUS.ONLINE).length,
        offline: devices.filter((d: DeviceEntity) => d.connection_status === DEVICE_CONNECTION_STATUS.OFFLINE).length,
        danger: devices.filter((d: DeviceEntity) => d.danger_status === DEVICE_DANGER_STATUS.DANGER).length,
        warning: devices.filter((d: DeviceEntity) => d.danger_status === DEVICE_DANGER_STATUS.WARNING).length,
    }

    const isLoading = devicesQuery.isLoading || sensorDataQuery.isLoading;

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-[400px]">
                <Spinner size="lg" label="Loading Dashboard..." />
            </div>
        )
    }

    return (
        <PageContainer className="space-y-3">
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Lab Monitor Dashboard</h1>
                    <Breadcrumbs size="sm" className="mt-1.5">
                        <BreadcrumbItem href="/backoffice/dashboard">Dashboard</BreadcrumbItem>
                        <BreadcrumbItem href="/backoffice/labmonitor/dashboard">Lab Monitor</BreadcrumbItem>
                        <BreadcrumbItem>Overview</BreadcrumbItem>
                    </Breadcrumbs>
                </div>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="border-none shadow-sm bg-blue-50">
                    <CardBody className="flex flex-row items-center gap-4 p-4">
                        <div className="p-3 rounded-xl bg-blue-500 text-white">
                            <FiBox size={24} />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-blue-600">Total Devices</p>
                            <h3 className="text-2xl font-bold text-blue-900">{stats.total}</h3>
                        </div>
                    </CardBody>
                </Card>

                <Card className="border-none shadow-sm bg-green-50">
                    <CardBody className="flex flex-row items-center gap-4 p-4">
                        <div className="p-3 rounded-xl bg-green-500 text-white">
                            <FiCheckCircle size={24} />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-green-600">Online</p>
                            <h3 className="text-2xl font-bold text-green-900">{stats.online}</h3>
                        </div>
                    </CardBody>
                </Card>

                <Card className="border-none shadow-sm bg-amber-50">
                    <CardBody className="flex flex-row items-center gap-4 p-4">
                        <div className="p-3 rounded-xl bg-amber-500 text-white">
                            <FiAlertTriangle size={24} />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-amber-600">Warnings</p>
                            <h3 className="text-2xl font-bold text-amber-900">{stats.warning}</h3>
                        </div>
                    </CardBody>
                </Card>

                <Card className="border-none shadow-sm bg-rose-50">
                    <CardBody className="flex flex-row items-center gap-4 p-4">
                        <div className="p-3 rounded-xl bg-rose-500 text-white">
                            <FiActivity size={24} />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-rose-600">Danger Alerts</p>
                            <h3 className="text-2xl font-bold text-rose-900">{stats.danger}</h3>
                        </div>
                    </CardBody>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Latest Activity Table */}
                <Card className="lg:col-span-2 shadow-sm border border-gray-100">
                    <CardBody className="p-0">
                        <div className="p-4 border-b border-gray-100 flex justify-between items-center">
                            <h3 className="font-bold text-gray-800 flex items-center gap-2">
                                <FiRefreshCw className="text-blue-500" /> Latest Readings
                            </h3>
                            <Chip size="sm" variant="flat" color="primary">Real-time</Chip>
                        </div>
                        <Table aria-label="Latest sensor readings" shadow="none" radius="none">
                            <TableHeader>
                                <TableColumn>DEVICE</TableColumn>
                                <TableColumn>SENSOR</TableColumn>
                                <TableColumn>VALUE</TableColumn>
                                <TableColumn>TIME</TableColumn>
                            </TableHeader>
                            <TableBody emptyContent="No recent data found.">
                                {latestData.map((data: any) => (
                                    <TableRow key={data.id}>
                                        <TableCell className="font-medium text-gray-700">{data.device_name}</TableCell>
                                        <TableCell>
                                            <Chip size="sm" variant="dot" color="primary">
                                                {DeviceSensorTypeMap[data.sensor_type as keyof typeof DeviceSensorTypeMap] || data.sensor_type}
                                            </Chip>
                                        </TableCell>
                                        <TableCell className="font-mono font-bold text-blue-600">
                                            {data.process_value_number ?? data.process_value_text ?? '-'}
                                        </TableCell>
                                        <TableCell className="text-gray-500 text-xs text-nowrap">
                                            {formatDistanceToNow(new Date(data.sensor_timestamp), { addSuffix: true })}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardBody>
                </Card>

                {/* Device Status List */}
                <Card className="shadow-sm border border-gray-100">
                    <CardBody className="p-0">
                        <div className="p-4 border-b border-gray-100 italic">
                            <h3 className="font-bold text-gray-800">Critical Devices</h3>
                        </div>
                        <div className="p-4 space-y-4">
                            {devices.filter((d: DeviceEntity) => d.danger_status !== DEVICE_DANGER_STATUS.NORMAL).length === 0 ? (
                                <p className="text-center text-gray-400 py-10">All systems clear ✨</p>
                            ) : (
                                devices
                                    .filter((d: DeviceEntity) => d.danger_status !== DEVICE_DANGER_STATUS.NORMAL)
                                    .slice(0, 5)
                                    .map((device: DeviceEntity) => (
                                        <div key={device.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-100">
                                            <div>
                                                <p className="font-bold text-gray-900">{device.name}</p>
                                            </div>
                                            <Chip
                                                size="sm"
                                                color={device.danger_status === DEVICE_DANGER_STATUS.DANGER ? 'danger' : 'warning'}
                                                variant="shadow"
                                            >
                                                {device.danger_status.toUpperCase()}
                                            </Chip>
                                        </div>
                                    ))
                            )}
                        </div>
                    </CardBody>
                </Card>
            </div>
        </PageContainer>
    );
}
