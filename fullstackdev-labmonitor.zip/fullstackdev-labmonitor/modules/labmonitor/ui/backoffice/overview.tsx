import { Card, CardBody, CardFooter, CardHeader, Chip, CircularProgress, DatePicker, Tab, Tabs, type CardProps, type DateValue } from "@heroui/react";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { today, getLocalTimeZone, CalendarDate, Calendar } from "@internationalized/date";
import dayjs from "dayjs";
import ReactECharts from 'echarts-for-react';
import { DeviceAggsResponseDTO, DeviceDtoWithLatestSensorData } from "../../applications/dtos/device.dto.aggs";
import { isNullOrUndefined } from "../../../../src/common/utils/utils";
import { client } from "../../../../src/client";
import { DeviceSensorResponseDTO } from "../../applications/dtos/device_sensor.dto";
import { DEVICE_CONNECTION_STATUS, DEVICE_SENSOR_TYPE, DeviceSensorTypeMap } from "../../domains/valueObject";
import { DeviceSensorDataResponseDTO } from "../../applications/dtos/device_sensor_data.dto";
import { scale } from "framer-motion";


export default function DeviceOverview() {
    return (
        <div className="flex flex-col gap-4">

            <div className="flex flex-row">
                <h1 className="text-2xl font-bold">Overview</h1>
            </div>
            <div className="">
                <DevicesDashboard />
            </div>

            <div>
                <DeviceChartSection />
            </div>
        </div>
    );
}

function DeviceLastestDataCard({ device, ...props }: { device: DeviceDtoWithLatestSensorData, className: string } & CardProps) {

    const mapSensorWithData = new Map<any, any>()

    device.device_sensors?.sort((a, b) => a.sensor_id.localeCompare(b.sensor_id))

    for (const sensor of device.device_sensors || []) {
        mapSensorWithData.set(sensor, device.latest_sensor_data?.find(
            (data) => data.sensor_id === sensor.sensor_id
        ))
    }



    return (<>
        <Card {...props}>
            <CardHeader>
                <div className="w-full">
                    <div className="flex flex-row w-full  items-center justify-between">
                        <h2 className="text-lg font-semibold">Device : {device.name}</h2>
                        <div>
                            {
                                device.connection_status === DEVICE_CONNECTION_STATUS.ONLINE ? (
                                    <Chip color="success">Online</Chip>
                                ) : (
                                    <Chip color="danger">Offline</Chip>
                                )
                            }
                        </div>
                    </div>
                    <p className="text-sm">Last Seen : {device.last_seen ? dayjs(device.last_seen).format("YYYY-MM-DD HH:mm:ss") : '-'}</p>
                </div>
            </CardHeader>
            <CardBody>
                <div className="">
                    {
                        device.device_sensors?.map((sensor) => (
                            <div key={sensor.id} className="flex flex-row justify-between">
                                <p>{DeviceSensorTypeMap[sensor.sensor_type]} : </p>
                                <p>{
                                    isNullOrUndefined(mapSensorWithData.get(sensor)?.process_value_number)
                                        ? mapSensorWithData.get(sensor)?.process_value_text
                                        : mapSensorWithData.get(sensor)?.process_value_number.toFixed(2)
                                }</p>
                            </div>
                        ))
                    }

                </div>

            </CardBody>
        </Card>
    </>)
}

function DevicesDashboard() {

    const [devicesData, setDevicesData] = useState<DeviceDtoWithLatestSensorData[]>([])

    const query = useQuery({
        queryKey: ["devices_data"],
        queryFn: async () => {
            const response = await client.api.devices.latestData.get()

            const data = response.data as DeviceDtoWithLatestSensorData[]

            if (data && ('length' in data)) {
                data.sort((a, b) => a.name.localeCompare(b.name))
                setDevicesData(data)
            }

            return data
        },
        refetchInterval: 60 * 60 * 1000,
        refetchOnMount: true,
        refetchOnWindowFocus: true,
    });



    return (
        <>
            {devicesData && devicesData.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {devicesData.map((device) => (
                        <DeviceLastestDataCard className="w-full" key={device.id} device={device} />
                    ))}
                </div>
            ) : (
                <p>No devices found</p>
            )}

        </>
    )
}


function TimeSeriesNumberChart({ sensor, device, startDate, endDate }: { sensor: DeviceSensorResponseDTO, device: DeviceDtoWithLatestSensorData, startDate: CalendarDate, endDate: CalendarDate }) {
    let device_name = device.name
    let sensor_id = sensor.sensor_id
    let [option, setOption] = useState<any>({})

    const MapMaxMin = {
        [DEVICE_SENSOR_TYPE.AMMONIA]: { min: 0, max: 1 },
        [DEVICE_SENSOR_TYPE.AQI]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.AQL_PPM]: { min: 0, max: 1 },
        [DEVICE_SENSOR_TYPE.HUMID]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.LIGHT]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.RAW]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.SOUND]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.TEMP]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.V_BATT]: { min: 0, max: 100 },
        [DEVICE_SENSOR_TYPE.WATER_LEVEL]: { min: 0, max: 100 },
    } satisfies Record<DEVICE_SENSOR_TYPE, { min: number, max: number }>

    const generateOptions = (data: DeviceSensorDataResponseDTO[]) => {
        let xData = data.map((item) => dayjs(item.sensor_timestamp).toDate().getTime())
        let yData = data.map((item) => item.process_value_number)
        let yDataNotNull = yData.filter(x => x != null)
        let maxYData = Math.max(...yDataNotNull)
        let minYData = Math.min(...yDataNotNull)

        const option = {
            grid: {
                left: 0,   // ลดระยะห่างด้านซ้าย
                right: 10,  // ลดระยะห่างด้านขวา
                top: 20,    // ลดระยะห่างด้านบน
                bottom: 20, // ลดระยะห่างด้านล่าง
                containLabel: true, // ให้ label อยู่ในพื้นที่ grid
            },
            tooltip: { trigger: "axis" },
            xAxis: {
                type: 'time',
            },
            yAxis: {
                scale: false,
                min: Math.min(MapMaxMin[sensor.sensor_type].min, minYData),
                max: Math.max(maxYData, MapMaxMin[sensor.sensor_type].max)
            },
            series: [
                {
                    showSymbol: false,
                    type: 'line',
                    data: xData.map((item, index) => [item, yData[index]])
                }
            ]
        };

        return option
    }

    const query = useQuery({
        queryKey: ["device_sensor_data", device_name, sensor_id, startDate, endDate],
        queryFn: async () => {

            let startDateStr = dayjs(startDate.toDate(getLocalTimeZone())).startOf('day').toISOString()
            let endDateStr = dayjs(endDate.toDate(getLocalTimeZone())).add(1, 'day').startOf('day').toISOString()

            const response = await client.api["device-sensor-data"].loaddata.post({
                device_name,
                sensor_id,
                start_date: startDateStr,
                end_date: endDateStr,
            })
            if (response.data && ('length' in response.data)) {
                setOption(generateOptions(response.data))
                return response.data
            }
            return []
        },
        refetchInterval: 60 * 60 * 1000,
        refetchOnMount: true,
        refetchOnWindowFocus: true,
    });


    return <ReactECharts option={option} />

}

function TimeSeriesAQIChart({ sensor, device, startDate, endDate }: { sensor: DeviceSensorResponseDTO, device: DeviceDtoWithLatestSensorData, startDate: CalendarDate, endDate: CalendarDate }) {
    let device_name = device.name
    let sensor_id = sensor.sensor_id

    let [option, setOption] = useState<any>({})

    const generateOptions = (data: DeviceSensorDataResponseDTO[]) => {
        let xData = data.map((item) => dayjs(item.sensor_timestamp).toDate().getTime())
        let yData = data.map((item) => item.process_value_text)
        console.log(xData, yData)
        const option = {
            grid: {
                left: 0,   // ลดระยะห่างด้านซ้าย
                right: 10,  // ลดระยะห่างด้านขวา
                top: 20,    // ลดระยะห่างด้านบน
                bottom: 20, // ลดระยะห่างด้านล่าง
                containLabel: true, // ให้ label อยู่ในพื้นที่ grid
            },

            xAxis: {
                type: 'time',
            },
            yAxis: {
                type: "category", // ใช้ string เป็นแกน Y
                data: ["Good", "Moderate", "Unhealthy", "Very Unhealthy", "Hazardous"].reverse(),
            },
            series: [
                {
                    showSymbol: false,
                    type: 'line',
                    data: xData.map((item, index) => [item, yData[index]])
                }
            ]
        };

        return option
    }

    const query = useQuery({
        queryKey: ["device_sensor_data", device_name, sensor_id, startDate, endDate],
        queryFn: async () => {

            let startDateStr = dayjs(startDate.toDate(getLocalTimeZone())).startOf('day').toISOString()
            let endDateStr = dayjs(endDate.toDate(getLocalTimeZone())).add(1, 'day').startOf('day').toISOString()

            const response = await client.api["device-sensor-data"].loaddata.post({
                device_name,
                sensor_id,
                start_date: startDateStr,
                end_date: endDateStr,
            })
            if (response.data && ('length' in response.data)) {
                setOption(generateOptions(response.data))
                return response.data
            }
            return []
        },
        refetchInterval: 60 * 60 * 1000,
        refetchOnMount: true,
        refetchOnWindowFocus: true,
    });


    return <ReactECharts option={option} />

}



function DeviceSensorChart({ sensor, device }: { sensor: DeviceSensorResponseDTO, device: DeviceDtoWithLatestSensorData }) {



    // Today at 00:00
    const todayMidnight = today(getLocalTimeZone())
    // Tomorrow at 00:00
    const tomorrowMidnight = today(getLocalTimeZone()).add({ days: 1 });


    let [startDate, setStartDate] = useState<DateValue | null>(todayMidnight as unknown as DateValue)
    let [endDate, setEndDate] = useState<DateValue | null>(tomorrowMidnight as unknown as DateValue)


    return (
        <>
            <Card>
                <CardHeader className="pb-1 font-semibold">
                    {DeviceSensorTypeMap[sensor.sensor_type]} - {sensor.sensor_id}
                </CardHeader>
                <CardBody className="pt-1 min-h-[300px]">
                    {
                        sensor.sensor_type !== DEVICE_SENSOR_TYPE.AQI && startDate && endDate ?
                            <TimeSeriesNumberChart sensor={sensor} device={device} startDate={startDate as unknown as CalendarDate} endDate={endDate as unknown as CalendarDate} />
                            : null
                    }
                    {
                        sensor.sensor_type == DEVICE_SENSOR_TYPE.AQI && startDate && endDate ?
                            <TimeSeriesAQIChart sensor={sensor} device={device} startDate={startDate as unknown as CalendarDate} endDate={endDate as unknown as CalendarDate} />
                            : null
                    }
                </CardBody>
                <CardFooter className="flex gap-2">
                    <DatePicker
                        label="Start Date"
                        hideTimeZone
                        showMonthAndYearPickers
                        value={startDate}
                        onChange={setStartDate as any}
                        className="w-full"
                    />
                    <DatePicker
                        label="End Date"
                        hideTimeZone
                        showMonthAndYearPickers
                        value={endDate}
                        onChange={setEndDate as any}
                        className="w-full"
                    />
                </CardFooter>
            </Card>

        </>
    )
}

function DeviceChartSection() {

    const [devicesData, setDevicesData] = useState<DeviceDtoWithLatestSensorData[]>([])

    const sortDeviceSensor = (device: DeviceDtoWithLatestSensorData) => {
        return device.device_sensors?.sort((a, b) => a.sensor_id.localeCompare(b.sensor_id))
    }

    const query = useQuery({
        queryKey: ["devices_data_section"],
        queryFn: async () => {
            const response = await client.api.devices.latestData.get()

            const data = response.data as DeviceDtoWithLatestSensorData[]

            if (data && ('length' in data)) {
                data.sort((a, b) => a.name.localeCompare(b.name))
                setDevicesData(data)
            }

            return data
        },
        refetchInterval: 60 * 60 * 1000,
        refetchOnMount: true,
        refetchOnWindowFocus: true,
    });

    return (
        <>
            <Tabs aria-label="devices select display chart">
                {
                    devicesData.map((device) => (
                        <Tab key={device.id} title={device.name} className="">
                            <div className="flex flex-col gap-4 mb-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {
                                        sortDeviceSensor(device)?.map((sensor) => (
                                            <DeviceSensorChart key={sensor.sensor_id} sensor={sensor} device={device} />
                                        ))
                                    }
                                </div>
                            </div>
                        </Tab>
                    ))
                }
            </Tabs>
        </>
    )
}

function DeviceCard() {

    const [devicesCount, setDevicesCount] = useState<number>(0);
    const [onlineDevicesCount, setOnlineDevicesCount] = useState<number>(0);


    const { data: devicesCountData } = useQuery({
        queryKey: ["devices_count"],
        queryFn: async () => {
            const response = await client.api.devices.count.get()
            const { data, error } = response

            if (response.status === 200) {
                if (data && 'total' in data) {
                    setDevicesCount(data.total)
                }
                if (data && 'online' in data) {
                    setOnlineDevicesCount(data.online)
                }

                return data
            } else {

                return error
            }
        },
        refetchInterval: 60 * 1000,
        refetchOnMount: true,
        refetchOnWindowFocus: true,
    });

    return (
        <Card>
            <CardBody className="flex flex-row justify-between">
                <div className="flex flex-col justify-between">
                    <h2 className="text-lg font-semibold">Devices</h2>
                    <p className="text-4xl font-bold">{devicesCount}</p>
                </div>
                <div>
                    <CircularProgress
                        color="success"
                        size="lg"
                        showValueLabel={true}
                        valueLabel={onlineDevicesCount.toString()}
                        value={(onlineDevicesCount / devicesCount) * 100}
                        label={<span className="text-xs leading-none">Online</span>}
                    />
                </div>
            </CardBody>
        </Card>
    )
}
