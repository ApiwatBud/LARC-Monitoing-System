import { integer, pgTable, timestamp, varchar } from "drizzle-orm/pg-core";
import { AuditorName } from "../../../../../src/common/persistents/types";
import { EmailAlertSetting } from "../../../domains/entities/email_alert_setting.entity";

export const emailAlertSettingsTable = pgTable("email_alert_settings", {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    recipientEmail: varchar("recipient_email", { length: 255 }).notNull(),

    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}) satisfies Record<keyof Omit<EmailAlertSetting, AuditorName>, any>;
