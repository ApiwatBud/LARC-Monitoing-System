import { pgEnum } from "drizzle-orm/pg-core";
import { enumToPgEnum } from "../../../../../src/common/persistents/pgutils";
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DEVICE_METADATA_TYPE, DEVICE_SENSOR_TYPE, DEVICE_STATUS, PROCESS_STATUS } from "../../../domains/valueObject";

export const connection_status_enum = pgEnum('connection_status_enum', enumToPgEnum(DEVICE_CONNECTION_STATUS))
export const danger_status_enum = pgEnum('danger_status_enum', enumToPgEnum(DEVICE_DANGER_STATUS))
export const status_enum = pgEnum('status_enum', enumToPgEnum(DEVICE_STATUS))
export const metadata_type_enum = pgEnum('metadata_type_enum', enumToPgEnum(DEVICE_METADATA_TYPE))

export const sensor_type_enum = pgEnum('sensor_type_enum', enumToPgEnum(DEVICE_SENSOR_TYPE))

export const process_status_enum = pgEnum('process_status_enum', enumToPgEnum(PROCESS_STATUS))
