import { integer, pgTable, timestamp, varchar, text } from "drizzle-orm/pg-core";

/**
 * Table to track email rate limiting state
 * Keyed by device_id (0 for system-wide summary)
 */
export const emailRateLimitsTable = pgTable("email_rate_limits", {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    device_id: integer("device_id").notNull().unique(), // 0 for global summary
    last_sent_at: timestamp("last_sent_at").notNull().defaultNow(),
    sent_count: integer("sent_count").notNull().default(1),
    warning_fingerprint: text("warning_fingerprint"),
    deletedAt: timestamp("deleted_at"),

    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
