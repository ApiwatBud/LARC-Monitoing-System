import { doublePrecision, index, integer, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { devices_sensors_data_raw } from "./device_sensor_data_raw.pg.schema";
import { danger_status_enum, sensor_type_enum } from "./enums.pg.schema";
import { DEVICE_DANGER_STATUS } from "../../../domains/valueObject";

export const devices_sensors_data = pgTable('devices_sensors_data', {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    sensor_id: varchar('sensor_id'),
    device_name: varchar('device_name'),
    sensor_type: sensor_type_enum(),
    sensor_timestamp: timestamp({ withTimezone: true }).defaultNow(),
    raw_value: text('raw_value'),
    process_value_number: doublePrecision('process_value_number'),
    process_value_text: varchar('process_value_text'),
    raw_id: integer('raw_id').references(() => devices_sensors_data_raw.id, { onDelete: 'set null' }),
    dangerStatus: danger_status_enum('danger_status').default(DEVICE_DANGER_STATUS.NORMAL).notNull(),

    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),

}, (table) => [
    index('device_sensor_sensor_id_index').on(table.sensor_id),
    index('device_sensor_device_name_index').on(table.device_name),
    index('device_sensor_sensor_type_index').on(table.sensor_type),
    index('device_sensor_sensor_timestamp_index').on(table.sensor_timestamp),
])