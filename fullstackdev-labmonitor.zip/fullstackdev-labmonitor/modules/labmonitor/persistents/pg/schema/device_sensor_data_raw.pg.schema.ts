import { integer, json, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { PROCESS_STATUS } from "../../../domains/valueObject";
import { devices } from "./device.pg.schema";
import { process_status_enum } from "./enums.pg.schema";

export const devices_sensors_data_raw = pgTable('devices_sensors_data_raw', {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    device_id: integer('device_id').references(() => devices.id),
    device_name: varchar('device_name').references(() => devices.name),
    process_status: process_status_enum().default(PROCESS_STATUS.PENDING),
    values: json('values').default({}),
    process_log: text('process_log'),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}) 
