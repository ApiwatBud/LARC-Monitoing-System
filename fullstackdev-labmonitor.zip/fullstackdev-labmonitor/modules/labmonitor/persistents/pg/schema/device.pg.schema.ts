import { index, integer, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DEVICE_STATUS } from "../../../domains/valueObject";
import { connection_status_enum, danger_status_enum, status_enum } from "./enums.pg.schema";


export const devices = pgTable('devices', {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    name: varchar('name').unique(),
    description: text(),
    connection_status: connection_status_enum().default(DEVICE_CONNECTION_STATUS.OFFLINE).notNull(),
    danger_status: danger_status_enum().default(DEVICE_DANGER_STATUS.NORMAL).notNull(),
    status: status_enum().default(DEVICE_STATUS.INACTIVE).notNull(),
    last_seen: timestamp({ withTimezone: true }),
    raw_id: integer('raw_id'),
    token: varchar('token'),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}, (table) => [
    index('last_seen_index').on(table.last_seen),
    index('raw_id_index').on(table.raw_id)
])
