import { isNull } from "drizzle-orm";
import { doublePrecision, integer, pgTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";
import { DEVICE_METADATA_TYPE } from "../../../domains/valueObject";
import { devices } from "./device.pg.schema";
import { metadata_type_enum } from "./enums.pg.schema";
import { lower } from "./sql.pg.schema";

export const devices_envs = pgTable('devices_envs', {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    device_id: integer('device_id').references(() => devices.id),
    key: varchar('key'),
    type: metadata_type_enum().default(DEVICE_METADATA_TYPE.TEXT),
    value: text(),
    valueNumber: doublePrecision(),

    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),

}, (table) => [
    uniqueIndex('device_env_unique').on(lower(table.key), table.device_id).where(isNull(table.deletedAt))
])
