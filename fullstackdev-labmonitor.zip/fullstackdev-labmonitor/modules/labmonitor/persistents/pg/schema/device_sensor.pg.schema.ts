import { isNull } from "drizzle-orm";
import { doublePrecision, index, integer, pgTable, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";
import { DEVICE_DANGER_STATUS } from "../../../domains/valueObject";
import { devices } from "./device.pg.schema";
import { danger_status_enum, sensor_type_enum } from "./enums.pg.schema";
import { lower } from "./sql.pg.schema";

export const devices_sensors = pgTable('devices_sensors', {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    sensor_id: varchar('sensor_id'),
    device_id: integer('device_id').references(() => devices.id),
    sensor_type: sensor_type_enum(),
    danger_status: danger_status_enum().default(DEVICE_DANGER_STATUS.NORMAL).notNull(),
    normalMin: doublePrecision('normal_min'),
    normalMax: doublePrecision('normal_max'),
    dangerMin: doublePrecision('danger_min'),
    dangerMax: doublePrecision('danger_max'),

    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}, (table) => [
    uniqueIndex('device_sensor_unique').on(lower(table.sensor_id), table.device_id).where(isNull(table.deletedAt)),
    index('idx_devices_sensors_lookup').on(table.device_id, table.sensor_id, table.deletedAt)
])
