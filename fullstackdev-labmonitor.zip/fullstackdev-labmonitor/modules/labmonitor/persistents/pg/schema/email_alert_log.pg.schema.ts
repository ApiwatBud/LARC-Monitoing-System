import { index, integer, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { devices } from "./device.pg.schema";

export const emailAlertLogsTable = pgTable("email_alert_logs", {
    id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
    device_id: integer("device_id").notNull().references(() => devices.id),
    device_name: varchar("device_name", { length: 255 }).notNull(),
    alert_type: varchar("alert_type", { length: 50 }).notNull(), // 'device_warning', 'summary_warning'

    recipients: varchar("recipients", { length: 500 }).notNull(),
    subject: varchar("subject", { length: 255 }).notNull(),
    content: text("content"),
    message_id: varchar("message_id", { length: 255 }),

    sent_at: timestamp("sent_at").notNull().defaultNow(),

    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    deletedAt: timestamp("deleted_at"),
    createdBy: integer("created_by"),
    updatedBy: integer("updated_by"),
}, (table) => [
    index('eal_device_id_idx').on(table.device_id),
    index('eal_alert_type_idx').on(table.alert_type),
    index('eal_sent_at_idx').on(table.sent_at),
    index('eal_deleted_at_idx').on(table.deletedAt),
]);
