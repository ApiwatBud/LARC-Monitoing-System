import { eq } from "drizzle-orm";
import { GenericPgTransactionalRepository } from "../../../../../src/common/repositories/generic.pg.repository";
import { EmailRateLimitEntity } from "../../../domains/entities/email_rate_limit.entity";
import { IEmailRateLimitRepository } from "../../../domains/repositories/email_rate_limit.repository";
import { emailRateLimitsTable } from "../schema/email_rate_limit.pg.schema";
import { AnyPgTransaction } from "../../../../../src/common/persistents/types";
import { rowToEntity } from "../../../../../src/common/repositories/mapper";

export class EmailRateLimitPgRepository extends GenericPgTransactionalRepository<EmailRateLimitEntity, typeof emailRateLimitsTable> implements IEmailRateLimitRepository {
    constructor(dbClient: any) {
        super(dbClient, "EmailRateLimit", emailRateLimitsTable, "id", "deletedAt");
    }

    async findByDeviceId(props: { deviceId: number, transaction?: AnyPgTransaction }): Promise<EmailRateLimitEntity | null> {
        const client = this.getClient(props.transaction);
        const results = await client.select().from(this.table).where(eq(this.table.device_id, props.deviceId));
        if (results.length == 0) return null;
        return rowToEntity<EmailRateLimitEntity>(results[0]);
    }

    async upsert(props: { entity: Partial<EmailRateLimitEntity>, transaction?: AnyPgTransaction }): Promise<EmailRateLimitEntity> {
        const client = this.getClient(props.transaction);
        const { device_id, ...data } = props.entity;

        if (device_id === undefined) throw new Error("device_id is required for upsert");

        const existing = await this.findByDeviceId({ deviceId: device_id, transaction: props.transaction });

        if (existing) {
            const results = await client.update(this.table)
                .set({ ...data, updatedAt: new Date() })
                .where(eq(this.table.device_id, device_id))
                .returning();
            return rowToEntity<EmailRateLimitEntity>(results[0]);
        } else {
            const results = await client.insert(this.table)
                .values({ device_id, ...data, last_sent_at: data.last_sent_at || new Date() } as any)
                .returning();
            return rowToEntity<EmailRateLimitEntity>(results[0]);
        }
    }

    async deleteByDeviceId(props: { deviceId: number, transaction?: AnyPgTransaction }): Promise<void> {
        const client = this.getClient(props.transaction);
        await client.delete(this.table).where(eq(this.table.device_id, props.deviceId));
    }
}
