import { PgDatabase } from "drizzle-orm/pg-core";
import { GenericPgTransactionalRepository } from "../../../../../src/common/repositories/generic.pg.repository";
import { DeviceEntity } from "../../../domains/entities/device.entity";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { devices } from "../schema/device.pg.schema";
import { usersTable } from "../../../../../src/modules/core/persistents/pg/schema/user.pg.schema";
import { AnyPgTransaction } from "../../../../../src/common/persistents/types";
import { rowToEntity } from "../../../../../src/common/repositories/mapper";
import { and, desc, eq, isNull, ne } from "drizzle-orm";
import { DEVICE_CONNECTION_STATUS } from "../../../domains/valueObject";
import { differenceInMinutes } from 'date-fns';
import { DeviceWithSensorAndEnv } from "../../../domains/entities/device.aggs";
import { devices_sensors } from "../schema/device_sensor.pg.schema";
import { devices_envs } from "../schema/device_env.pg.schema";
import { devices_sensors_data } from "../schema/device_sensor_data.pg.schema";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { DeviceEnvEntity } from "../../../domains/entities/device_env.entity";
import { DeviceSensorDataEntity } from "../../../domains/entities/device_sensor_data.entity";

export class DevicePgRepository extends GenericPgTransactionalRepository<DeviceEntity, typeof devices> implements IDeviceRepository {
    constructor(db: PgDatabase<any, any, any>) {
        super(db, "Device", devices, "id", "deletedAt", usersTable);
    }
    async getWithLatestData(): Promise<DeviceWithSensorAndEnv[]> {
        const latestData = this.db.selectDistinctOn(
            [devices_sensors_data.device_name, devices_sensors_data.sensor_id]).from(devices_sensors_data)
            .orderBy(devices_sensors_data.device_name, devices_sensors_data.sensor_id, desc(devices_sensors_data.sensor_timestamp))
            .as('latest_data');

        const rows = await this.db.select().from(devices)
            .leftJoin(devices_sensors, eq(devices.id, devices_sensors.device_id))
            .leftJoin(devices_envs, eq(devices.id, devices_envs.device_id))
            .leftJoin(latestData, and(
                eq(devices.name, latestData.device_name),
                eq(devices_sensors.sensor_id, latestData.sensor_id)
            ))
            .where(isNull(devices.deletedAt));

        const result = rows.reduce<Record<number, DeviceWithSensorAndEnv>>(
            (acc, row) => {
                const device = row.devices;
                const sensor = row.devices_sensors;
                const env = row.devices_envs;
                const sensorData = row.latest_data;

                if (!acc[device.id]) {
                    acc[device.id] = { ...rowToEntity<DeviceEntity>(device), sensors: [], latest_sensor_data: [], envs: [] };
                }

                if (sensor && !acc[device.id].sensors.some(s => s.id === sensor.id)) {
                    acc[device.id].sensors.push(rowToEntity<DeviceSensorEntity>(sensor));
                }

                if (env && !acc[device.id].envs.some(e => e.id === env.id)) {
                    acc[device.id].envs.push(rowToEntity<DeviceEnvEntity>(env));
                }

                if (sensorData && !acc[device.id].latest_sensor_data?.some(sd => sd.id === sensorData.id)) {
                    acc[device.id].latest_sensor_data?.push(rowToEntity<DeviceSensorDataEntity>(sensorData));
                }

                return acc;
            },
            {}
        );
        return Object.values(result);
    }

    async findAllWithAggs(): Promise<DeviceWithSensorAndEnv[]> {
        const rows = await this.db.select().from(devices)
            .leftJoin(devices_sensors, eq(devices.id, devices_sensors.device_id))
            .leftJoin(devices_envs, eq(devices.id, devices_envs.device_id))
            .where(isNull(devices.deletedAt));

        const result = rows.reduce<Record<number, DeviceWithSensorAndEnv>>(
            (acc, row) => {
                const device = row.devices;
                const sensor = row.devices_sensors;
                const env = row.devices_envs;

                if (!acc[device.id]) {
                    acc[device.id] = { ...rowToEntity<DeviceEntity>(device), sensors: [], envs: [] };
                }

                if (sensor) {
                    acc[device.id].sensors.push(rowToEntity<DeviceSensorEntity>(sensor));
                }

                if (env) {
                    acc[device.id].envs.push(rowToEntity<DeviceEnvEntity>(env));
                }

                return acc;
            },
            {}
        );
        return Object.values(result);
    }
    async findByName({ name, transaction }: { name: string, transaction?: AnyPgTransaction }): Promise<DeviceEntity> {
        let result = await this.db.select().from(devices).where(eq(devices.name, name)).limit(1)

        return rowToEntity<DeviceEntity>(result[0])
    }
    async findByToken({ token, transaction }: { token: string, transaction?: AnyPgTransaction }): Promise<DeviceEntity | null> {
        let result = await this.db.select().from(devices).where(eq(devices.token, token)).limit(1)

        return result[0] ? rowToEntity<DeviceEntity>(result[0]) : null
    }
    async healthCheck({ minutes }: { minutes: number }) {
        const list_devices = await this.db.select().from(devices).where(and(isNull(devices.deletedAt), ne(devices.connection_status, DEVICE_CONNECTION_STATUS.OFFLINE)));
        // console.log(list_devices)
        for (const device of list_devices) {
            if (device.connection_status === DEVICE_CONNECTION_STATUS.ONLINE) {
                if (device.last_seen) {
                    // console.log(differenceInMinutes(new Date(), new Date(device.last_seen)), device.name)
                    if (differenceInMinutes(new Date(), new Date(device.last_seen)) > minutes) {
                        await this.db.update(devices).set({
                            connection_status: DEVICE_CONNECTION_STATUS.OFFLINE,
                        }).where(eq(devices.id, device.id));
                    }
                } else {
                    await this.db.update(devices).set({
                        connection_status: DEVICE_CONNECTION_STATUS.OFFLINE,
                    }).where(eq(devices.id, device.id));
                }
            }
        }
    }
}