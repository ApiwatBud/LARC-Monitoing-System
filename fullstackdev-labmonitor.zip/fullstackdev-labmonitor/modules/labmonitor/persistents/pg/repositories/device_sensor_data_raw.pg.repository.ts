import { GenericPgTransactionalRepository } from "../../../../../src/common/repositories/generic.pg.repository";
import { DeviceSensorDataRawEntity } from "../../../domains/entities/device_sensor_data_raw.entity";
import { IDeviceSensorDataRawRepository } from "../../../domains/repositories/device_sensor_data_raw.repository";
import { devices_sensors_data_raw } from "../schema/device_sensor_data_raw.pg.schema";
import { PgDatabase } from "drizzle-orm/pg-core";

export class DeviceSensorDataRawPgRepository extends GenericPgTransactionalRepository<DeviceSensorDataRawEntity, typeof devices_sensors_data_raw> implements IDeviceSensorDataRawRepository {
    constructor(db: PgDatabase<any, any, any>) {
        super(db, "devices_sensors_data_raw", devices_sensors_data_raw, "id", "deletedAt");
    }
}
