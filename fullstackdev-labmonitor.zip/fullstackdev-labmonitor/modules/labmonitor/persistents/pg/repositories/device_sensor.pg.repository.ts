import { GenericChildPgTransactionalRepository } from "../../../../../src/common/repositories/pg/generic.child.pg.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { devices_sensors } from "../schema/device_sensor.pg.schema";
import { PgDatabase } from "drizzle-orm/pg-core";
import { and, eq, isNull } from "drizzle-orm";
import { AnyTransaction } from "../../../../../src/common/persistents/types";
import { rowToEntity } from "../../../../../src/common/repositories/mapper";

export class DeviceSensorPgRepository extends GenericChildPgTransactionalRepository<DeviceSensorEntity, typeof devices_sensors> implements IDeviceSensorRepository {
    constructor(db: PgDatabase<any, any, any>) {
        super(db, "devices_sensors", devices_sensors, "id", "device_id", undefined);
    }

    async findBySensorId(props: {
        parentId: number;
        sensorId: string;
        transaction?: AnyTransaction
    }): Promise<DeviceSensorEntity | null> {
        const db = (props.transaction as any) || this.db;

        const result = await db
            .select()
            .from(this.table)
            .where(
                and(
                    eq(this.table.device_id, props.parentId),
                    eq(this.table.sensor_id, props.sensorId),
                    isNull(this.table.deletedAt)
                )
            )
            .limit(1);

        return result[0] ? rowToEntity<DeviceSensorEntity>(result[0]) : null;
    }
}
