import { and, eq, gte, lte } from "drizzle-orm";
import { GenericPgTransactionalRepository } from "../../../../../src/common/repositories/generic.pg.repository";
import { DeviceSensorDataFilterDTO, DeviceSensorDataResponseDTO } from "../../../applications/dtos/device_sensor_data.dto";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { DeviceSensorDataEntity } from "../../../domains/entities/device_sensor_data.entity";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { devices_sensors_data } from "../schema/device_sensor_data.pg.schema";
import { PgDatabase } from "drizzle-orm/pg-core";
import { rowToEntity } from "../../../../../src/common/repositories/mapper";

export class DeviceSensorDataPgRepository extends GenericPgTransactionalRepository<DeviceSensorDataEntity, typeof devices_sensors_data> implements IDeviceSensorDataRepository {
    constructor(db: PgDatabase<any, any, any>) {
        super(db, "devices_sensors_data", devices_sensors_data, "id", "deletedAt");
    }
    async loadData(body: DeviceSensorDataFilterDTO): Promise<DeviceSensorDataEntity[]> {
        const result = await this.db.select()
            .from(devices_sensors_data)
            .where(
                and(eq(devices_sensors_data.device_name, body.device_name),
                    eq(devices_sensors_data.sensor_id, body.sensor_id),
                    gte(devices_sensors_data.sensor_timestamp, new Date(body.start_date)),
                    lte(devices_sensors_data.sensor_timestamp, new Date(body.end_date)))
            )

        let entities = result.map((row) => rowToEntity<DeviceSensorDataEntity>(row))
        return entities as DeviceSensorDataEntity[]
    }
}
