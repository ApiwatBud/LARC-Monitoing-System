import { GenericChildPgTransactionalRepository } from "../../../../../src/common/repositories/pg/generic.child.pg.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { DeviceEnvEntity } from "../../../domains/entities/device_env.entity";
import { devices_envs } from "../schema/device_env.pg.schema";
import { PgDatabase } from "drizzle-orm/pg-core";

export class DeviceEnvPgRepository extends GenericChildPgTransactionalRepository<DeviceEnvEntity, typeof devices_envs> implements IDeviceEnvRepository {
    constructor(db: PgDatabase<any, any, any>) {
        super(db, "devices_envs", devices_envs, "id", "device_id", undefined);
    }
}