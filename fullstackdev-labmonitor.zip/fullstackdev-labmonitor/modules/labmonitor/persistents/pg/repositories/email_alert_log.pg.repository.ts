import { GenericPgTransactionalRepository } from "../../../../../src/common/repositories/generic.pg.repository";
import { EmailAlertLogEntity } from "../../../domains/entities/email_alert_log.entity";
import { IEmailAlertLogRepository } from "../../../domains/repositories/email_alert_log.repository";
import { emailAlertLogsTable } from "../schema/email_alert_log.pg.schema";
import { AnyPgTransaction } from "../../../../../src/common/persistents/types";

export class EmailAlertLogPgRepository extends GenericPgTransactionalRepository<EmailAlertLogEntity, typeof emailAlertLogsTable> implements IEmailAlertLogRepository {
    constructor(dbClient: any) {
        super(dbClient, "EmailAlertLog", emailAlertLogsTable, "id", "deletedAt");
    }

    async logAlert(props: {
        device_id: number,
        device_name: string,
        alert_type: string,
        recipients: string,
        subject: string,
        content?: string,
        message_id?: string,
        transaction?: AnyPgTransaction
    }): Promise<void> {
        const client = this.getClient(props.transaction);
        const { device_id, device_name, alert_type, recipients, subject, content, message_id } = props;

        await client.insert(this.table)
            .values({
                device_id,
                device_name,
                alert_type,
                recipients,
                subject,
                content,
                message_id,
                sent_at: new Date(),
                createdAt: new Date(),
                updatedAt: new Date()
            } as any);
    }
}
