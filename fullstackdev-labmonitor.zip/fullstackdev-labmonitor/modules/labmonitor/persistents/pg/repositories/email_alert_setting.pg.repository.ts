import { PgDatabase } from "drizzle-orm/pg-core";
import { GenericPgTransactionalRepository } from "../../../../../src/common/repositories/generic.pg.repository";
import { EmailAlertSetting } from "../../../domains/entities/email_alert_setting.entity";
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { emailAlertSettingsTable } from "../schema/email_alert_setting.pg.schema";
import { usersTable } from "../../../../../src/modules/core/persistents/pg/schema/user.pg.schema";

export class EmailAlertSettingPgRepository extends GenericPgTransactionalRepository<EmailAlertSetting, typeof emailAlertSettingsTable> implements IEmailAlertSettingRepository {
    constructor(db: PgDatabase<any, any, any>) {
        super(db, "EmailAlertSetting", emailAlertSettingsTable, "id", "deletedAt", usersTable);
    }
}
