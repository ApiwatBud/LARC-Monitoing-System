import Elysia from "elysia";
import { DevicePgRepository } from "./persistents/pg/repositories/device.pg.repository";
import { DeviceEnvPgRepository } from "./persistents/pg/repositories/device_env.pg.repository";
import { DeviceSensorPgRepository } from "./persistents/pg/repositories/device_sensor.pg.repository";
import { DeviceSensorDataRawPgRepository } from "./persistents/pg/repositories/device_sensor_data_raw.pg.repository";
import { DeviceSensorDataPgRepository } from "./persistents/pg/repositories/device_sensor_data.pg.repository";
import { EmailAlertSettingPgRepository } from "./persistents/pg/repositories/email_alert_setting.pg.repository";

import { EmailRateLimitPgRepository } from "./persistents/pg/repositories/email_rate_limit.pg.repository";
import { EmailAlertLogPgRepository } from "./persistents/pg/repositories/email_alert_log.pg.repository";
import pgClient from "../../src/common/persistents/pgClient";

export const LabMonitorIoC = new Elysia()
    .decorate("dbClient", pgClient)
    .decorate("deviceRepository", new DevicePgRepository(pgClient))
    .decorate("deviceEnvRepository", new DeviceEnvPgRepository(pgClient))
    .decorate("deviceSensorRepository", new DeviceSensorPgRepository(pgClient))
    .decorate("deviceSensorDataRawRepository", new DeviceSensorDataRawPgRepository(pgClient))
    .decorate("deviceSensorDataRepository", new DeviceSensorDataPgRepository(pgClient))
    .decorate("emailAlertSettingRepository", new EmailAlertSettingPgRepository(pgClient))
    .decorate("emailRateLimitRepository", new EmailRateLimitPgRepository(pgClient))
    .decorate("emailAlertLogRepository", new EmailAlertLogPgRepository(pgClient));
