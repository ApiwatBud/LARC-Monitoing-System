#!/usr/bin/env bun
import { LabMonitorIoC } from "../../ioc";
import { ConfigIoC } from "../../../../src/modules/config/ioc";
import { HealthCheck } from "../usecases/devices/healthCheck";
import * as p from '@clack/prompts';

/**
 * Manual Health Check CLI Script
 * 
 * Usage:
 *   bun run src/modules/labmonitor/applications/cli/healthCheck.cli.ts
 *   bun run src/modules/labmonitor/applications/cli/healthCheck.cli.ts --minutes 10
 *   bun run src/modules/labmonitor/applications/cli/healthCheck.cli.ts --force
 */

export async function main() {
    console.log("╔═══════════════════════════════════════╗");
    console.log("║   Lab Monitor Health Check CLI       ║");
    console.log("╚═══════════════════════════════════════╝\n");

    // Parse command line arguments
    const args = process.argv.slice(2);
    const minutesArg = args.find(arg => arg.startsWith('--minutes='));
    const minutes = minutesArg ? parseInt(minutesArg.split('=')[1]) : 5;

    let force = args.includes('--force') || args.includes('-f');

    // If not forced by flag, ask interactively
    if (!force) {
        const bypass = await p.confirm({
            message: 'Do you want to bypass the email rate limit?',
            initialValue: false
        });
        if (p.isCancel(bypass)) return;
        force = bypass;
    }

    console.log(`⚙️  Configuration:`);
    console.log(`   - Check window: ${minutes} minutes`);
    console.log(`   - Bypass rate limit: ${force ? 'YES' : 'NO'}`);
    console.log(`   - Timestamp: ${new Date().toLocaleString('th-TH')}\n`);

    // Initialize Health Check use case
    const healthCheck = HealthCheck({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository,
        emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository,
        configRepository: ConfigIoC.decorator.configRepository,
        emailRateLimitRepository: LabMonitorIoC.decorator.emailRateLimitRepository,
        emailAlertLogRepository: LabMonitorIoC.decorator.emailAlertLogRepository
    });

    // Run health check
    const startTime = Date.now();

    console.log("🔍 Running health check...\n");

    try {
        const result = await healthCheck({
            minutes,
            bypassRateLimit: force
        });

        const duration = Date.now() - startTime;

        console.log("\n╔═══════════════════════════════════════╗");
        console.log("║         HEALTH CHECK RESULTS          ║");
        console.log("╚═══════════════════════════════════════╝");
        console.log(`✅ Status: Complete`);
        console.log(`⏱️  Duration: ${duration}ms`);
        console.log(`\n📊 Statistics:`);
        console.log(`   - Connection checked: ${result.connectionChecked} devices`);
        console.log(`   - Devices checked: ${result.devicesChecked}`);
        console.log(`   - Devices updated: ${result.devicesUpdated}`);
        console.log(`   - Emails sent: ${result.emailsSent}`);
        console.log(`   - Emails skipped: ${result.emailsSkipped}`);

        // Exit with success
        console.log("\n✅ Health check completed successfully!\n");

    } catch (error) {
        console.error("\n╔═══════════════════════════════════════╗");
        console.error("║            ERROR OCCURRED             ║");
        console.error("╚═══════════════════════════════════════╝");
        console.error("❌ Health check failed:", error);
    }
}

// Still allow running directly if needed
if (import.meta.main) {
    main().then(() => process.exit(0)).catch(() => process.exit(1));
}
