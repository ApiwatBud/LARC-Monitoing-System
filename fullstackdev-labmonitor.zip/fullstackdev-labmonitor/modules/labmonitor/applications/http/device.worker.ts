import cron from "@elysiajs/cron"
import cronstrue from "cronstrue"
import Elysia from "elysia"
import { LabMonitorIoC } from "../../ioc"
import { ConfigIoC } from "../../../../src/modules/config/ioc"
import { HealthCheck } from "../usecases/devices/healthCheck"

const deviceHealthCheckCronPattern = process.env.DEVICE_HEALTH_CHECK_CRON || '*/5 * * * *'
console.log("Device Health Check : " + cronstrue.toString(deviceHealthCheckCronPattern))

const deviceHealthCheckMinutes = Number(process.env.DEVICE_HEALTH_CHECK_MINUTES) || 5

// Initialize HealthCheck use case with all dependencies
const healthCheck = HealthCheck({
    deviceRepository: LabMonitorIoC.decorator.deviceRepository,
    deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository,
    emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository,
    configRepository: ConfigIoC.decorator.configRepository,
    emailRateLimitRepository: LabMonitorIoC.decorator.emailRateLimitRepository,
    emailAlertLogRepository: LabMonitorIoC.decorator.emailAlertLogRepository
})

export const DeviceCron = new Elysia()
    .use(cron({
        name: 'device_health_check',
        pattern: deviceHealthCheckCronPattern,
        async run() {
            const timestamp = new Date().toISOString()
            console.log(`\n⏰ [${timestamp}] Running Device Health Check...`)

            try {
                const result = await healthCheck({ minutes: deviceHealthCheckMinutes })

                console.log(`✅ Health Check Complete:`)
                console.log(`   - Connection checked: ${result.connectionChecked} devices`)
                console.log(`   - Devices checked: ${result.devicesChecked}`)
                console.log(`   - Devices updated: ${result.devicesUpdated}`)
                console.log(`   - Emails sent: ${result.emailsSent}`)
                console.log(`   - Emails skipped: ${result.emailsSkipped}`)
            } catch (error) {
                console.error(`❌ Health Check Failed:`, error)
            }
        }
    }))
