import { Elysia, t } from "elysia";
import { PaginateQueryDto } from "../../../../src/common/types";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";
import { LabMonitorIoC } from "../../ioc";
import { DeviceSensorDataCreateDTO, DeviceSensorDataFilterDTO, DeviceSensorDataUpdateDTO } from "../dtos/device_sensor_data.dto";
import { CreateDeviceSensorData } from "../usecases/deviceSensorData/createDeviceSensorData";
import { DeleteDeviceSensorData } from "../usecases/deviceSensorData/deleteDeviceSensorData";
import { GetDeviceSensorData } from "../usecases/deviceSensorData/getDeviceSensorData";
import { PaginateDeviceSensorData } from "../usecases/deviceSensorData/paginateDeviceSensorData";
import { UpdateDeviceSensorData } from "../usecases/deviceSensorData/updateDeviceSensorData";
import { DeviceSensorDataExcelExport } from "../usecases/deviceSensorData/excelExport";
import { logger } from "../../../../src/common/utils/logger";
import { LoadDeviceSensorData } from "../usecases/deviceSensorData/loadData";

const DeviceSensorDataUsecase = new Elysia()
    .use(LabMonitorIoC)
    .decorate("loadDeviceSensorData", LoadDeviceSensorData({ deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository }))
    .decorate("paginateData", PaginateDeviceSensorData({ deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository }))
    .decorate("excelExport", DeviceSensorDataExcelExport({ deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository }))
    .decorate("createData", CreateDeviceSensorData({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository,
        deviceEnvRepository: LabMonitorIoC.decorator.deviceEnvRepository,
        deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository
    }))
    .decorate("getData", GetDeviceSensorData({ deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository }))
    .decorate("updateData", UpdateDeviceSensorData({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository,
        deviceEnvRepository: LabMonitorIoC.decorator.deviceEnvRepository
    }))
    .decorate("deleteData", DeleteDeviceSensorData({ deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository }))

export const DeviceSensorDataHttp = new Elysia({
    detail: {
        tags: ['api.device-sensor-data']
    }
})
    .use(AuthMiddleware)
    .use(DeviceSensorDataUsecase)
    .group("/device-sensor-data", (app) => app
        .post("/loaddata", ({ body, user, permissions, loadDeviceSensorData }) => loadDeviceSensorData({
            query: body,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: DeviceSensorDataFilterDTO,
            permission: ["guest"]
        })
        .post("/filter", ({ body, paginateData, user, permissions }) => paginateData({
            page: body.page,
            limit: body.limit,
            filter: body.filter as any,
            sort: body.sort as any,
            withAudit: body.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("", ({ body, user, permissions, paginateData }) => paginateData({
            page: body.page,
            limit: body.limit,
            filter: body.filter as any,
            sort: body.sort as any,
            withAudit: body.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("export", ({ body, user, permissions, excelExport }) => excelExport({
            page: body.page,
            limit: -1,
            filter: body.filter as any,
            sort: body.sort as any,
            withAudit: body.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("", async ({ body, user, permissions, createData }) => {
            logger.info({ action: 'create_sensor_data', device_name: body.device_name, sensor_id: body.sensor_id, performed_by: user?.email }, `Creating sensor data for ${body.device_name}`);
            const result = await createData({
                dto: body,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'create_sensor_data_success', result_id: result.id }, `Sensor data created successfully`);
            return result
        }, {
            body: DeviceSensorDataCreateDTO,
            permission: ["anyone"]
        })
        .get("/:id", ({ params, getData, user, permissions }) => getData({
            id: Number(params.id),
            context: { user, permissions: permissions as any || [] }
        }), {
            params: t.Object({
                id: t.String()
            }),
            permission: ["anyone"]
        })
        .put("/:id", async ({ params, body, user, permissions, updateData }) => {
            const id = Number(params.id)
            logger.info({ action: 'update_sensor_data', target_id: id, performed_by: user?.email }, `Updating sensor data ID ${id}`);
            const result = await updateData({
                id: id,
                dto: body,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'update_sensor_data_success', target_id: id }, `Sensor data ID ${id} updated successfully`);
            return result
        }, {
            params: t.Object({
                id: t.String()
            }),
            body: DeviceSensorDataUpdateDTO,
            permission: ["anyone"]
        })
        .delete("/:id", async ({ params, deleteData, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'delete_sensor_data', target_id: id, performed_by: user?.email }, `Deleting sensor data ID ${id}`);
            const result = await deleteData({
                id: id,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'delete_sensor_data_success', target_id: id }, `Sensor data ID ${id} deleted successfully`);
            return result
        }, {
            params: t.Object({
                id: t.String()
            }),
            permission: ["anyone"]
        })
    )
