import { Elysia, t } from "elysia";
import { PaginateQueryDto } from "../../../../src/common/types";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";
import { LabMonitorIoC } from "../../ioc";
import { DeviceSensorDataRawCreateDTO, DeviceSensorDataRawUpdateDTO } from "../dtos/device_sensor_data_raw.dto";
import { CreateDeviceSensorDataRaw } from "../usecases/deviceSensorDataRaw/createDeviceSensorDataRaw";
import { DeleteDeviceSensorDataRaw } from "../usecases/deviceSensorDataRaw/deleteDeviceSensorDataRaw";
import { GetDeviceSensorDataRaw } from "../usecases/deviceSensorDataRaw/getDeviceSensorDataRaw";
import { PaginateDeviceSensorDataRaw } from "../usecases/deviceSensorDataRaw/paginateDeviceSensorDataRaw";
import { UpdateDeviceSensorDataRaw } from "../usecases/deviceSensorDataRaw/updateDeviceSensorDataRaw";
import { logger } from "../../../../src/common/utils/logger";
import { background } from "elysia-background"
export const DeviceSensorDataRawUsecase = new Elysia()
    .use(LabMonitorIoC)
    .decorate("createDeviceSensorDataRaw", CreateDeviceSensorDataRaw({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceEnvRepository: LabMonitorIoC.decorator.deviceEnvRepository,
        deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository,
        deviceSensorDataRepository: LabMonitorIoC.decorator.deviceSensorDataRepository,
        deviceSensorDataRawRepository: LabMonitorIoC.decorator.deviceSensorDataRawRepository,
    }))
    .decorate("deleteDeviceSensorDataRaw", DeleteDeviceSensorDataRaw({
        deviceSensorDataRawRepository: LabMonitorIoC.decorator.deviceSensorDataRawRepository,
    }))
    .decorate("getDeviceSensorDataRaw", GetDeviceSensorDataRaw({
        deviceSensorDataRawRepository: LabMonitorIoC.decorator.deviceSensorDataRawRepository,
    }))
    .decorate("paginateDeviceSensorDataRaw", PaginateDeviceSensorDataRaw({
        deviceSensorDataRawRepository: LabMonitorIoC.decorator.deviceSensorDataRawRepository,
    }))
    .decorate("updateDeviceSensorDataRaw", UpdateDeviceSensorDataRaw({
        deviceSensorDataRawRepository: LabMonitorIoC.decorator.deviceSensorDataRawRepository,
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
    }))


export const DeviceSensorDataRawHttp = new Elysia({
    detail: {
        tags: ['api.device-sensor-data-raw']
    }
})
    .use(DeviceSensorDataRawUsecase)
    .use(AuthMiddleware)
    .use(background())
    .group("/device_sensor_data_raw", (app) => app
        .post("", async ({ body, user, permissions, createDeviceSensorDataRaw, backgroundTasks }) => {
            logger.info({ action: 'create_raw_sensor_data', device_name: body.device_name, performed_by: user?.email }, `Creating raw sensor data for device ${body.device_name}`);
            const result = await createDeviceSensorDataRaw({
                dto: body,
                context: { user, permissions: permissions as any || [], backgroundTasks: backgroundTasks }
            })
            logger.info({ action: 'create_raw_sensor_data_success', result_id: result.id }, `Raw sensor data created successfully`);
            return result
        }, {
            body: DeviceSensorDataRawCreateDTO,
            permission: ["guest"]
        })

    )
    .group("/device-sensor-data-raw", (app) => app
        .get("", ({ query, paginateDeviceSensorDataRaw, user, permissions }) => paginateDeviceSensorDataRaw({
            page: query.page,
            limit: query.limit,
            filter: query.filter as any,
            sort: query.sort as any,
            withAudit: query.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            query: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("/filter", ({ body, paginateDeviceSensorDataRaw, user, permissions }) => paginateDeviceSensorDataRaw({
            page: body.page,
            limit: body.limit,
            filter: body.filter as any,
            sort: body.sort as any,
            withAudit: body.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("", async ({ body, user, permissions, createDeviceSensorDataRaw, backgroundTasks }) => {
            logger.info({ action: 'create_raw_sensor_data', device_name: body.device_name, performed_by: user?.email }, `Creating raw sensor data for device ${body.device_name}`);
            const result = await createDeviceSensorDataRaw({
                dto: body,
                context: {
                    user, permissions: permissions as any || [],
                    backgroundTasks: backgroundTasks
                }
            })
            logger.info({ action: 'create_raw_sensor_data_success', result_id: result.id }, `Raw sensor data created successfully`);
            return result
        }, {
            body: DeviceSensorDataRawCreateDTO,
            permission: ["anyone"]
        })
        .get("/:id", ({ params, getDeviceSensorDataRaw, user, permissions }) => getDeviceSensorDataRaw({
            id: Number(params.id),
            context: { user, permissions: permissions as any || [] }
        }), {
            params: t.Object({
                id: t.String()
            }),
            permission: ["anyone"]
        })
        .put("/:id", async ({ params, body, user, permissions, updateDeviceSensorDataRaw }) => {
            const id = Number(params.id)
            logger.info({ action: 'update_raw_sensor_data', target_id: id, performed_by: user?.email }, `Updating raw sensor data ID ${id}`);
            const result = await updateDeviceSensorDataRaw({
                id: id,
                dto: body,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'update_raw_sensor_data_success', target_id: id }, `Raw sensor data ID ${id} updated successfully`);
            return result
        }, {
            params: t.Object({
                id: t.String()
            }),
            body: DeviceSensorDataRawUpdateDTO,
            permission: ["anyone"]
        })
        .delete("/:id", async ({ params, deleteDeviceSensorDataRaw, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'delete_raw_sensor_data', target_id: id, performed_by: user?.email }, `Deleting raw sensor data ID ${id}`);
            const result = await deleteDeviceSensorDataRaw({
                id: id,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'delete_raw_sensor_data_success', target_id: id }, `Raw sensor data ID ${id} deleted successfully`);
            return result
        }, {
            params: t.Object({
                id: t.String()
            }),
            permission: ["anyone"]
        })
    )
