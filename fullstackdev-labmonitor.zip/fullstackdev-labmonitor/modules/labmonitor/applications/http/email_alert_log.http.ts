import { Elysia, t } from "elysia";
import { PaginateQueryDto } from "../../../../src/common/types";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";
import { LabMonitorIoC } from "../../ioc";
import { PaginateEmailAlertLog } from "../usecases/emailAlertLogs/paginateEmailAlertLog";

const EmailAlertLogUsecase = new Elysia()
    .use(LabMonitorIoC)
    .decorate("paginateLogs", PaginateEmailAlertLog({
        emailAlertLogRepository: LabMonitorIoC.decorator.emailAlertLogRepository
    }));

export const EmailAlertLogHttp = new Elysia({
    detail: {
        tags: ['api.email-alert-log']
    }
})
    .use(AuthMiddleware)
    .use(EmailAlertLogUsecase)
    .group("/email-alert-logs", (app) => app
        .post("/filter", ({ body, paginateLogs, user, permissions }) => paginateLogs({
            page: body.page,
            limit: body.limit,
            filter: body.filter as any,
            sort: body.sort as any,
            withAudit: body.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
    );
