import Elysia from "elysia";
import { LabMonitorIoC } from "../../ioc";
import { CreateDevice } from "../usecases/devices/createDevice";
import { DeleteDevice } from "../usecases/devices/deleteDevice";
import { GetDevice } from "../usecases/devices/getDevice";
import { GetAllDevices } from "../usecases/devices/getAllDevices";
import { GetDeviceSensorByDeviceName } from "../usecases/devices/getDeviceSensorByDevice";
import { PaginateDevice } from "../usecases/devices/paginateDevice";
import { UpdateDevice } from "../usecases/devices/updateDevice";
import { CountDevice } from "../usecases/devices/countDevice";
import { GetDeviceWithLatestData } from "../usecases/devices/getDevicesWithLatestData";

export const DeviceUseCase = new Elysia()
    .use(LabMonitorIoC)
    .decorate("paginateDevice", PaginateDevice({ deviceRepository: LabMonitorIoC.decorator.deviceRepository }))
    .decorate("countDevice", CountDevice({ deviceRepository: LabMonitorIoC.decorator.deviceRepository }))
    .decorate("createDevice", CreateDevice({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceEnvRepository: LabMonitorIoC.decorator.deviceEnvRepository,
        deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository
    }))
    .decorate("getDevice", GetDevice(
        {
            deviceRepository: LabMonitorIoC.decorator.deviceRepository,
            deviceEnvRepository: LabMonitorIoC.decorator.deviceEnvRepository,
            deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository
        }))
    .decorate("updateDevice", UpdateDevice({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceEnvRepository: LabMonitorIoC.decorator.deviceEnvRepository,
        deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository
    }))
    .decorate("deleteDevice", DeleteDevice({ deviceRepository: LabMonitorIoC.decorator.deviceRepository }))
    .decorate("getAllDevices", GetAllDevices({ deviceRepository: LabMonitorIoC.decorator.deviceRepository }))
    .decorate("getDeviceSensorByDevice", GetDeviceSensorByDeviceName({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        deviceSensorRepository: LabMonitorIoC.decorator.deviceSensorRepository
    }))
    .decorate("getDeviceWithLatestData", GetDeviceWithLatestData({ deviceRepository: LabMonitorIoC.decorator.deviceRepository }))