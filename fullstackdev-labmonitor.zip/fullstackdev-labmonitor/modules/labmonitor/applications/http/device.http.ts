import { Elysia, t } from "elysia";
import { LabMonitorIoC } from "../../ioc";
import { DeviceAggsCreateDTO, DeviceAggsUpdateDTO } from "../dtos/device.dto.aggs";
import { DeviceUseCase } from "./device.usecase.http";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";
import { PaginateQueryDto } from "../../../../src/common/types";
import { logger } from "../../../../src/common/utils/logger";


export const DeviceHttp = new Elysia({
    detail: {
        tags: ['api.devices']
    }
})
    .use(AuthMiddleware)
    .use(LabMonitorIoC)
    .use(DeviceUseCase)
    .group("/devices", (app) => app
        .get("", async ({ getAllDevices, user, permissions }) => {
            return await getAllDevices({
                context: { user, permissions: permissions as any || [] }
            })
        }, {
            permission: ["anyone"]
        })
        .get("/latestData", async ({ getDeviceWithLatestData, user, permissions }) => {
            return await getDeviceWithLatestData({
                context: { user, permissions: permissions as any || [] }
            })
        }, {
            permission: ["guest"]
        })
        .get("/count", async ({ countDevice, user, permissions }) => {
            return await countDevice({
                context: { user, permissions: permissions as any || [] }
            })
        }, {
            permission: ["anyone"]
        })
        .post("/filter", ({ paginateDevice, body, user, permissions }) => paginateDevice({
            page: body.page,
            limit: body.limit,
            filter: body.filter as any,
            sort: body.sort as any,
            withAudit: body.withAudit,
            context: { user, permissions: permissions as any || [] }
        }), {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("", async ({ createDevice, body, user, permissions }) => {
            logger.info({ action: 'create_device', device_name: body.name, performed_by: user?.email }, `Creating device ${body.name}`);
            const result = await createDevice({
                dto: body,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'create_device_success', device_name: body.name, result_id: result.id }, `Device ${body.name} created successfully`);
            return result
        }, {
            body: DeviceAggsCreateDTO,
            permission: ["anyone"]
        })
        .get("/:id", ({ getDevice, params, user, permissions }) => getDevice({
            id: Number(params.id),
            context: { user, permissions: permissions as any || [] }
        }), {
            params: t.Object({
                id: t.String()
            }),
            permission: ["anyone"]
        })

        .get("byName/:name/deviceSensors", ({ getDeviceSensorByDevice, params, user, permissions }) => getDeviceSensorByDevice({
            name: String(params.name),
            context: { user, permissions: permissions as any || [] }
        }), {
            params: t.Object({
                name: t.String()
            }),
            permission: ["anyone"]
        })

        .put("/:id", async ({ updateDevice, params, body, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'update_device', target_id: id, device_name: body.name, performed_by: user?.email }, `Updating device ID ${id} (${body.name})`);
            const result = await updateDevice({
                id: id,
                dto: body,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'update_device_success', target_id: id }, `Device ID ${id} updated successfully`);
            return result
        }, {
            params: t.Object({
                id: t.String()
            }),
            body: DeviceAggsUpdateDTO,
            permission: ["anyone"]
        })
        .delete("/:id", async ({ deleteDevice, params, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'delete_device', target_id: id, performed_by: user?.email }, `Deleting device ID ${id}`);
            const result = await deleteDevice({
                id: id,
                context: { user, permissions: permissions as any || [] }
            })
            logger.info({ action: 'delete_device_success', target_id: id }, `Device ID ${id} deleted successfully`);
            return result
        }, {
            params: t.Object({
                id: t.String()
            }),
            permission: ["anyone"]
        })
    )


