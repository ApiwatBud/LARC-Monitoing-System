import { Elysia, t } from "elysia";
import { LabMonitorIoC } from "../../ioc";
import { CreateEmailAlertSetting } from "../usecases/emailAlertSettings/createEmailAlertSetting";
import { UpdateEmailAlertSetting } from "../usecases/emailAlertSettings/updateEmailAlertSetting";
import { DeleteEmailAlertSetting } from "../usecases/emailAlertSettings/deleteEmailAlertSetting";
import { GetEmailAlertSetting } from "../usecases/emailAlertSettings/getEmailAlertSetting";
import { PaginateEmailAlertSetting } from "../usecases/emailAlertSettings/paginateEmailAlertSetting";
import { PaginateQueryDto } from "../../../../src/common/types";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";
import { EmailAlertSettingCreateDto, EmailAlertSettingUpdateDto } from "../dtos/email_alert_setting.dto";
import { logger } from "../../../../src/common/utils/logger";

export const EmailAlertSettingUseCase = new Elysia()
    .use(LabMonitorIoC)
    .decorate("createEmailAlertSetting", CreateEmailAlertSetting({
        emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository
    }))
    .decorate("updateEmailAlertSetting", UpdateEmailAlertSetting({
        emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository
    }))
    .decorate("deleteEmailAlertSetting", DeleteEmailAlertSetting({
        emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository
    }))
    .decorate("getEmailAlertSetting", GetEmailAlertSetting({
        emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository
    }))
    .decorate("paginateEmailAlertSetting", PaginateEmailAlertSetting({
        emailAlertSettingRepository: LabMonitorIoC.decorator.emailAlertSettingRepository
    }));

export const EmailAlertSettingHttp = new Elysia({
    detail: {
        tags: ['labmonitor.email_alert_settings']
    }
})
    .use(EmailAlertSettingUseCase)
    .group("/email-alert-settings", (app) => app
        .use(AuthMiddleware)
        .post("/filter", async ({ body, paginateEmailAlertSetting, user, permissions }) => {
            return await paginateEmailAlertSetting({
                page: body.page,
                limit: body.limit,
                filter: body.filter as any,
                sort: body.sort as any,
                withAudit: body.withAudit,
                context: { user, permissions: permissions as any || [] }
            });
        }, {
            body: PaginateQueryDto,
            permission: ["anyone"]
        })
        .post("", async ({ body, createEmailAlertSetting, user, permissions }) => {
            logger.info({ action: 'create_email_alert_setting', recipient_email: body.recipientEmail, performed_by: user?.email }, `Creating email alert setting for ${body.recipientEmail}`);
            const result = await createEmailAlertSetting({
                dto: body,
                context: { user, permissions: permissions as any || [] }
            });
            logger.info({ action: 'create_email_alert_setting_success', result_id: result.id }, `Email alert setting created successfully`);
            return result
        }, {
            body: EmailAlertSettingCreateDto,
            permission: ["anyone"]
        })
        .get("/:id", async ({ params, getEmailAlertSetting, user, permissions }) => {
            return await getEmailAlertSetting({
                id: Number(params.id),
                context: { user, permissions: permissions as any || [] }
            });
        }, {
            permission: ["anyone"]
        })
        .patch("/:id", async ({ params, body, updateEmailAlertSetting, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'update_email_alert_setting', target_id: id, performed_by: user?.email }, `Updating email alert setting ID ${id}`);
            const result = await updateEmailAlertSetting({
                id: id,
                dto: body,
                context: { user, permissions: permissions as any || [] }
            });
            logger.info({ action: 'update_email_alert_setting_success', target_id: id }, `Email alert setting ID ${id} updated successfully`);
            return result
        }, {
            body: EmailAlertSettingUpdateDto,
            permission: ["anyone"]
        })
        .delete("/:id", async ({ params, deleteEmailAlertSetting, user, permissions }) => {
            const id = Number(params.id)
            logger.info({ action: 'delete_email_alert_setting', target_id: id, performed_by: user?.email }, `Deleting email alert setting ID ${id}`);
            const result = await deleteEmailAlertSetting({
                id: id,
                context: { user, permissions: permissions as any || [] }
            });
            logger.info({ action: 'delete_email_alert_setting_success', target_id: id }, `Email alert setting ID ${id} deleted successfully`);
            return result
        }, {
            permission: ["anyone"]
        })
    );
