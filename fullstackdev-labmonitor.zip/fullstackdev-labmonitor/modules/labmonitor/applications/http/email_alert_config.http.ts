import { Elysia } from "elysia";
import { ConfigIoC } from "../../../../src/modules/config/ioc";
import { GetEmailAlertConfig } from "../usecases/emailAlertConfig/getEmailAlertConfig";
import { SaveEmailAlertConfig } from "../usecases/emailAlertConfig/saveEmailAlertConfig";
import { EmailAlertConfigDto } from "../dtos/email_alert_config.dto";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";
import { logger } from "../../../../src/common/utils/logger";

export const EmailAlertConfigUseCase = new Elysia()
    .decorate("getEmailAlertConfig", GetEmailAlertConfig({
        configRepository: ConfigIoC.decorator.configRepository
    }))
    .decorate("saveEmailAlertConfig", SaveEmailAlertConfig({
        configRepository: ConfigIoC.decorator.configRepository
    }));

export const EmailAlertConfigHttp = new Elysia({
    detail: {
        tags: ['labmonitor.email_alert_config']
    }
})
    .use(EmailAlertConfigUseCase)
    .group("/email-alert-config", (app) => app
        .use(AuthMiddleware)
        .get("", async ({ getEmailAlertConfig, user, permissions }) => {
            return await getEmailAlertConfig({
                context: { user, permissions: permissions as any || [] }
            });
        }, {
            permission: ["anyone"]
        })
        .post("", async ({ body, saveEmailAlertConfig, user, permissions }) => {
            logger.info({ action: 'save_email_alert_config', performed_by: user?.email }, `Saving email alert configuration`);
            const result = await saveEmailAlertConfig({
                dto: body,
                context: { user, permissions: permissions as any || [] }
            });
            logger.info({ action: 'save_email_alert_config_success' }, `Email alert configuration saved successfully`);
            return result
        }, {
            body: EmailAlertConfigDto,
            permission: ["anyone"]
        })
    );