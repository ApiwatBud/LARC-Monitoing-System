import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { EmailAlertSettingResponseDto } from "../../dtos/email_alert_setting.dto";

interface GetEmailAlertSettingDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository
}

interface GetEmailAlertSettingProps {
    id: number
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const GetEmailAlertSetting: TUsecase<GetEmailAlertSettingDeps, GetEmailAlertSettingProps, EmailAlertSettingResponseDto> = (deps) => async (props) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const result = await deps.emailAlertSettingRepository.findById({ id: props.id });
    if (!result) {
        throw new BusinessValidationError([
            {
                path: ['id'],
                message: 'Email alert setting not found',
                code: 'custom'
            }
        ]);
    }

    return EmailAlertSettingResponseDto.parse(result);
}
