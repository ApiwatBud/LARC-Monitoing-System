import { TUsecase } from "../../../../../src/common/types";
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { EmailAlertSettingUpdateDto, EmailAlertSettingResponseDto } from "../../dtos/email_alert_setting.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { BusinessValidationError } from "../../../../../src/common/errors";

interface UpdateEmailAlertSettingDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository
}

interface UpdateEmailAlertSettingProps {
    id: number
    dto: EmailAlertSettingUpdateDto
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const UpdateEmailAlertSetting: TUsecase<UpdateEmailAlertSettingDeps, UpdateEmailAlertSettingProps, EmailAlertSettingResponseDto> = (deps) => async (props) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Update);
    const validated = await EmailAlertSettingUpdateDto.parseAsync(props.dto);

    const emailAlertSetting = await deps.emailAlertSettingRepository.findById({ id: props.id });
    if (!emailAlertSetting) {
        throw new BusinessValidationError([
            {
                path: ['id'],
                message: 'Email alert setting not found',
                code: 'custom'
            }
        ]);
    }

    const result = await deps.emailAlertSettingRepository.update({
        id: props.id,
        entity: {
            recipientEmail: validated.recipientEmail
        },
        userId: guard.user?.id
    });

    return EmailAlertSettingResponseDto.parse(result);
}
