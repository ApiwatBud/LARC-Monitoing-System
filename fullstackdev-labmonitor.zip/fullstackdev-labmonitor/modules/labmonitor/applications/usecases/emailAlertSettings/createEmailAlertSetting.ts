import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { EmailAlertSettingCreateDto, EmailAlertSettingResponseDto } from "../../dtos/email_alert_setting.dto";

interface CreateEmailAlertSettingDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository
}

interface CreateEmailAlertSettingProps {
    dto: EmailAlertSettingCreateDto
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const CreateEmailAlertSetting: TUsecase<CreateEmailAlertSettingDeps, CreateEmailAlertSettingProps, EmailAlertSettingResponseDto> = (deps) => async (props) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Create);
    const validated = await EmailAlertSettingCreateDto.parseAsync(props.dto);

    const result = await deps.emailAlertSettingRepository.create({
        entity: {
            recipientEmail: validated.recipientEmail
        },
        userId: guard.user?.id
    });

    return EmailAlertSettingResponseDto.parse(result);
}
