import { TUsecase } from "../../../../../src/common/types";
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { EmailAlertSettingResponseDto } from "../../dtos/email_alert_setting.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface DeleteEmailAlertSettingDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository
}

interface DeleteEmailAlertSettingProps {
    id: number
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const DeleteEmailAlertSetting: TUsecase<DeleteEmailAlertSettingDeps, DeleteEmailAlertSettingProps, EmailAlertSettingResponseDto> = (deps) => async (props) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Delete);
    const result = await deps.emailAlertSettingRepository.delete({
        id: props.id
    });

    return EmailAlertSettingResponseDto.parse(result);
}
