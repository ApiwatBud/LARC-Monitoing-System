import { TPaginateQuery, TPaginateResult, TUsecase } from "../../../../../src/common/types";
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { EmailAlertSettingResponseDto } from "../../dtos/email_alert_setting.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface PaginateEmailAlertSettingDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository
}

interface PaginateEmailAlertSettingProps extends TPaginateQuery<EmailAlertSettingResponseDto> {
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const PaginateEmailAlertSetting: TUsecase<PaginateEmailAlertSettingDeps, PaginateEmailAlertSettingProps, TPaginateResult<EmailAlertSettingResponseDto>> = (deps) => async (props) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    let { page, limit, filter, sort, withAudit } = props;
    page = page || 1;
    limit = limit || 20;
    filter = filter || [];
    sort = sort || [];
    withAudit = withAudit || false;

    return await deps.emailAlertSettingRepository.paginate({
        query: { page, limit, filter, sort, withAudit }
    });
}
