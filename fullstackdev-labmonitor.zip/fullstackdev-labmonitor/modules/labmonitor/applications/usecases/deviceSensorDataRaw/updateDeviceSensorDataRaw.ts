import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IDeviceSensorDataRawRepository } from "../../../domains/repositories/device_sensor_data_raw.repository";
import { DeviceSensorDataRawResponseDTO, DeviceSensorDataRawUpdateDTO } from "../../dtos/device_sensor_data_raw.dto";

import { IDeviceRepository } from "../../../domains/repositories/device.repository";

interface UpdateDeviceSensorDataRawDeps {
    deviceSensorDataRawRepository: IDeviceSensorDataRawRepository
    deviceRepository: IDeviceRepository
}

interface UpdateDeviceSensorDataRawProps {
    id: number
    dto: DeviceSensorDataRawUpdateDTO
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const UpdateDeviceSensorDataRaw: TUsecase<UpdateDeviceSensorDataRawDeps, UpdateDeviceSensorDataRawProps, DeviceSensorDataRawResponseDTO> = (deps: UpdateDeviceSensorDataRawDeps) => async (props: UpdateDeviceSensorDataRawProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Write);
    const validated = await DeviceSensorDataRawUpdateDTO.parseAsync(props.dto);

    const existing = await deps.deviceSensorDataRawRepository.findById({ id: props.id });
    if (!existing) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device sensor data raw not found',
            code: 'custom'
        }]);
    }

    let deviceId = undefined;
    if (validated.device_name) {
        const devices = await deps.deviceRepository.paginate({
            query: {
                page: 1,
                limit: 1,
                filter: [{ key: 'name', operator: '=', value: validated.device_name }],
                sort: [],
                withAudit: false
            }
        });

        if (devices.data.length === 0) {
            throw new BusinessValidationError([{
                path: ['device_name'],
                message: `Device with name "${validated.device_name}" not found`,
                code: 'custom'
            }]);
        }
        deviceId = devices.data[0].id;
    }

    const result = await deps.deviceSensorDataRawRepository.update({
        id: props.id,
        entity: {
            ...validated,
            ...(deviceId !== undefined ? { device_id: deviceId } : {})
        },
        userId: guard.user?.id
    });

    return DeviceSensorDataRawResponseDTO.parse(result);
}
