import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { DeviceSensorDataRawEntity } from "../../../domains/entities/device_sensor_data_raw.entity";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { IDeviceSensorDataRawRepository } from "../../../domains/repositories/device_sensor_data_raw.repository";
import { PROCESS_STATUS } from "../../../domains/valueObject";
import { DeviceSensorDataRawCreateDTO, DeviceSensorDataRawResponseDTO } from "../../dtos/device_sensor_data_raw.dto";
import { UpdateLastSeenUseCase } from "../devices/updateLastSeen";
import { ProcessSensorData } from "../deviceSensorData/proessDeviceSensorData";
import { CalculateSensorDangerStatus } from "../deviceSensorData/checkSensorThreshold";
import { UpdateSensorStatus } from "../deviceSensorData/updateSensorStatus";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface CreateDeviceSensorDataRawDeps {
    deviceSensorDataRawRepository: IDeviceSensorDataRawRepository
    deviceRepository: IDeviceRepository
    deviceEnvRepository: IDeviceEnvRepository,
    deviceSensorRepository: IDeviceSensorRepository,
    deviceSensorDataRepository: IDeviceSensorDataRepository,
}

interface CreateDeviceSensorDataRawProps {
    dto: DeviceSensorDataRawCreateDTO
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";
import { isNullOrUndefined } from "../../../../../src/common/utils/utils";

export const CreateDeviceSensorDataRaw: TUsecase<CreateDeviceSensorDataRawDeps, CreateDeviceSensorDataRawProps, DeviceSensorDataRawResponseDTO> = (deps: CreateDeviceSensorDataRawDeps) => async (props: CreateDeviceSensorDataRawProps) => {
    const guard = createGuard(props.context);
    //guard.ensure(LabmonitorPermissions.Ingest);

    return await deps.deviceRepository.transaction(async (tx) => {
        const validated = props.dto;

        // Find device_id by device_name
        const device = await deps.deviceRepository.findByName({
            name: validated.device_name,
            transaction: tx
        });

        if (!device) {
            throw new BusinessValidationError([{
                path: ['device_name'],
                message: `Device with name "${validated.device_name}" not found`,
                code: 'custom'
            }]);
        }

        if (device.token && device.token !== validated.device_token) {
            throw new BusinessValidationError([{
                path: ['device_token'],
                message: `Invalid device token for device "${validated.device_name}"`,
                code: 'custom'
            }]);
        }

        const result = await deps.deviceSensorDataRawRepository.create({
            entity: {
                ...validated,
                process_status: PROCESS_STATUS.PENDING,
                device_id: device.id,
                process_log: ""
            },
            userId: guard.user?.id,
            transaction: tx
        });


        let backgroundTasks = props.context.backgroundTasks
        if (backgroundTasks) {
            backgroundTasks.addTask(
                ProcessRawSubUsecase({
                    ...deps,
                    processSensorDataUsecase: ProcessSensorData(deps)
                })
                , { entity: result }
            )

            backgroundTasks.addTask(
                UpdateLastSeenUseCase({
                    deviceRepository: deps.deviceRepository
                })
                , { device_id: device.id, userId: guard.user?.id }
            )
        }

        return DeviceSensorDataRawResponseDTO.parse(result);
    })
}

interface ProcessRawSubUsecaseDeps {
    deviceRepository: IDeviceRepository
    deviceEnvRepository: IDeviceEnvRepository
    deviceSensorRepository: IDeviceSensorRepository
    deviceSensorDataRepository: IDeviceSensorDataRepository
    deviceSensorDataRawRepository: IDeviceSensorDataRawRepository
    processSensorDataUsecase: ReturnType<typeof ProcessSensorData>
}

interface ProcessRawSubUsecaseProps {
    entity: DeviceSensorDataRawEntity

}
const ProcessRawSubUsecase = (deps: ProcessRawSubUsecaseDeps) => async ({ entity }: ProcessRawSubUsecaseProps) => {

    let values = entity.values
    let device_id = entity.device_id
    let processed_success_data: any[] = []
    const process_log: any[] = []

    try {
        return await deps.deviceRepository.transaction(async (transaction) => {
            const process = async (entity: DeviceSensorDataRawEntity) => {

                console.log("start process", entity)
                process_log.push({
                    message: "start process",
                    data: entity
                })
                const device = await deps.deviceRepository.findById({ id: device_id })
                if (!device) {
                    process_log.push({
                        message: "device not found",
                        data: entity
                    })
                    throw new BusinessValidationError([{
                        path: ['device_id'],
                        message: 'Device not found',
                        code: 'custom'
                    }]);
                }
                process_log.push({
                    message: "device found",
                    data: device
                })
                const envs = await deps.deviceEnvRepository.findAll({ parentId: device.id })
                process_log.push({
                    message: "envs found",
                    data: envs
                })
                const device_sensors = await deps.deviceSensorRepository.findAll({ parentId: device.id })
                process_log.push({
                    message: "device_sensors found",
                    data: device_sensors
                })
                for (const sensor_id in values) {
                    const sensor = device_sensors.find((s) => s.sensor_id === sensor_id)
                    if (!sensor) {
                        process_log.push({
                            message: "sensor not found",
                            data: entity
                        })
                        throw new BusinessValidationError([{
                            path: ['sensor_id'],
                            message: 'Sensor not found',
                            code: 'custom'
                        }]);
                    }
                    process_log.push({
                        message: "sensor found",
                        data: sensor
                    })
                    let processed = await deps.processSensorDataUsecase({
                        envs: envs,
                        sensor_id: sensor_id,
                        sensor_type: sensor.sensor_type,
                        raw_value: values[sensor_id],
                    })
                    process_log.push({
                        message: "sensor processed",
                        data: processed
                    })

                    if (!(isNullOrUndefined(processed.process_value_number) || isNullOrUndefined(processed.process_value_text))) {
                        process_log.push({
                            message: "sensor processed failed",
                            data: processed
                        })
                        continue;
                    }

                    // Calculate danger status before creating (pass sensor to avoid query)
                    const dangerStatus = await CalculateSensorDangerStatus(
                        deps.deviceSensorRepository,
                        device_id,
                        sensor_id,
                        processed.process_value_number ?? undefined,
                        sensor // Pass existing sensor entity to avoid query
                    );
                    process_log.push({
                        message: "danger status calculated",
                        data: dangerStatus
                    })
                    let newEntity = {
                        ...entity,
                        ...processed,
                        id: undefined,
                        device_id: device_id,
                        sensor_id: sensor_id,
                        sensor_type: sensor.sensor_type,
                        sensor_timestamp: entity.createdAt,
                        raw_value: values[sensor_id],
                        raw_id: entity.id,
                        dangerStatus: dangerStatus,
                    }


                    let result = await deps.deviceSensorDataRepository.create({
                        entity: newEntity,
                        userId: entity.createdBy ?? undefined,
                        transaction: transaction
                    })
                    process_log.push({
                        message: "sensor data created",
                        data: result
                    })
                    // Update sensor danger_status using helper (pass sensor to avoid query)
                    await UpdateSensorStatus({
                        deviceSensorRepository: deps.deviceSensorRepository,
                        deviceId: device_id,
                        sensorId: sensor_id,
                        dangerStatus: dangerStatus,
                        userId: entity.createdBy ?? undefined,
                        transaction: transaction,
                        sensor: sensor // Pass existing sensor entity to avoid query
                    });
                    process_log.push({
                        message: "sensor status updated",
                        data: result
                    })
                    processed_success_data.push(result)
                }


                process_log.push({
                    message: "end process",
                    data: processed_success_data
                })
            }

            await process(entity)


            await deps.deviceSensorDataRawRepository.update({
                id: entity.id,
                entity: {
                    process_status: processed_success_data.length == 0 ? PROCESS_STATUS.FAILED : processed_success_data.length === Object.keys(values).length ? PROCESS_STATUS.COMPLETED : PROCESS_STATUS.PARTIAL_SUCCESS,
                    process_log: JSON.stringify(process_log)
                },
                userId: entity.createdBy ?? undefined,
                transaction: transaction
            })

        })
    } catch (error) {
        console.error("ProcessRawSubUsecase error:", error);
        process_log.push({
            message: "process failed",
            data: error
        })
        await deps.deviceSensorDataRawRepository.update({
            id: entity.id,
            entity: {
                process_status: PROCESS_STATUS.FAILED,
                process_log: JSON.stringify(process_log)
            },
            userId: entity.createdBy ?? undefined
        })
    }
}
