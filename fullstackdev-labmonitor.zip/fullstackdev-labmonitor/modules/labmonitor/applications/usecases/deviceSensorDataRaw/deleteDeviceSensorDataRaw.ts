import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { IDeviceSensorDataRawRepository } from "../../../domains/repositories/device_sensor_data_raw.repository";
import { DeviceSensorDataRawResponseDTO } from "../../dtos/device_sensor_data_raw.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface DeleteDeviceSensorDataRawDeps {
    deviceSensorDataRawRepository: IDeviceSensorDataRawRepository
}

interface DeleteDeviceSensorDataRawProps {
    id: number
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const DeleteDeviceSensorDataRaw: TUsecase<DeleteDeviceSensorDataRawDeps, DeleteDeviceSensorDataRawProps, DeviceSensorDataRawResponseDTO> = (deps: DeleteDeviceSensorDataRawDeps) => async (props: DeleteDeviceSensorDataRawProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Delete);
    const existing = await deps.deviceSensorDataRawRepository.findById({ id: props.id });
    if (!existing) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device sensor data raw not found',
            code: 'custom'
        }]);
    }

    const result = await deps.deviceSensorDataRawRepository.delete({ id: props.id });

    return DeviceSensorDataRawResponseDTO.parse(result);
}
