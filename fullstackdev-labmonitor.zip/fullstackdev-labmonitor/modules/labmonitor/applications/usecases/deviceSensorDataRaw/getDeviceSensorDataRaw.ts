import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { IDeviceSensorDataRawRepository } from "../../../domains/repositories/device_sensor_data_raw.repository";
import { DeviceSensorDataRawResponseDTO } from "../../dtos/device_sensor_data_raw.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface GetDeviceSensorDataRawDeps {
    deviceSensorDataRawRepository: IDeviceSensorDataRawRepository
}

interface GetDeviceSensorDataRawProps {
    id: number
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const GetDeviceSensorDataRaw: TUsecase<GetDeviceSensorDataRawDeps, GetDeviceSensorDataRawProps, DeviceSensorDataRawResponseDTO> = (deps: GetDeviceSensorDataRawDeps) => async (props: GetDeviceSensorDataRawProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const result = await deps.deviceSensorDataRawRepository.findById({ id: props.id });

    if (!result) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device sensor data raw not found',
            code: 'custom'
        }]);
    }

    return DeviceSensorDataRawResponseDTO.parse(result);
}
