import { TPaginateQuery, TPaginateResult, TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IDeviceSensorDataRawRepository } from "../../../domains/repositories/device_sensor_data_raw.repository";
import { DeviceSensorDataRawResponseDTO } from "../../dtos/device_sensor_data_raw.dto";

interface PaginateDeviceSensorDataRawDeps {
    deviceSensorDataRawRepository: IDeviceSensorDataRawRepository
}

interface PaginateDeviceSensorDataRawProps extends TPaginateQuery<DeviceSensorDataRawResponseDTO> {
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const PaginateDeviceSensorDataRaw: TUsecase<PaginateDeviceSensorDataRawDeps, PaginateDeviceSensorDataRawProps, TPaginateResult<DeviceSensorDataRawResponseDTO>> = (deps: PaginateDeviceSensorDataRawDeps) => async (props: PaginateDeviceSensorDataRawProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const result = await deps.deviceSensorDataRawRepository.paginate({ query: props as any });

    return {
        ...result,
        data: result.data.map(item => DeviceSensorDataRawResponseDTO.parse(item))
    };
}
