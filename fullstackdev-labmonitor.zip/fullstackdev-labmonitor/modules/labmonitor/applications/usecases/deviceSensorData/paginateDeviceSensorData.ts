import { TPaginateQuery, TPaginateResult } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { DeviceSensorDataEntity } from "../../../domains/entities/device_sensor_data.entity";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DeviceSensorDataResponseDTO } from "../../dtos/device_sensor_data.dto";


interface PaginateDeviceSensorDataDeps {
    deviceSensorDataRepository: IDeviceSensorDataRepository
}

interface PaginateDeviceSensorDataProps extends TPaginateQuery<DeviceSensorDataEntity> {
    context: UsecaseContext
}


export const PaginateDeviceSensorData = (deps: PaginateDeviceSensorDataDeps) => async (props: PaginateDeviceSensorDataProps): Promise<TPaginateResult<DeviceSensorDataResponseDTO>> => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const result = await deps.deviceSensorDataRepository.paginate({ query: props });

    return {
        ...result,
        data: result.data.map(item => DeviceSensorDataResponseDTO.parse({
            ...item,
        }))
    };
}
