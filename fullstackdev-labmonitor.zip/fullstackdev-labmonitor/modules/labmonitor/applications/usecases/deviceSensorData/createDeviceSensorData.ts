import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { DeviceEnvEntity } from "../../../domains/entities/device_env.entity";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DeviceSensorDataCreateDTO, DeviceSensorDataResponseDTO } from "../../dtos/device_sensor_data.dto";
import { CalculateSensorDangerStatus } from "./checkSensorThreshold";
import { ProcessSensorData, ProcessSensorNeedEnv } from "./proessDeviceSensorData";
import { UpdateSensorStatus } from "./updateSensorStatus";

interface CreateDeviceSensorDataDeps {
    deviceSensorDataRepository: IDeviceSensorDataRepository
    deviceRepository: IDeviceRepository
    deviceEnvRepository: IDeviceEnvRepository
    deviceSensorRepository: IDeviceSensorRepository
}

interface CreateDeviceSensorDataProps {
    dto: DeviceSensorDataCreateDTO
    context: UsecaseContext
}

export const CreateDeviceSensorData: TUsecase<CreateDeviceSensorDataDeps, CreateDeviceSensorDataProps, DeviceSensorDataResponseDTO> = (deps: CreateDeviceSensorDataDeps) => async (props: CreateDeviceSensorDataProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Write);

    const deivce = await deps.deviceRepository.findByName({ name: props.dto.device_name })
    if (!deivce) {
        throw new BusinessValidationError([{
            path: ['device_name'],
            message: 'Device not found',
            code: 'custom'
        }]);
    }
    let envs: DeviceEnvEntity[] = []
    if (ProcessSensorNeedEnv[props.dto.sensor_type]) {
        envs = await deps.deviceEnvRepository.findAll({ parentId: deivce.id })
    }

    const processed = await ProcessSensorData({})({
        sensor_id: props.dto.sensor_id,
        sensor_type: props.dto.sensor_type,
        raw_value: props.dto.raw_value,
        envs: envs,
    })

    // Calculate danger status before creating
    const dangerStatus = await CalculateSensorDangerStatus(
        deps.deviceSensorRepository,
        deivce.id,
        props.dto.sensor_id,
        processed.process_value_number ?? undefined
    );

    const result = await deps.deviceSensorDataRepository.create({
        entity: {
            device_id: deivce.id,
            ...props.dto,
            sensor_timestamp: new Date(props.dto.sensor_timestamp),
            ...processed,
            raw_id: props.dto.raw_id ? props.dto.raw_id : undefined,
            dangerStatus: dangerStatus,
        },
        userId: guard.user?.id
    });

    // Update sensor danger_status
    await UpdateSensorStatus({
        deviceSensorRepository: deps.deviceSensorRepository,
        deviceId: deivce.id,
        sensorId: props.dto.sensor_id,
        dangerStatus: dangerStatus,
        userId: guard.user?.id
    });

    return DeviceSensorDataResponseDTO.parse({
        ...result
    });
}