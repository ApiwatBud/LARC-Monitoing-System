import { BusinessValidationError } from "../../../../../src/common/errors";
import { AnyTransaction } from "../../../../../src/common/persistents/types";
import { TUsecase } from "../../../../../src/common/types";
import { DeviceEnvEntity } from "../../../domains/entities/device_env.entity";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { DEVICE_SENSOR_TYPE } from "../../../domains/valueObject";

interface ProcessSensorDataDeps {
}
interface ProcessSensorDataProps {
    sensor_type: DEVICE_SENSOR_TYPE,
    raw_value: string,
    envs: DeviceEnvEntity[],
    sensor_id: string
}
export const ProcessSensorData: TUsecase<ProcessSensorDataDeps, ProcessSensorDataProps, {
    process_value_number?: number,
    process_value_text?: string
}>
    = (deps) => async (props) => {

        const handler = ProcessSensorDataMapFunction[props.sensor_type];
        if (handler) {
            return Promise.resolve(handler(props.raw_value, props.sensor_id, props.envs));
        }

        return Promise.resolve({});
    }


const parseNumber = (rawValue: string, _sensor_id: string, _envs: DeviceEnvEntity[]) => {
    const parsed = parseFloat(rawValue);
    return { process_value_number: isNaN(parsed) ? null : parsed };
};

const parseText = (rawValue: string, _sensor_id: string, _envs: DeviceEnvEntity[]) => ({ process_value_text: rawValue });

const parseWaterLevel = (rawValue: string, sensor_id: string, envs: DeviceEnvEntity[]) => {

    const needed_env_key = `SENSOR_HIGH_MM_${sensor_id}`.toUpperCase()
    const env = envs.find((e) => e.key === needed_env_key)
    if (!env) {
        throw new BusinessValidationError([
            {
                path: ['env'],
                message: `Env ${needed_env_key} not found`,
                code: 'custom'
            }
        ]);
    }

    const parsed = parseFloat(rawValue);
    if (isNaN(parsed)) {
        throw new BusinessValidationError([
            {
                path: ['raw_value'],
                message: `Raw value ${rawValue} is not a number`,
                code: 'custom'
            }
        ]);
    }
    const env_value = parseFloat(env.value)
    if (isNaN(env_value)) {
        throw new BusinessValidationError([
            {
                path: ['env'],
                message: `Env ${needed_env_key} is not a number`,
                code: 'custom'
            }
        ]);
    }
    return { process_value_number: env_value - parsed };
};

export const ProcessSensorDataMapFunction: Record<DEVICE_SENSOR_TYPE, (rawValue: string, sensor_id: string, envs: DeviceEnvEntity[]) => { process_value_number?: number | null, process_value_text?: string | null }> = {
    [DEVICE_SENSOR_TYPE.AMMONIA]: parseNumber,
    [DEVICE_SENSOR_TYPE.AQL_PPM]: parseNumber,
    [DEVICE_SENSOR_TYPE.AQI]: parseText,
    [DEVICE_SENSOR_TYPE.HUMID]: parseNumber,
    [DEVICE_SENSOR_TYPE.LIGHT]: parseNumber,
    [DEVICE_SENSOR_TYPE.RAW]: parseNumber,
    [DEVICE_SENSOR_TYPE.SOUND]: parseNumber,
    [DEVICE_SENSOR_TYPE.TEMP]: parseNumber,
    [DEVICE_SENSOR_TYPE.V_BATT]: parseNumber,
    [DEVICE_SENSOR_TYPE.WATER_LEVEL]: parseWaterLevel,
}

export const ProcessSensorNeedEnv: Record<DEVICE_SENSOR_TYPE, boolean | string[]> = {
    [DEVICE_SENSOR_TYPE.AMMONIA]: false,
    [DEVICE_SENSOR_TYPE.AQL_PPM]: false,
    [DEVICE_SENSOR_TYPE.AQI]: false,
    [DEVICE_SENSOR_TYPE.HUMID]: false,
    [DEVICE_SENSOR_TYPE.LIGHT]: false,
    [DEVICE_SENSOR_TYPE.RAW]: false,
    [DEVICE_SENSOR_TYPE.SOUND]: false,
    [DEVICE_SENSOR_TYPE.TEMP]: false,
    [DEVICE_SENSOR_TYPE.V_BATT]: false,
    [DEVICE_SENSOR_TYPE.WATER_LEVEL]: ['SENSOR_HIGH_MM'],
}