import { TUsecase } from "../../../../../src/common/types";
import { isNullOrUndefined } from "../../../../../src/common/utils/utils";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DEVICE_DANGER_STATUS } from "../../../domains/valueObject";

interface CheckSensorThresholdDeps {
    deviceSensorRepository: IDeviceSensorRepository;
    deviceSensorDataRepository: IDeviceSensorDataRepository;
}

interface CheckSensorThresholdProps {
    sensorDataId: number;
    deviceId: number;
    deviceName: string;
    sensorId: string;
    processValueNumber?: number;
    userId?: number;
}

interface CheckSensorThresholdResult {
    dangerStatus: DEVICE_DANGER_STATUS;
    sensorUpdated: boolean;
    sensorDataUpdated: boolean;
}

/**
 * Calculate sensor danger status based on thresholds
 * 
 * Performance tip: Pass sensor entity if already available to avoid extra query
 */
export const CalculateSensorDangerStatus = async (
    deviceSensorRepository: IDeviceSensorRepository,
    deviceId: number,
    sensorId: string,
    processValueNumber?: number,
    sensor?: DeviceSensorEntity // Optional: pass existing sensor to avoid query
): Promise<DEVICE_DANGER_STATUS> => {

    // Default to NORMAL if no numeric value
    if (processValueNumber === undefined || processValueNumber === null) {
        return DEVICE_DANGER_STATUS.NORMAL;
    }

    // Use provided sensor or fetch it
    let sensorConfig = sensor;
    if (!sensorConfig) {
        const fetchedSensor = await deviceSensorRepository.findBySensorId({
            parentId: deviceId,
            sensorId: sensorId
        });
        sensorConfig = fetchedSensor ?? undefined;
    }

    // Default to NORMAL if sensor not found
    if (!sensorConfig) {
        return DEVICE_DANGER_STATUS.NORMAL;
    }

    // Check if thresholds are configured
    console.log('sensorConfig', sensorConfig)


    if (isNullOrUndefined(sensorConfig.normalMin) || isNullOrUndefined(sensorConfig.normalMax)) {
        return DEVICE_DANGER_STATUS.NORMAL;
    }

    // Check if value is outside normal range
    const belowMin = sensorConfig.normalMin !== undefined && processValueNumber < sensorConfig.normalMin;
    const aboveMax = sensorConfig.normalMax !== undefined && processValueNumber > sensorConfig.normalMax;

    // If not outside normal range, status is NORMAL
    if (!belowMin && !aboveMax) {
        return DEVICE_DANGER_STATUS.NORMAL;
    }

    // Check if value crosses DANGER threshold (if configured)
    // Danger threshold extends beyond normal range
    const belowDangerMin = sensorConfig.dangerMin !== undefined && !isNullOrUndefined(sensorConfig.dangerMin)
        ? processValueNumber < sensorConfig.dangerMin
        : false;
    const aboveDangerMax = sensorConfig.dangerMax !== undefined && !isNullOrUndefined(sensorConfig.dangerMax)
        ? processValueNumber > sensorConfig.dangerMax
        : false;

    // If a danger threshold is crossed, status is DANGER; otherwise WARNING
    return (belowDangerMin || aboveDangerMax)
        ? DEVICE_DANGER_STATUS.DANGER
        : DEVICE_DANGER_STATUS.WARNING;
};

/**
 * Use case to check if sensor data exceeds normal thresholds
 * and update both sensor and sensor_data danger status accordingly
 */
export const CheckSensorThreshold: TUsecase<CheckSensorThresholdDeps, CheckSensorThresholdProps, CheckSensorThresholdResult> =
    (deps: CheckSensorThresholdDeps) => async (props: CheckSensorThresholdProps) => {

        // Calculate danger status
        const dangerStatus = await CalculateSensorDangerStatus(
            deps.deviceSensorRepository,
            props.deviceId,
            props.sensorId,
            props.processValueNumber
        );


        // Update sensor_data danger status
        await deps.deviceSensorDataRepository.update({
            id: props.sensorDataId,
            entity: {
                dangerStatus: dangerStatus
            },
            userId: props.userId
        });

        // Update sensor danger status if needed
        const sensor = await deps.deviceSensorRepository.findBySensorId({
            parentId: props.deviceId,
            sensorId: props.sensorId
        });

        let sensorUpdated = false;
        if (sensor && sensor.danger_status !== dangerStatus) {
            await deps.deviceSensorRepository.update({
                id: sensor.id,
                parentId: sensor.device_id,
                entity: {
                    danger_status: dangerStatus
                },
                userId: props.userId
            });
            sensorUpdated = true;
        }

        return {
            dangerStatus,
            sensorUpdated,
            sensorDataUpdated: true
        };
    };
