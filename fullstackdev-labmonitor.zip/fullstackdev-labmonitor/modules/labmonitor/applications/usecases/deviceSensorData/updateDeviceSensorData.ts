import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { DeviceEnvEntity } from "../../../domains/entities/device_env.entity";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DeviceSensorDataResponseDTO, DeviceSensorDataUpdateDTO } from "../../dtos/device_sensor_data.dto";
import { ProcessSensorData, ProcessSensorNeedEnv } from "./proessDeviceSensorData";

interface UpdateDeviceSensorDataDeps {
    deviceRepository: IDeviceRepository
    deviceSensorDataRepository: IDeviceSensorDataRepository
    deviceEnvRepository: IDeviceEnvRepository
}

interface UpdateDeviceSensorDataProps {
    id: number
    dto: DeviceSensorDataUpdateDTO
    context: UsecaseContext
}


export const UpdateDeviceSensorData: TUsecase<UpdateDeviceSensorDataDeps, UpdateDeviceSensorDataProps, DeviceSensorDataResponseDTO> = (deps: UpdateDeviceSensorDataDeps) => async (props: UpdateDeviceSensorDataProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Write);
    const validated = await DeviceSensorDataUpdateDTO.parseAsync(props.dto);

    const existing = await deps.deviceSensorDataRepository.findById({ id: props.id });
    if (!existing) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device sensor data not found',
            code: 'custom'
        }]);
    }

    const deivce = await deps.deviceRepository.findByName({ name: existing.device_name })
    if (!deivce) {
        throw new BusinessValidationError([{
            path: ['device_name'],
            message: 'Device not found',
            code: 'custom'
        }]);
    }
    let envs: DeviceEnvEntity[] = []
    if (ProcessSensorNeedEnv[existing.sensor_type]) {
        envs = await deps.deviceEnvRepository.findAll({ parentId: deivce.id })
    }

    const processed = await ProcessSensorData({})({
        sensor_type: existing.sensor_type,
        raw_value: validated.raw_value!,
        envs: envs,
        sensor_id: existing.sensor_id
    })

    const result = await deps.deviceSensorDataRepository.update({
        id: props.id,
        entity: {
            ...validated,
            process_value_number: processed.process_value_number ?? undefined,
            process_value_text: processed.process_value_text ?? undefined,
            sensor_timestamp: validated.sensor_timestamp ? new Date(validated.sensor_timestamp) : undefined,
            raw_id: validated.raw_id ? validated.raw_id : undefined,
        },
        userId: guard.user?.id
    });


    return DeviceSensorDataResponseDTO.parse({
        ...result,
    });
}
