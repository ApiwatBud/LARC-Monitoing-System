import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DeviceSensorDataResponseDTO } from "../../dtos/device_sensor_data.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface DeleteDeviceSensorDataDeps {
    deviceSensorDataRepository: IDeviceSensorDataRepository
}

interface DeleteDeviceSensorDataProps {
    id: number
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const DeleteDeviceSensorData: TUsecase<DeleteDeviceSensorDataDeps, DeleteDeviceSensorDataProps, DeviceSensorDataResponseDTO> = (deps: DeleteDeviceSensorDataDeps) => async (props: DeleteDeviceSensorDataProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Delete);
    const existing = await deps.deviceSensorDataRepository.findById({ id: props.id });
    if (!existing) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device sensor data not found',
            code: 'custom'
        }]);
    }

    const result = await deps.deviceSensorDataRepository.delete({ id: props.id });

    return DeviceSensorDataResponseDTO.parse({
        ...result,
    });
}
