import * as XLSX from 'xlsx';
import z from "zod";
import { BusinessValidationError } from "../../../../../src/common/errors";
import { TPaginateQuery } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { DeviceSensorDataEntity } from "../../../domains/entities/device_sensor_data.entity";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";


interface DeviceSensorDataExcelExportDeps {
    deviceSensorDataRepository: IDeviceSensorDataRepository;
}
interface DeviceSensorDataExcelExportProps extends TPaginateQuery<DeviceSensorDataEntity> {
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const DeviceSensorDataExcelExport = (deps: DeviceSensorDataExcelExportDeps) => async (props: DeviceSensorDataExcelExportProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);

    const { data } = await deps.deviceSensorDataRepository.paginate({ query: props });

    //transform part
    const finalTransform = data
    //export part

    if (finalTransform.length === 0) {
        throw new BusinessValidationError([
            {
                code: "custom",
                message: "No data to export",
            }
        ] as z.core.$ZodSuperRefineIssue[]);
    }

    const ws = XLSX.utils.json_to_sheet(finalTransform);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' })

    return buffer
}