import { TPaginateQuery, TPaginateResult } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { DeviceSensorDataEntity } from "../../../domains/entities/device_sensor_data.entity";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DeviceSensorDataFilterDTO, DeviceSensorDataResponseDTO } from "../../dtos/device_sensor_data.dto";


interface LoadDeviceSensorDataDeps {
    deviceSensorDataRepository: IDeviceSensorDataRepository
}

interface LoadDeviceSensorDataProps {
    query: DeviceSensorDataFilterDTO
    context: UsecaseContext
}


export const LoadDeviceSensorData = (deps: LoadDeviceSensorDataDeps) => async (props: LoadDeviceSensorDataProps): Promise<DeviceSensorDataResponseDTO[]> => {
    const guard = createGuard(props.context);
    guard.ensure(['guest', LabmonitorPermissions.Read]);
    const result = await deps.deviceSensorDataRepository.loadData(props.query);

    return result.map(item => DeviceSensorDataResponseDTO.parse({
        ...item,
    }))
}
