import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IDeviceSensorDataRepository } from "../../../domains/repositories/device_sensor_data.repository";
import { DeviceSensorDataResponseDTO } from "../../dtos/device_sensor_data.dto";

interface GetDeviceSensorDataDeps {
    deviceSensorDataRepository: IDeviceSensorDataRepository
}

interface GetDeviceSensorDataProps {
    id: number
    context: UsecaseContext
}

import LabmonitorPermissions from "../../../domains/permissions";

export const GetDeviceSensorData: TUsecase<GetDeviceSensorDataDeps, GetDeviceSensorDataProps, DeviceSensorDataResponseDTO> = (deps: GetDeviceSensorDataDeps) => async (props: GetDeviceSensorDataProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const result = await deps.deviceSensorDataRepository.findById({ id: props.id });

    if (!result) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device sensor data not found',
            code: 'custom'
        }]);
    }

    return DeviceSensorDataResponseDTO.parse({
        ...result,
    });
}
