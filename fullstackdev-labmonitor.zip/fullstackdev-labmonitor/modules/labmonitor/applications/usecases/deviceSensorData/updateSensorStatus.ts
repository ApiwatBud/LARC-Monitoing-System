import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { DEVICE_DANGER_STATUS } from "../../../domains/valueObject";
import { AnyTransaction } from "../../../../../src/common/persistents/types";

interface UpdateSensorStatusProps {
    deviceSensorRepository: IDeviceSensorRepository;
    deviceId: number;
    sensorId: string;
    dangerStatus: DEVICE_DANGER_STATUS;
    userId?: number;
    transaction?: AnyTransaction;
    sensor?: DeviceSensorEntity; // Optional: pass existing sensor to avoid query
}

/**
 * Update sensor danger_status if it has changed
 * Returns true if sensor was updated, false otherwise
 * 
 * Performance tip: Pass sensor entity if already available to avoid extra query
 */
export const UpdateSensorStatus = async (props: UpdateSensorStatusProps): Promise<boolean> => {
    const { deviceSensorRepository, deviceId, sensorId, dangerStatus, userId, transaction } = props;

    // Use provided sensor or fetch it
    let sensor = props.sensor;
    if (!sensor) {
        const fetchedSensor = await deviceSensorRepository.findBySensorId({
            parentId: deviceId,
            sensorId: sensorId,
            transaction
        });
        sensor = fetchedSensor ?? undefined;
    }

    // If sensor not found or status hasn't changed, no update needed
    if (!sensor || sensor.danger_status === dangerStatus) {
        return false;
    }

    // Update sensor status
    await deviceSensorRepository.update({
        id: sensor.id,
        parentId: deviceId,
        entity: {
            danger_status: dangerStatus
        },
        userId,
        transaction
    });

    return true;
};
