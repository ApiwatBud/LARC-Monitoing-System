import { DEVICE_DANGER_STATUS } from "../../../domains/valueObject";
import { IEmailRateLimitRepository } from "../../../domains/repositories/email_rate_limit.repository";

interface CheckEmailRateLimitDeps {
    emailRateLimitRepository: IEmailRateLimitRepository;
}

interface CheckEmailRateLimitProps {
    deviceId: number;
    currentStatus: string; // 'WARNING' or 'NORMAL'
    warningFingerprint?: string;
    /** Escalation stages in minutes. Interval used = stages[min(sentCount-1, stages.length-1)] */
    rateLimitStagesMinutes?: number[];
    sendOnFirstWarning?: boolean;
    resetOnSensorChange?: boolean;
    clearOnNormal?: boolean;
}

interface CheckEmailRateLimitResult {
    shouldSend: boolean;
    reason: string;
    nextAllowedAt?: Date;
}

/**
 * Check if email should be sent based on rate limiting rules using database storage:
 * 1. First time status changes to WARNING: Send immediately
 * 2. Status still WARNING: Send every interval from escalation stages (default 30 minutes)
 * 3. Warning fingerprint changed: Send immediately (reset rate limit)
 * 4. Status changes to NORMAL: Clear rate limit
 */
export const CheckEmailRateLimit = (deps: CheckEmailRateLimitDeps) =>
    async (props: CheckEmailRateLimitProps): Promise<CheckEmailRateLimitResult> => {

        const { deviceId, currentStatus, warningFingerprint, rateLimitStagesMinutes = [30], sendOnFirstWarning = true, resetOnSensorChange = true, clearOnNormal = true } = props;
        const { emailRateLimitRepository } = deps;

        const now = new Date();

        // If status is NORMAL, clear rate limit and don't send
        if (currentStatus !== DEVICE_DANGER_STATUS.WARNING) {
            if (clearOnNormal) {
                await emailRateLimitRepository.deleteByDeviceId({ deviceId });
            }
            return {
                shouldSend: false,
                reason: `Device status is ${currentStatus}`
            };
        }

        const state = await emailRateLimitRepository.findByDeviceId({ deviceId });

        // If no previous state, this is first warning
        if (!state) {
            await emailRateLimitRepository.upsert({
                entity: {
                    device_id: deviceId,
                    last_sent_at: now,
                    sent_count: sendOnFirstWarning ? 1 : 0,
                    warning_fingerprint: warningFingerprint
                }
            });
            if (!sendOnFirstWarning) {
                return {
                    shouldSend: false,
                    reason: 'First warning - rate limit cooldown started'
                };
            }
            return {
                shouldSend: true,
                reason: 'First warning alert'
            };
        }

        // Check if warning fingerprint changed (new sensors added or removed)
        if (warningFingerprint && state.warning_fingerprint !== warningFingerprint) {
            await emailRateLimitRepository.upsert({
                entity: {
                    device_id: deviceId,
                    last_sent_at: now,
                    sent_count: state.sent_count + 1,
                    warning_fingerprint: warningFingerprint
                }
            });
            if (!resetOnSensorChange) {
                return {
                    shouldSend: false,
                    reason: 'Warning sensors changed - cooldown restarted'
                };
            }
            return {
                shouldSend: true,
                reason: 'Warning sensors changed - resetting rate limit'
            };
        }

        // Check if interval has passed since last email, using escalation stage
        const lastSentAtTime = state.last_sent_at instanceof Date ? state.last_sent_at.getTime() : new Date(state.last_sent_at).getTime();
        const minutesSinceLastSent = (now.getTime() - lastSentAtTime) / (1000 * 60);

        // Escalation: pick interval based on how many alerts already sent in this episode
        // sent_count=1 -> stage[0], sent_count=2 -> stage[1], ... capped at last stage
        const stageIndex = Math.min(Math.max(state.sent_count - 1, 0), rateLimitStagesMinutes.length - 1);
        const currentRateLimitMinutes = rateLimitStagesMinutes[stageIndex] ?? rateLimitStagesMinutes[rateLimitStagesMinutes.length - 1] ?? 30;

        if (minutesSinceLastSent >= currentRateLimitMinutes) {
            await emailRateLimitRepository.upsert({
                entity: {
                    device_id: deviceId,
                    last_sent_at: now,
                    sent_count: state.sent_count + 1,
                    warning_fingerprint: warningFingerprint
                }
            });
            return {
                shouldSend: true,
                reason: `Rate limit passed (${Math.floor(minutesSinceLastSent)} minutes since last email)`
            };
        }

        // Rate limit not passed yet
        const nextAllowedAt = new Date(lastSentAtTime + (currentRateLimitMinutes * 60 * 1000));
        return {
            shouldSend: false,
            reason: `Rate limit active (${Math.floor(currentRateLimitMinutes - minutesSinceLastSent)} minutes remaining)`,
            nextAllowedAt
        };
    };
