import { TUsecase } from "../../../../../src/common/types";
import { EmailAlertLogEntity } from "../../../domains/entities/email_alert_log.entity";
import { IEmailAlertLogRepository } from "../../../domains/repositories/email_alert_log.repository";
import { TPaginateQuery, TPaginateResult } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";

interface PaginateEmailAlertLogDeps {
    emailAlertLogRepository: IEmailAlertLogRepository;
}

interface PaginateEmailAlertLogProps extends TPaginateQuery<EmailAlertLogEntity> {
    context: UsecaseContext;
}

import LabmonitorPermissions from "../../../domains/permissions";

export const PaginateEmailAlertLog: TUsecase<PaginateEmailAlertLogDeps, PaginateEmailAlertLogProps, TPaginateResult<EmailAlertLogEntity>>
    = (deps) => async (props) => {
        const guard = createGuard(props.context);
        guard.ensure(LabmonitorPermissions.Read);
        return await deps.emailAlertLogRepository.paginate({ query: props });
    };
