import { IEmailAlertLogRepository } from "../../../domains/repositories/email_alert_log.repository";
import { AnyPgTransaction } from "../../../../../src/common/persistents/types";

interface CreateEmailAlertLogDeps {
    emailAlertLogRepository: IEmailAlertLogRepository;
}

interface CreateEmailAlertLogProps {
    device_id: number;
    device_name: string;
    alert_type: string;
    recipients: string;
    subject: string;
    content?: string;
    message_id?: string;
    transaction?: AnyPgTransaction;
}

/**
 * Log an email alert event
 * Stores full details of the sent email for history tracking
 */
export const CreateEmailAlertLog = (deps: CreateEmailAlertLogDeps) =>
    async (props: CreateEmailAlertLogProps): Promise<void> => {
        await deps.emailAlertLogRepository.logAlert(props);
    };
