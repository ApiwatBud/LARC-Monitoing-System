import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DeviceEntity } from "../../../domains/entities/device.entity";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { CreateEmailAlertLog } from "../emailAlertLogs/createEmailAlertLog";
import { SendEmail } from "../../../../../src/modules/config/applications/usecases/email/sendEmail";
import { IConfigRepository } from "../../../../../src/modules/config/domains/repositories/config.repository";
import { GetEmailAlertConfig } from "../emailAlertConfig/getEmailAlertConfig";

interface SendDeviceAlertEmailDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository;
    deviceRepository: IDeviceRepository;
    deviceSensorRepository: IDeviceSensorRepository;
    configRepository: IConfigRepository;
    createEmailAlertLog: ReturnType<typeof CreateEmailAlertLog>;
}

interface SendDeviceAlertEmailProps {
    device: DeviceEntity;
    warningSensors: DeviceSensorEntity[];
}

interface SendDeviceAlertEmailResult {
    emailsSent: number;
    recipients: string[];
    success?: boolean;
    error?: string;
}

/**
 * Send email alert for device with warning sensors
 * Includes device status summary and warning sensor details
 */
export const SendDeviceAlertEmail = (deps: SendDeviceAlertEmailDeps) =>
    async (props: SendDeviceAlertEmailProps): Promise<SendDeviceAlertEmailResult> => {

        const { device, warningSensors } = props;

        // Get all email alert settings
        const emailSettings = await deps.emailAlertSettingRepository.findAll({});

        if (emailSettings.length === 0) {
            return {
                emailsSent: 0,
                recipients: []
            };
        }

        // Prepare email content
        const subject = `⚠️ Lab Monitor Alert: ${device.name} - Warning Status`;

        const sensorDetails = warningSensors.map(sensor => {
            const issues = [];
            if (sensor.normalMin !== undefined && sensor.normalMin !== null) issues.push(`Min: ${sensor.normalMin}`);
            if (sensor.normalMax !== undefined && sensor.normalMax !== null) issues.push(`Max: ${sensor.normalMax}`);

            return `
        • Sensor: ${sensor.sensor_id}
          Type: ${sensor.sensor_type}
          Status: ${sensor.danger_status}
          ${issues.length > 0 ? `Threshold: ${issues.join(', ')}` : 'No threshold configured'}
        `;
        }).join('\n');

        const emailBody = `
Lab Monitor Alert
═══════════════════════════════════════

Device: ${device.name}
Status: ⚠️ WARNING
Connection: ${device.connection_status}
Last Seen: ${device.last_seen ? new Date(device.last_seen).toLocaleString('th-TH') : 'Never'}

Warning Sensors (${warningSensors.length}):
${sensorDetails}

═══════════════════════════════════════
Please check the device and sensors immediately.

This is an automated alert from Lab Monitor System.
Time: ${new Date().toLocaleString('th-TH')}
    `.trim();

        // Send emails to all recipients
        const recipients = emailSettings.map(s => s.recipientEmail);

        try {
            const emailAlertConfig = await GetEmailAlertConfig({ configRepository: deps.configRepository })({ context: { user: null, permissions: [] }, skipGuard: true });
            const sendEmail = SendEmail({ configRepository: deps.configRepository });
            const result = await sendEmail({
                to: recipients,
                subject: subject,
                text: emailBody,
                fromName: emailAlertConfig.fromName
            });

            console.log(`✅ Device alert email sent successfully to ${recipients.length} recipients`);

            // Log after successful sending
            await deps.createEmailAlertLog({
                device_id: device.id,
                device_name: device.name,
                alert_type: 'device_warning',
                recipients: recipients.join(', '),
                subject: subject,
                content: emailBody,
                message_id: result.messageId
            });

            return {
                emailsSent: recipients.length,
                recipients,
                success: true
            };
        } catch (error: any) {
            console.error(`❌ Failed to send device alert email:`, error);
            return {
                emailsSent: 0,
                recipients,
                success: false,
                error: error.message
            };
        }
    };
