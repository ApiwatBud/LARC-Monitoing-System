import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DeviceEntity } from "../../../domains/entities/device.entity";
import { DeviceSensorEntity } from "../../../domains/entities/device_sensor.entity";
import { IConfigRepository } from "../../../../../src/modules/config/domains/repositories/config.repository";
import { SendEmail } from "../../../../../src/modules/config/applications/usecases/email/sendEmail";
import { CreateEmailAlertLog } from "../emailAlertLogs/createEmailAlertLog";
import { GetEmailAlertConfig } from "../emailAlertConfig/getEmailAlertConfig";

interface SendDeviceSummaryAlertEmailDeps {
    emailAlertSettingRepository: IEmailAlertSettingRepository;
    deviceRepository: IDeviceRepository;
    deviceSensorRepository: IDeviceSensorRepository;
    configRepository: IConfigRepository;
    createEmailAlertLog: ReturnType<typeof CreateEmailAlertLog>;
}

interface SendDeviceSummaryAlertEmailProps {
    warningDevices: Array<{
        device: DeviceEntity;
        warningSensors: DeviceSensorEntity[];
    }>;
}

interface SendDeviceSummaryAlertEmailResult {
    emailsSent: number;
    recipients: string[];
    success?: boolean;
    error?: string;
    messageId?: string;
}

/**
 * Send summary email alert for all devices with warnings
 * Format: Table summary of all warning devices and their sensors
 */
export const SendDeviceSummaryAlertEmail = (deps: SendDeviceSummaryAlertEmailDeps) =>
    async (props: SendDeviceSummaryAlertEmailProps): Promise<SendDeviceSummaryAlertEmailResult> => {

        const { warningDevices } = props;

        // Get all email alert settings
        const emailSettings = await deps.emailAlertSettingRepository.findAll({});

        if (emailSettings.length === 0) {
            console.log('⚠️  No email recipients configured');
            return {
                emailsSent: 0,
                recipients: []
            };
        }

        // Calculate totals
        const totalDevices = warningDevices.length;
        const totalWarningSensors = warningDevices.reduce((sum, d) => sum + d.warningSensors.length, 0);

        // Prepare email subject
        const subject = `⚠️ Lab Monitor Alert: ${totalDevices} Device${totalDevices > 1 ? 's' : ''} Warning`;

        // Build table rows
        const tableRows = warningDevices.map(({ device, warningSensors }) => {
            const sensorSummary = warningSensors.map(s => {
                const threshold = [];
                if (s.normalMin !== undefined && s.normalMin !== null) threshold.push(`Min:${s.normalMin}`);
                if (s.normalMax !== undefined && s.normalMax !== null) threshold.push(`Max:${s.normalMax}`);
                return `${s.sensor_id} (${threshold.join(', ')})`;
            }).join(', ');

            const lastSeen = device.last_seen ? new Date(device.last_seen).toLocaleString('th-TH') : 'Never';

            return `| ${device.name.padEnd(20)} | ${warningSensors.length.toString().padEnd(8)} | ${device.connection_status.padEnd(12)} | ${lastSeen.padEnd(16)} | ${sensorSummary.substring(0, 40).padEnd(40)} |`;
        }).join('\n');

        // Build HTML
        const htmlRows = warningDevices.map(({ device, warningSensors }) => {
            const lastSeen = device.last_seen ? new Date(device.last_seen).toLocaleString('th-TH') : 'Never';
            const sensorList = warningSensors.map(s => `<li>${s.sensor_id}</li>`).join('');
            return `
                <tr>
                    <td style="border: 1px solid #ddd; padding: 8px;">${device.name}</td>
                    <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">${warningSensors.length}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${device.connection_status}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">${lastSeen}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;"><ul>${sensorList}</ul></td>
                </tr>
            `;
        }).join('');

        const htmlBody = `
            <div style="font-family: sans-serif; max-width: 800px; margin: 0 auto; color: #333;">
                <div style="background-color: #d9534f; color: white; padding: 20px; border-radius: 5px 5px 0 0;">
                    <h1 style="margin: 0;">LAB MONITOR SYSTEM ALERT</h1>
                </div>
                <div style="padding: 20px; border: 1px solid #ddd; border-top: none;">
                    <h2 style="color: #d9534f;">⚠️ SYSTEM STATUS: WARNING</h2>
                    <p><strong>Summary:</strong></p>
                    <ul>
                        <li>Warning Devices: ${totalDevices}</li>
                        <li>Total Warning Sensors: ${totalWarningSensors}</li>
                        <li>Alert Time: ${new Date().toLocaleString('th-TH')}</li>
                    </ul>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background-color: #f2f2f2;">
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Device Name</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Warnings</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Connection</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Last Seen</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Warning Sensors</th>
                            </tr>
                        </thead>
                        <tbody>${htmlRows}</tbody>
                    </table>
                </div>
            </div>
        `;

        const emailBody = `
Lab Monitor System Alert
══════════════════════════════════════════════════════════════
⚠️ SYSTEM STATUS: WARNING
📊 SUMMARY:
   • Warning Devices: ${totalDevices}
   • Total Warning Sensors: ${totalWarningSensors}
   • Alert Time: ${new Date().toLocaleString('th-TH')}
${tableRows}
        `.trim();

        const recipients = emailSettings.map(s => s.recipientEmail);

        try {
            const emailAlertConfig = await GetEmailAlertConfig({ configRepository: deps.configRepository })({ context: { user: null, permissions: [] }, skipGuard: true });
            const sendEmail = SendEmail({ configRepository: deps.configRepository });
            const result = await sendEmail({
                to: recipients,
                subject: subject,
                text: emailBody,
                html: htmlBody,
                fromName: emailAlertConfig.fromName
            });

            console.log(`✅ Summary email alert sent successfully to ${recipients.length} recipients`);

            // Log for EACH device in summary, but only AFTER success
            for (const wd of warningDevices) {
                await deps.createEmailAlertLog({
                    device_id: wd.device.id,
                    device_name: wd.device.name,
                    alert_type: 'summary_warning',
                    recipients: recipients.join(', '),
                    subject: subject,
                    content: emailBody, // Or summary content
                    message_id: result.messageId
                });
            }

            return {
                emailsSent: recipients.length,
                recipients,
                success: true,
                messageId: result.messageId
            };
        } catch (error: any) {
            console.error(`❌ Failed to send summary email alert:`, error);
            return {
                emailsSent: 0,
                recipients,
                success: false,
                error: error.message
            };
        }
    };
