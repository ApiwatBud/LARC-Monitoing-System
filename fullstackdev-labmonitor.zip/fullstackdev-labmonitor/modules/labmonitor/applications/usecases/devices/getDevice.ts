import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DeviceAggsResponseDTO } from "../../dtos/device.dto.aggs";

interface GetDeviceDeps {
    deviceRepository: IDeviceRepository
    deviceEnvRepository: IDeviceEnvRepository,
    deviceSensorRepository: IDeviceSensorRepository
}

interface GetDeviceProps {
    id: number
    context: UsecaseContext
}


export const GetDevice: TUsecase<GetDeviceDeps, GetDeviceProps, DeviceAggsResponseDTO> = (deps: GetDeviceDeps) => async (props: GetDeviceProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const device = await deps.deviceRepository.findById({ id: props.id });
    const deviceEnv = await deps.deviceEnvRepository.findAll({ parentId: props.id });
    const deviceSensor = await deps.deviceSensorRepository.findAll({ parentId: props.id });
    if (!device) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device not found',
            code: 'custom'
        }]);
    }

    return DeviceAggsResponseDTO.parse({ ...device, device_envs: deviceEnv, device_sensors: deviceSensor });
}
