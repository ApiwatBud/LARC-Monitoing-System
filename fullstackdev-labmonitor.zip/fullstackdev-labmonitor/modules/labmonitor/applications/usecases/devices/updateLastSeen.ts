import { IDeviceRepository } from "../../../domains/repositories/device.repository"
import { DEVICE_CONNECTION_STATUS, DEVICE_STATUS } from "../../../domains/valueObject"

interface deps {
    deviceRepository: IDeviceRepository
}

interface props {
    device_id: number,
    userId?: number
}

export const UpdateLastSeenUseCase = (deps: deps) =>
    async (props: props) => {
        try {


            const device = await deps.deviceRepository.findById({
                id: props.device_id
            })
            if (!device) {
                throw new Error('Device not found')
            }
            await deps.deviceRepository.update({
                id: device.id,
                entity: {
                    last_seen: new Date(),
                    connection_status: DEVICE_CONNECTION_STATUS.ONLINE
                },
                userId: props.userId
            })
        } catch (error) {
            console.error(error)
        }
    }