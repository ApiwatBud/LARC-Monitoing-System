import { BusinessValidationError } from "../../../../../src/common/errors";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { DeviceResponseDTO } from "../../dtos/device.dto";

interface DeleteDeviceDeps {
    deviceRepository: IDeviceRepository
}

interface DeleteDeviceProps {
    id: number
    context: UsecaseContext
}

export const DeleteDevice: TUsecase<DeleteDeviceDeps, DeleteDeviceProps, DeviceResponseDTO> = (deps: DeleteDeviceDeps) => async (props: DeleteDeviceProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Delete);
    const existingDevice = await deps.deviceRepository.findById({ id: props.id });
    if (!existingDevice) {
        throw new BusinessValidationError([{
            path: ['id'],
            message: 'Device not found',
            code: 'custom'
        }]);
    }

    const device = await deps.deviceRepository.delete({ id: props.id });

    return DeviceResponseDTO.parse(device);
}
