import { TUsecase } from "../../../../../src/common/types";
import { DeviceSensorResponseDTO } from "../../dtos/device_sensor.dto";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";

interface deps {
    deviceRepository: IDeviceRepository
    deviceSensorRepository: IDeviceSensorRepository
}

interface props {
    name: string
    context: UsecaseContext
}

export const GetDeviceSensorByDeviceName: TUsecase<deps, props, DeviceSensorResponseDTO[]> = ({ deviceRepository, deviceSensorRepository }: deps) => {
    return async (props: props) => {
        const { name, context } = props;
        const guard = createGuard(context);
        guard.ensure(LabmonitorPermissions.Read);


        return deviceRepository.transaction(async (tx) => {
            let device = await deviceRepository.findByName({ name, transaction: tx })
            if (!device) return []
            let data = await deviceSensorRepository.findAll({ parentId: device.id, transaction: tx });
            return data.map((item) => {
                return DeviceSensorResponseDTO.parse({
                    ...item,
                    createdAt: item.createdAt,
                    updatedAt: item.updatedAt,
                    deletedAt: item.deletedAt,
                    createdBy: item.createdBy,
                    updatedBy: item.updatedBy,
                })
            })
        })
    }
}