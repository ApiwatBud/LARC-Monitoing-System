import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { DeviceResponseDTO } from "../../dtos/device.dto";
import { DeviceAggsResponseDTO, DeviceDtoWithLatestSensorData } from "../../dtos/device.dto.aggs";

interface GetDeviceWithLatestDataDeps {
    deviceRepository: IDeviceRepository
}

interface GetDeviceWithLatestDataProps {
    context: UsecaseContext
}

export const GetDeviceWithLatestData: TUsecase<GetDeviceWithLatestDataDeps, GetDeviceWithLatestDataProps, DeviceAggsResponseDTO[]> = (deps: GetDeviceWithLatestDataDeps) => async (props: GetDeviceWithLatestDataProps) => {
    const guard = createGuard(props.context);
    guard.ensure(['guest', LabmonitorPermissions.Read]);
    const devices = await deps.deviceRepository.getWithLatestData();
    return devices.map((d: any) => (DeviceDtoWithLatestSensorData.parse({
        ...d,
        device_sensors: d.sensors || [],
        device_envs: d.envs || [],
        latest_sensor_data: d.latest_sensor_data || [],
    })));
}
