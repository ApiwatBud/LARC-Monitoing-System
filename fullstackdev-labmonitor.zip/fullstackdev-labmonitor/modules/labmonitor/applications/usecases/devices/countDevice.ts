import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { DEVICE_CONNECTION_STATUS } from "../../../domains/valueObject";
import { DeviceCountResponseDTO } from "../../dtos/device.dto";

interface CountDeviceDeps {
    deviceRepository: IDeviceRepository
}

interface CountDeviceProps {
    context: UsecaseContext
}

export const CountDevice: TUsecase<CountDeviceDeps, CountDeviceProps, DeviceCountResponseDTO> = (deps: CountDeviceDeps) => async (props: CountDeviceProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);

    const devices = await deps.deviceRepository.findAll();

    const total = devices.length;
    const online = devices.filter(d => d.connection_status === DEVICE_CONNECTION_STATUS.ONLINE).length;

    return DeviceCountResponseDTO.parse({
        total,
        online
    });
}
