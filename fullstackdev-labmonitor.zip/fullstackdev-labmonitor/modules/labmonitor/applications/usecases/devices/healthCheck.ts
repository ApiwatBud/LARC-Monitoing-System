import { IDeviceRepository } from "../../../domains/repositories/device.repository"
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository"
import { IEmailAlertSettingRepository } from "../../../domains/repositories/email_alert_setting.repository"
import { DEVICE_DANGER_STATUS } from "../../../domains/valueObject"
import { SendDeviceSummaryAlertEmail } from "../emailAlerts/sendDeviceSummaryAlertEmail"
import { CheckEmailRateLimit } from "../emailRateLimits/checkEmailRateLimit"
import { IConfigRepository } from "../../../../../src/modules/config/domains/repositories/config.repository"
import { GetEmailAlertConfig } from "../emailAlertConfig/getEmailAlertConfig"
import { RATE_LIMIT_MINUTES_MAP } from "../../dtos/email_alert_config.dto"
import { IEmailRateLimitRepository } from "../../../domains/repositories/email_rate_limit.repository"
import { IEmailAlertLogRepository } from "../../../domains/repositories/email_alert_log.repository"
import { CreateEmailAlertLog } from "../emailAlertLogs/createEmailAlertLog"

interface HealthCheckDeps {
    deviceRepository: IDeviceRepository
    deviceSensorRepository: IDeviceSensorRepository
    emailAlertSettingRepository: IEmailAlertSettingRepository
    configRepository: IConfigRepository
    emailRateLimitRepository: IEmailRateLimitRepository
    emailAlertLogRepository: IEmailAlertLogRepository
}

interface HealthCheckProps {
    minutes: number;
    bypassRateLimit?: boolean;
}

interface HealthCheckResult {
    connectionChecked: number;
    devicesChecked: number;
    devicesUpdated: number;
    emailsSent: number;
    emailsSkipped: number;
}

/**
 * Health Check Use Case
 * 1. Check device connection status (last_seen)
 * 2. Check device danger status based on sensors
 * 3. Send summary email alert if any device has WARNING status (with rate limiting)
 */
export const HealthCheck = ({
    deviceRepository,
    deviceSensorRepository,
    emailAlertSettingRepository,
    configRepository,
    emailRateLimitRepository,
    emailAlertLogRepository
}: HealthCheckDeps) => {
    return async ({ minutes, bypassRateLimit }: HealthCheckProps): Promise<HealthCheckResult> => {

        const createEmailAlertLog = CreateEmailAlertLog({ emailAlertLogRepository });

        const emailAlertConfig = await GetEmailAlertConfig({ configRepository })({ context: { user: null, permissions: [] as any }, skipGuard: true });
        const rateLimitStagesMinutes = emailAlertConfig.rateLimitStages.map(s => s.value * (RATE_LIMIT_MINUTES_MAP[s.unit] ?? 1));

        // 1. Check connection status (existing logic)
        const connectionResult = await deviceRepository.healthCheck({ minutes });

        // 2. Check all devices' sensor statuses
        const devices = await deviceRepository.findAll({});
        let devicesUpdated = 0;
        let emailsSent = 0;
        let emailsSkipped = 0;

        // Collect all warning devices
        const warningDevices: Array<{
            device: any;
            warningSensors: any[];
        }> = [];

        for (const device of devices) {
            // Skip deleted devices
            if (device.deletedAt) continue;

            // Get all sensors for this device
            const sensors = await deviceSensorRepository.findAll({ parentId: device.id });

            // Get warning/danger sensors
            const warningSensors = sensors.filter(s =>
                s.danger_status === DEVICE_DANGER_STATUS.WARNING ||
                s.danger_status === DEVICE_DANGER_STATUS.DANGER
            );
            const dangerSensors = sensors.filter(s => s.danger_status === DEVICE_DANGER_STATUS.DANGER);

            // Determine device danger status: DANGER if any sensor is danger, else WARNING if any warning
            const newDangerStatus = dangerSensors.length > 0
                ? DEVICE_DANGER_STATUS.DANGER
                : warningSensors.length > 0
                    ? DEVICE_DANGER_STATUS.WARNING
                    : DEVICE_DANGER_STATUS.NORMAL;

            // Update if status changed
            if (device.danger_status !== newDangerStatus) {
                await deviceRepository.update({
                    id: device.id,
                    entity: {
                        danger_status: newDangerStatus
                    }
                });
                devicesUpdated++;
                console.log(`🔄 Device "${device.name}" status changed: ${device.danger_status} → ${newDangerStatus}`);
            }

            // Collect warning devices (respecting minLevel from config)
            const minLevel = emailAlertConfig.minLevel;
            const passesMinLevel = newDangerStatus === DEVICE_DANGER_STATUS.DANGER || (minLevel === 'warning' && newDangerStatus === DEVICE_DANGER_STATUS.WARNING);

            if (passesMinLevel && warningSensors.length > 0) {
                warningDevices.push({
                    device,
                    warningSensors: minLevel === 'danger' ? dangerSensors : warningSensors
                });
            } else if (newDangerStatus === DEVICE_DANGER_STATUS.NORMAL) {
                console.log(`ℹ️  Device "${device.name}" is NORMAL (${sensors.length} sensors, 0 warnings)`);
            }
        }


        // 3. Send summary email if there are any warning devices
        if (warningDevices.length > 0) {
            // Check if email alerts are enabled via config
            if (!emailAlertConfig.enable) {
                console.log(`⏭️  Email alerts are disabled by config, skipping ${warningDevices.length} warning device(s)`);
            } else {
                // Build fingerprint of warning sensors to detect changes
                const warningFingerprint = warningDevices
                    .map(wd => `${wd.device.id}:${wd.warningSensors.map(s => s.sensor_id).sort().join(',')}`)
                    .sort()
                    .join('|');

                // Use first device ID for rate limiting (or could use a global key)
                const rateLimitCheck = await CheckEmailRateLimit({ emailRateLimitRepository })({
                    deviceId: 0, // Use 0 for system-wide summary
                    currentStatus: DEVICE_DANGER_STATUS.WARNING,
                    warningFingerprint,
                    rateLimitStagesMinutes,
                    sendOnFirstWarning: emailAlertConfig.sendOnFirstWarning,
                    resetOnSensorChange: emailAlertConfig.resetOnSensorChange,
                    clearOnNormal: emailAlertConfig.clearOnNormal
                });

                const shouldSend = bypassRateLimit || rateLimitCheck.shouldSend;
                const reason = bypassRateLimit ? 'Manual bypass' : rateLimitCheck.reason;

                if (shouldSend) {
                    // Send summary email for all warning devices
                    const emailResult = await SendDeviceSummaryAlertEmail({
                        emailAlertSettingRepository,
                        deviceRepository,
                        deviceSensorRepository,
                        configRepository,
                        createEmailAlertLog
                    })({
                        warningDevices
                    });

                    emailsSent += emailResult.emailsSent;

                    console.log(`✅ Summary email alert sent for ${warningDevices.length} warning devices: ${reason}`);

                    // If we bypassed rate limit, we should still update the rate limit state
                    // so that the next regular check knows we just sent one.
                    if (bypassRateLimit && !rateLimitCheck.shouldSend) {
                        await emailRateLimitRepository.upsert({
                            entity: {
                                device_id: 0,
                                last_sent_at: new Date(),
                                sent_count: 1, // Or increment if we want to be precise, but 1 is fine for reset
                                warning_fingerprint: warningFingerprint
                            }
                        });
                    }
                } else {
                    emailsSkipped++;
                    console.log(`⏭️  Summary email alert skipped for ${warningDevices.length} warning devices: ${reason}`);
                }
            }
        } else {
            // Clear rate limit when no warnings
            await CheckEmailRateLimit({ emailRateLimitRepository })({
                deviceId: 0,
                currentStatus: DEVICE_DANGER_STATUS.NORMAL,
                clearOnNormal: emailAlertConfig.clearOnNormal
            });
            console.log(`ℹ️  No warning devices - all systems normal`);
        }

        return {
            connectionChecked: typeof connectionResult === 'number' ? connectionResult : 0,
            devicesChecked: devices.length,
            devicesUpdated,
            emailsSent,
            emailsSkipped
        };
    }
}