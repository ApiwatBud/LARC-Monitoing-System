import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { DeviceResponseDTO } from "../../dtos/device.dto";
import { DeviceAggsResponseDTO } from "../../dtos/device.dto.aggs";

interface GetAllDevicesDeps {
    deviceRepository: IDeviceRepository
}

interface GetAllDevicesProps {
    context: UsecaseContext
}

export const GetAllDevices: TUsecase<GetAllDevicesDeps, GetAllDevicesProps, DeviceAggsResponseDTO[]> = (deps: GetAllDevicesDeps) => async (props: GetAllDevicesProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);
    const devices = await deps.deviceRepository.findAllWithAggs();
    return devices.map((d: any) => (DeviceAggsResponseDTO.parse({
        ...d,
        device_sensors: d.sensors || [],
        device_envs: d.envs || [],
    })));
}
