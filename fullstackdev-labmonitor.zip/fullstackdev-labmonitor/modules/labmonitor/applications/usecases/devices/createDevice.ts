import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DEVICE_METADATA_TYPE } from "../../../domains/valueObject";
import { DeviceAggsCreateDTO, DeviceAggsResponseDTO } from "../../dtos/device.dto.aggs";

interface CreateDeviceDeps {
    deviceRepository: IDeviceRepository
    deviceEnvRepository: IDeviceEnvRepository
    deviceSensorRepository: IDeviceSensorRepository
}

interface CreateDeviceProps {
    dto: DeviceAggsCreateDTO
    context: UsecaseContext
}

export const CreateDevice: TUsecase<CreateDeviceDeps, CreateDeviceProps, DeviceAggsResponseDTO> = (deps: CreateDeviceDeps) => async (props: CreateDeviceProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Write);

    const validated = await DeviceAggsCreateDTO.parseAsync(props.dto);

    return deps.deviceRepository.transaction(async (tx) => {
        const device = await deps.deviceRepository.create({
            entity: {
                name: validated.name as any,
                description: (validated.description ?? null) as any,
                connection_status: validated.connection_status as any,
                danger_status: validated.danger_status as any,
                status: validated.status as any,
                last_seen: (validated.last_seen ?? null) as any,
                raw_id: (validated.raw_id ?? null) as any,
                token: (validated.token ?? null) as any,
            },
            userId: guard.user?.id,
            transaction: tx
        });

        const createdEnvs = [];
        if (validated.device_envs) {
            for (const env of validated.device_envs) {
                const createdEnv = await deps.deviceEnvRepository.create({
                    parentId: device.id,
                    entity: {
                        device_id: device.id,
                        key: env.key,
                        type: env.type as DEVICE_METADATA_TYPE,
                        value: env.value
                    },
                    transaction: tx,
                    userId: guard.user?.id
                });
                createdEnvs.push(createdEnv);
            }
        }

        const createdSensors = [];
        if (validated.device_sensors) {
            for (const sensor of validated.device_sensors) {
                const createdSensor = await deps.deviceSensorRepository.create({
                    parentId: device.id,
                    entity: {
                        device_id: device.id,
                        sensor_id: sensor.sensor_id,
                        sensor_type: sensor.sensor_type,
                        danger_status: sensor.danger_status,
                        normalMin: sensor.normalMin ?? undefined,
                        normalMax: sensor.normalMax ?? undefined,
                        dangerMin: sensor.dangerMin ?? undefined,
                        dangerMax: sensor.dangerMax ?? undefined,
                    },
                    transaction: tx,
                    userId: guard.user?.id
                });
                createdSensors.push(createdSensor);
            }
        }

        return DeviceAggsResponseDTO.parse({
            ...device,
            device_envs: createdEnvs,
            device_sensors: createdSensors
        });
    });
}
