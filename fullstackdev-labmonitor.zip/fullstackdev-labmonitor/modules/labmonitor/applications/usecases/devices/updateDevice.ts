import z from "zod";
import { BusinessValidationError } from "../../../../../src/common/errors";
import { AnyPgTransaction } from "../../../../../src/common/persistents/types";
import { TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";
import { IDeviceEnvRepository } from "../../../domains/repositories/device_env.repository";
import { IDeviceSensorRepository } from "../../../domains/repositories/device_sensor.repository";
import { DEVICE_METADATA_TYPE } from "../../../domains/valueObject";
import { DeviceAggsResponseDTO, DeviceAggsUpdateDTO } from "../../dtos/device.dto.aggs";

interface UpdateDeviceDeps {
    deviceRepository: IDeviceRepository
    deviceEnvRepository: IDeviceEnvRepository
    deviceSensorRepository: IDeviceSensorRepository
}

interface UpdateDeviceProps {
    id: number
    dto: DeviceAggsUpdateDTO
    context: UsecaseContext
}

export const UpdateDevice: TUsecase<UpdateDeviceDeps, UpdateDeviceProps, DeviceAggsResponseDTO> = (deps: UpdateDeviceDeps) => async (props: UpdateDeviceProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Update);

    const syncDeviceEnvs = async (deviceId: number, envs: DeviceAggsUpdateDTO['device_envs'], transaction?: AnyPgTransaction) => {

        if (envs) {
            const envIds = new Set<string>();
            for (const env of envs) {
                if (envIds.has(env.key)) {
                    return new BusinessValidationError([
                        {
                            path: ['device_envs'],
                            message: 'Device environment key must be unique',
                            code: 'custom'
                        }
                    ]);
                }
                envIds.add(env.key);
            }
        }

        const existingEnvs = await deps.deviceEnvRepository.findAll({
            parentId: deviceId,
            transaction: transaction
        });
        const incomingIds = new Set(envs?.filter(s => s.id).map(s => s.id) || []);

        for (const existing of existingEnvs) {
            if (!incomingIds.has(existing.id)) {
                await deps.deviceEnvRepository.delete({
                    parentId: deviceId,
                    id: existing.id,
                    transaction: transaction
                });
            }
        }

        if (envs) {
            for (const env of envs) {
                if (env.id) {
                    await deps.deviceEnvRepository.update({
                        parentId: deviceId,
                        id: env.id,
                        entity: {
                            key: env.key,
                            type: env.type as DEVICE_METADATA_TYPE,
                            value: env.value
                        },
                        transaction: transaction
                    });
                } else {
                    await deps.deviceEnvRepository.create({
                        parentId: deviceId,
                        entity: {
                            device_id: deviceId,
                            key: env.key,
                            type: env.type as DEVICE_METADATA_TYPE,
                            value: env.value
                        },
                        transaction: transaction
                    });
                }
            }
        }


        return null;
    }

    const syncDeviceSensors = async (deviceId: number, sensors: DeviceAggsUpdateDTO['device_sensors'], transaction?: AnyPgTransaction) => {
        const existingSensors = await deps.deviceSensorRepository.findAll({
            parentId: deviceId,
            transaction: transaction
        });
        const incomingIds = new Set(sensors?.filter(s => s.id).map(s => s.id) || []);

        for (const existing of existingSensors) {
            if (!incomingIds.has(existing.id)) {
                await deps.deviceSensorRepository.delete({
                    parentId: deviceId,
                    id: existing.id,
                    transaction: transaction
                });
            }
        }

        if (sensors) {
            for (const sensor of sensors) {
                if (sensor.id) {
                    await deps.deviceSensorRepository.update({
                        parentId: deviceId,
                        id: sensor.id,
                        entity: {
                            sensor_id: sensor.sensor_id,
                            sensor_type: sensor.sensor_type,
                            danger_status: sensor.danger_status,
                            normalMin: sensor.normalMin ?? undefined,
                            normalMax: sensor.normalMax ?? undefined,
                            dangerMin: sensor.dangerMin ?? undefined,
                            dangerMax: sensor.dangerMax ?? undefined,
                        } as any,
                        transaction: transaction
                    });
                } else {
                    await deps.deviceSensorRepository.create({
                        parentId: deviceId,
                        entity: {
                            device_id: deviceId,
                            sensor_id: sensor.sensor_id!,
                            sensor_type: sensor.sensor_type!,
                            danger_status: sensor.danger_status!,
                            normalMin: sensor.normalMin ?? undefined,
                            normalMax: sensor.normalMax ?? undefined,
                            dangerMin: sensor.dangerMin ?? undefined,
                            dangerMax: sensor.dangerMax ?? undefined,
                        },
                        transaction: transaction
                    });
                }
            }
        }

        return null;
    }

    return deps.deviceRepository.transaction(async (tx) => {
        const validated = await DeviceAggsUpdateDTO
            .superRefine((data, ctx) => {
                if (data.device_envs.length === 0) {
                    // key in data_envs is unique
                    const keys = data.device_envs.map((item) => item.key);
                    const uniqueKeys = new Set(keys);
                    if (keys.length !== uniqueKeys.size) {
                        ctx.addIssue({
                            code: z.ZodIssueCode.custom,
                            path: ['device_envs'],
                            message: 'Device environment key must be unique'
                        })
                    }
                }
            }).parseAsync(props.dto);

        const existingDevice = await deps.deviceRepository.findById({ id: props.id });
        if (!existingDevice) {
            throw new BusinessValidationError([{
                path: ['id'],
                message: 'Device not found',
                code: 'custom'
            }]);
        }

        const device = await deps.deviceRepository.update({
            id: props.id,
            entity: {
                ...validated,
                last_seen: validated.last_seen ? new Date(validated.last_seen) : undefined,
                raw_id: validated.raw_id ? Number(validated.raw_id) : undefined,
                token: validated.token,
            },
            userId: guard.user?.id,
            transaction: tx
        });

        await syncDeviceEnvs(props.id, validated.device_envs, tx as AnyPgTransaction);
        await syncDeviceSensors(props.id, validated.device_sensors, tx as AnyPgTransaction);

        const deviceEnv = await deps.deviceEnvRepository.findAll({ parentId: props.id });
        const deviceSensor = await deps.deviceSensorRepository.findAll({ parentId: props.id });

        return DeviceAggsResponseDTO.parse({ ...device, device_envs: deviceEnv, device_sensors: deviceSensor });
    })
}


