import { TPaginateQuery, TPaginateResult, TUsecase } from "../../../../../src/common/types";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IDeviceRepository } from "../../../domains/repositories/device.repository";


import LabmonitorPermissions from "../../../domains/permissions";
import { DeviceResponseDTO } from "../../dtos/device.dto";

interface PaginateDeviceDeps {
    deviceRepository: IDeviceRepository
}
interface PaginateDeviceProps extends TPaginateQuery<DeviceResponseDTO> {
    context: UsecaseContext
}

export const PaginateDevice: TUsecase<PaginateDeviceDeps, PaginateDeviceProps, TPaginateResult<DeviceResponseDTO>> = (deps: PaginateDeviceDeps) => async (props: PaginateDeviceProps) => {
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.Read);


    let { page, limit, filter, sort, withAudit } = props
    page = page || 1
    limit = limit || 20
    filter = filter || []
    sort = sort || []
    withAudit = withAudit || false

    return await deps.deviceRepository.paginate({
        query: { page, limit, filter, sort, withAudit }
    });
}