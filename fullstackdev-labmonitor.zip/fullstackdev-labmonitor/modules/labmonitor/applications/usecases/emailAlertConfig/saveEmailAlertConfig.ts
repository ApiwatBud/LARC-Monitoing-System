import { z } from "zod";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import { IConfigRepository } from "../../../../../src/modules/config/domains/repositories/config.repository";
import { ConfigTypeEnum } from "../../../../../src/modules/config/domains/valueObjects/config.type";
import { ConfigResponseDto } from "../../../../../src/modules/config/applications/dtos/config.dto";
import { EmailAlertConfigDto } from "../../dtos/email_alert_config.dto";
import { EMAIL_ALERT_CONFIG_KEY } from "./getEmailAlertConfig";
import LabmonitorPermissions from "../../../domains/permissions";

interface SaveEmailAlertConfigDeps {
    configRepository: IConfigRepository;
}

interface SaveEmailAlertConfigProps {
    dto: z.infer<typeof EmailAlertConfigDto>;
    context: UsecaseContext;
}

export const SaveEmailAlertConfig = ({ configRepository }: SaveEmailAlertConfigDeps) => async (props: SaveEmailAlertConfigProps) => {
    const { dto, context } = props;
    const guard = createGuard(props.context);
    guard.ensure(LabmonitorPermissions.EmailAlertSettingWrite);
    const key = EMAIL_ALERT_CONFIG_KEY;

    const existing = await configRepository.findByKey({ key });

    const value = JSON.stringify(EmailAlertConfigDto.parse(dto));

    if (existing) {
        const updated = await configRepository.update({
            id: existing.id,
            entity: {
                type: ConfigTypeEnum.OBJECT,
                value: value
            },
            userId: guard.user?.id
        });
        return ConfigResponseDto.parse(updated);
    } else {
        const created = await configRepository.create({
            entity: {
                key: key,
                type: ConfigTypeEnum.OBJECT,
                value: value
            },
            userId: guard.user?.id
        });
        return ConfigResponseDto.parse(created);
    }
}