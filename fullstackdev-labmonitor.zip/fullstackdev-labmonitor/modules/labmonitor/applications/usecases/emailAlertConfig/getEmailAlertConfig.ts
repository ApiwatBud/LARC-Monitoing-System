import { IConfigRepository } from "../../../../../src/modules/config/domains/repositories/config.repository";
import { EmailAlertConfigDto } from "../../dtos/email_alert_config.dto";
import { createGuard, UsecaseContext } from "../../../../../src/common/utils/guard";
import LabmonitorPermissions from "../../../domains/permissions";

interface GetEmailAlertConfigDeps {
    configRepository: IConfigRepository;
}

interface GetEmailAlertConfigProps {
    context: UsecaseContext;
    skipGuard?: boolean;
}

export const EMAIL_ALERT_CONFIG_KEY = "EMAIL_ALERT";

export const DEFAULT_EMAIL_ALERT_CONFIG = EmailAlertConfigDto.parse({});

export const GetEmailAlertConfig = ({ configRepository }: GetEmailAlertConfigDeps) => async (props: GetEmailAlertConfigProps) => {
    const { context, skipGuard = false } = props;
    if (!skipGuard) {
        const guard = createGuard(context);
        guard.ensure(LabmonitorPermissions.EmailAlertSettingRead);
    }

    const config = await configRepository.findByKey({ key: EMAIL_ALERT_CONFIG_KEY });

    if (!config) {
        return DEFAULT_EMAIL_ALERT_CONFIG;
    }

    try {
        const parsedValue = JSON.parse(config.value);
        return EmailAlertConfigDto.parse(parsedValue);
    } catch (e) {
        console.error("Failed to parse EMAIL_ALERT configuration", e);
        return DEFAULT_EMAIL_ALERT_CONFIG;
    }
}