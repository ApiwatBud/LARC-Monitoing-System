import z from "zod";
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DEVICE_STATUS } from "../../domains/valueObject";
import { DeviceEntity } from "../../domains/entities/device.entity";

export const DeviceResponseDTO = z.object({
    id: z.number(),
    name: z.string(),
    description: z.string().nullable(),
    connection_status: z.enum(DEVICE_CONNECTION_STATUS),
    danger_status: z.enum(DEVICE_DANGER_STATUS),
    status: z.enum(DEVICE_STATUS),
    last_seen: z.date().nullable().optional(),
    raw_id: z.number().nullable().optional(),
    token: z.string().nullable().optional(),
    deletedAt: z.date().nullable(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullable().optional(),
    updaterName: z.string().nullable().optional(),
    createdAt: z.date(),
    updatedAt: z.date()
} satisfies Record<keyof DeviceEntity, any>)

export type DeviceResponseDTO = z.infer<typeof DeviceResponseDTO>

export const DeviceCreateDTO = z.object({
    name: z.string(),
    description: z.string().nullable().optional(),
    connection_status: z.enum(DEVICE_CONNECTION_STATUS).default(DEVICE_CONNECTION_STATUS.OFFLINE),
    danger_status: z.enum(DEVICE_DANGER_STATUS).default(DEVICE_DANGER_STATUS.NORMAL),
    status: z.enum(DEVICE_STATUS).default(DEVICE_STATUS.ACTIVE),
    last_seen: z.string().nullable().optional(),
    raw_id: z.number().nullable().optional(),
    token: z.string().nullable().optional(),
})

export type DeviceCreateDTO = z.infer<typeof DeviceCreateDTO>

export const DeviceUpdateDTO = DeviceCreateDTO.partial()

export type DeviceUpdateDTO = z.infer<typeof DeviceUpdateDTO>

export const DeviceCountResponseDTO = z.object({
    total: z.number(),
    online: z.number()
})

export type DeviceCountResponseDTO = z.infer<typeof DeviceCountResponseDTO>
