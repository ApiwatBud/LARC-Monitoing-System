import { z } from "zod";
import { DEVICE_DANGER_STATUS, DEVICE_SENSOR_TYPE } from "../../domains/valueObject";

export const DeviceSensorDataResponseDTO = z.object({
    id: z.number(),
    sensor_id: z.string(),
    device_name: z.string(),
    sensor_type: z.enum(DEVICE_SENSOR_TYPE),
    sensor_timestamp: z.coerce.date(),
    raw_value: z.string(),
    process_value_number: z.number().nullable(),
    process_value_text: z.string().nullable(),
    raw_id: z.union([z.number(), z.null()]),
    dangerStatus: z.enum(DEVICE_DANGER_STATUS),
    createdAt: z.date(),
    updatedAt: z.date(),
    deletedAt: z.date().nullable(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable()
});

export type DeviceSensorDataResponseDTO = z.infer<typeof DeviceSensorDataResponseDTO>;

export const DeviceSensorDataCreateDTO = z.object({
    sensor_id: z.string().min(1, "Sensor ID is required"),
    device_name: z.string().min(1, "Device name is required"),
    sensor_type: z.enum(DEVICE_SENSOR_TYPE),
    sensor_timestamp: z.iso.datetime(),
    raw_value: z.string().min(1, "Raw value is required"),
    raw_id: z.union([z.number(), z.null()]).default(0)
});

export type DeviceSensorDataCreateDTO = z.infer<typeof DeviceSensorDataCreateDTO>;

export const DeviceSensorDataUpdateDTO = DeviceSensorDataCreateDTO.extend({
    process_value_number: z.number().nullish(),
    process_value_text: z.string().nullish(),

}).partial();

export type DeviceSensorDataUpdateDTO = z.infer<typeof DeviceSensorDataUpdateDTO>;


export const DeviceSensorDataFilterDTO = z.object({
    device_name: z.string(),
    sensor_id: z.string(),
    start_date: z.iso.datetime().default(new Date().toISOString()),
    end_date: z.iso.datetime().default((new Date()).toISOString()),
})

export type DeviceSensorDataFilterDTO = z.infer<typeof DeviceSensorDataFilterDTO>;
