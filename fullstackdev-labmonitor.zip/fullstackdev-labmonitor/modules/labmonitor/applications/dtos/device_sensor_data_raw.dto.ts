import { z } from "zod";
import { DeviceSensorDataRawEntity } from "../../domains/entities/device_sensor_data_raw.entity";
import { PROCESS_STATUS } from "../../domains/valueObject";

export const DeviceSensorDataRawResponseDTO = z.object({
    id: z.number(),
    device_id: z.number(),
    device_name: z.string(),
    process_status: z.enum(PROCESS_STATUS),
    values: z.any(),
    createdAt: z.date(),
    updatedAt: z.date(),
    deletedAt: z.date().nullable(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullable().optional(),
    updaterName: z.string().nullable().optional(),
    process_log: z.string().nullable().optional(),
} satisfies Record<keyof DeviceSensorDataRawEntity, any>)

export type DeviceSensorDataRawResponseDTO = z.infer<typeof DeviceSensorDataRawResponseDTO>

export const DeviceSensorDataRawCreateDTO = z.object({
    device_name: z.string(),
    device_token: z.string().optional(),
    values: z.preprocess((val) => {
        if (typeof val === 'string') {
            try {
                return JSON.parse(val);
            } catch (e) {
                return val;
            }
        }
        return val;
    }, z.record(z.string(), z.any()).default({})),
})

export type DeviceSensorDataRawCreateDTO = z.infer<typeof DeviceSensorDataRawCreateDTO>

export const DeviceSensorDataRawUpdateDTO = DeviceSensorDataRawCreateDTO.partial()

export type DeviceSensorDataRawUpdateDTO = z.infer<typeof DeviceSensorDataRawUpdateDTO>
