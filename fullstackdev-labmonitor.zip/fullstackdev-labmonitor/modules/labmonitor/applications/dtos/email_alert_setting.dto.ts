import { z } from "zod";

export const EmailAlertSettingResponseDto = z.object({
    id: z.number(),
    recipientEmail: z.string().email(),
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.number().nullable().optional(),
    updatedBy: z.number().nullable().optional(),
    creatorName: z.string().nullable().optional(),
    updaterName: z.string().nullable().optional(),
})

export type EmailAlertSettingResponseDto = z.infer<typeof EmailAlertSettingResponseDto>

export const EmailAlertSettingCreateDto = z.object({
    recipientEmail: z.email(),
})

export type EmailAlertSettingCreateDto = z.infer<typeof EmailAlertSettingCreateDto>

export const EmailAlertSettingUpdateDto = EmailAlertSettingCreateDto.partial()

export type EmailAlertSettingUpdateDto = z.infer<typeof EmailAlertSettingUpdateDto>
