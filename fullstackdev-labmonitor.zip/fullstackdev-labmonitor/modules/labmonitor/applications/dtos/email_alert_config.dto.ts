import { z } from "zod";

export const EMAIL_ALERT_LEVELS = ["warning", "danger"] as const;
export const RATE_LIMIT_UNITS = ["minutes", "hours", "days"] as const;
export const RATE_LIMIT_MINUTES_MAP = {
    minutes: 1,
    hours: 60,
    days: 1440,
} as const;

const RateLimitStageDto = z.object({
    value: z.number().int().positive(),
    unit: z.enum(RATE_LIMIT_UNITS),
})

export type RateLimitStageDto = z.infer<typeof RateLimitStageDto>

export const DEFAULT_RATE_LIMIT_STAGES: RateLimitStageDto[] = [
    { value: 30, unit: "minutes" },
];

export const EmailAlertConfigDto = z.object({
    enable: z.boolean().default(true),
    minLevel: z.enum(EMAIL_ALERT_LEVELS).default("warning"),
    fromName: z.string().min(1).default("Lab Monitor System"),
    // Rate limit rules (ตรงตาม logic เดิม 4 ข้อ)
    sendOnFirstWarning: z.boolean().default(true),
    rateLimitStages: z.array(RateLimitStageDto).min(1).default(DEFAULT_RATE_LIMIT_STAGES),
    resetOnSensorChange: z.boolean().default(true),
    clearOnNormal: z.boolean().default(true),
})

export type EmailAlertConfigDto = z.infer<typeof EmailAlertConfigDto>