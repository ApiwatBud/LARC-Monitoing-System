import { DeviceCreateDTO, DeviceResponseDTO, DeviceUpdateDTO } from "./device.dto";
import { DeviceEnvCreateDTO, DeviceEnvResponseDTO, DeviceEnvUpdateDTO } from "./device_env.dto";
import { DeviceSensorCreateDTO, DeviceSensorResponseDTO, DeviceSensorUpdateDTO } from "./device_sensor.dto";
import z from "zod";
import { DeviceSensorDataResponseDTO } from "./device_sensor_data.dto";

export const DeviceAggsResponseDTO = DeviceResponseDTO.extend({
    device_envs: z.array(DeviceEnvResponseDTO),
    device_sensors: z.array(DeviceSensorResponseDTO)
})

export const DeviceDtoWithLatestSensorData = DeviceAggsResponseDTO.extend({
    latest_sensor_data: z.array(DeviceSensorDataResponseDTO).optional(),
})

export type DeviceDtoWithLatestSensorData = z.infer<typeof DeviceDtoWithLatestSensorData>

export type DeviceAggsResponseDTO = z.infer<typeof DeviceAggsResponseDTO>

export const DeviceAggsUpdateDTO = DeviceUpdateDTO.extend({
    device_envs: z.array(DeviceEnvUpdateDTO).default([]),
    device_sensors: z.array(DeviceSensorUpdateDTO).default([])
}).refine((data) => {
    const envs = data.device_envs;
    const keys = envs.map(env => env.key);
    const uniqueKeys = new Set(keys);
    return keys.length === uniqueKeys.size;
}, {
    message: "Device environments must have unique keys",
    path: ["device_envs"]
}).refine((data) => {
    const sensors = data.device_sensors;
    const ids = sensors.map(s => s.sensor_id);
    const uniqueIds = new Set(ids);
    return ids.length === uniqueIds.size;
}, {
    message: "Device sensors must have unique sensor IDs",
    path: ["device_sensors"]
})

export type DeviceAggsUpdateDTO = z.infer<typeof DeviceAggsUpdateDTO>

export const DeviceAggsCreateDTO = DeviceCreateDTO.extend({
    device_envs: z.array(DeviceEnvCreateDTO).default([]),
    device_sensors: z.array(DeviceSensorCreateDTO).default([])
}).refine((data) => {
    const envs = data.device_envs;
    const keys = envs.map(env => env.key);
    const uniqueKeys = new Set(keys);
    return keys.length === uniqueKeys.size;
}, {
    message: "Device environments must have unique keys",
    path: ["device_envs"]
}).refine((data) => {
    const sensors = data.device_sensors;
    const ids = sensors.map(s => s.sensor_id);
    const uniqueIds = new Set(ids);
    return ids.length === uniqueIds.size;
}, {
    message: "Device sensors must have unique sensor IDs",
    path: ["device_sensors"]
})

export type DeviceAggsCreateDTO = z.infer<typeof DeviceAggsCreateDTO>
