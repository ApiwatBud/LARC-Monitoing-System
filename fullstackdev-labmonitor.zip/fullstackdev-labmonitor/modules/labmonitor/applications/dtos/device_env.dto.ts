import z from "zod";
import { DeviceEnvEntity } from "../../domains/entities/device_env.entity";

export const DeviceEnvResponseDTO = z.object({
    id: z.number(),
    device_id: z.number(),
    key: z.string(),
    type: z.string(),
    value: z.string(),
    createdAt: z.date(),
    updatedAt: z.date(),
    deletedAt: z.date().nullable(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullable().optional(),
    updaterName: z.string().nullable().optional()
} satisfies Record<keyof DeviceEnvEntity, any>)

export type DeviceEnvResponseDTO = z.infer<typeof DeviceEnvResponseDTO>

export const DeviceEnvUpdateDTO = DeviceEnvResponseDTO
    .extend({
        key: z.string().min(1, "Key is required"),
        type: z.string().min(1, "Type is required"),
        value: z.string().min(1, "Value is required"),
    })
    .omit({
        createdAt: true,
        updatedAt: true,
        deletedAt: true,
        createdBy: true,
        updatedBy: true,
        creatorName: true,
        updaterName: true
    })
    .partial().required({
        key: true,
        type: true,
        value: true,
    })
export const DeviceEnvCreateDTO = DeviceEnvUpdateDTO
export type DeviceEnvCreateDTO = z.infer<typeof DeviceEnvCreateDTO>
export type DeviceEnvUpdateDTO = z.infer<typeof DeviceEnvUpdateDTO>
