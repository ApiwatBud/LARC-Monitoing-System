import z from "zod";
import { DEVICE_DANGER_STATUS, DEVICE_SENSOR_TYPE } from "../../domains/valueObject";
import { DeviceSensorEntity } from "../../domains/entities/device_sensor.entity";

export const DeviceSensorResponseDTO = z.object({
    id: z.number(),
    sensor_id: z.string(),
    device_id: z.number(),
    sensor_type: z.enum(DEVICE_SENSOR_TYPE),
    danger_status: z.enum(DEVICE_DANGER_STATUS),
    normalMin: z.number().nullable().optional(),
    normalMax: z.number().nullable().optional(),
    dangerMin: z.number().nullable().optional(),
    dangerMax: z.number().nullable().optional(),
    createdAt: z.date(),
    updatedAt: z.date(),
    deletedAt: z.date().nullable(),
    createdBy: z.number().nullable(),
    updatedBy: z.number().nullable(),
    creatorName: z.string().nullable().optional(),
    updaterName: z.string().nullable().optional(),
} satisfies Record<keyof DeviceSensorEntity, any>)

export type DeviceSensorResponseDTO = z.infer<typeof DeviceSensorResponseDTO>

export const DeviceSensorCreateDTO = z.object({
    sensor_id: z.string().min(1, "Sensor ID is required"),
    sensor_type: z.enum(DEVICE_SENSOR_TYPE),
    danger_status: z.enum(DEVICE_DANGER_STATUS).default(DEVICE_DANGER_STATUS.NORMAL),
    normalMin: z.number().nullable().optional(),
    normalMax: z.number().nullable().optional(),
    dangerMin: z.number().nullable().optional(),
    dangerMax: z.number().nullable().optional(),
})

export type DeviceSensorCreateDTO = z.infer<typeof DeviceSensorCreateDTO>

export const DeviceSensorUpdateDTO = DeviceSensorCreateDTO.partial().extend({
    id: z.number().optional()
})

export type DeviceSensorUpdateDTO = z.infer<typeof DeviceSensorUpdateDTO>
