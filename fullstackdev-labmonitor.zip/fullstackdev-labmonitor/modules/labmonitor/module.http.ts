import Elysia from "elysia";
import { LabMonitorIoC } from "./ioc";
import { EmailAlertLogHttp } from "./applications/http/email_alert_log.http";
import { EmailAlertSettingHttp } from "./applications/http/email_alert_setting.http";
import { EmailAlertConfigHttp } from "./applications/http/email_alert_config.http";
import { DeviceSensorDataHttp } from "./applications/http/device_sensor_data.http";
import { DeviceSensorDataRawHttp } from "./applications/http/device_sensor_data_raw.http";
import { DeviceHttp } from "./applications/http/device.http";

export const LabmonitorModule = new Elysia({
    detail: {
        tags: ["labmonitor"]
    }
})
    .use(LabMonitorIoC)
    .use(DeviceHttp)
    .use(DeviceSensorDataRawHttp)
    .use(DeviceSensorDataHttp)
    .use(EmailAlertSettingHttp)
    .use(EmailAlertLogHttp)
    .use(EmailAlertConfigHttp)
