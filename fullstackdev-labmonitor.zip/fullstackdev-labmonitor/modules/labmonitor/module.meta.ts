import { FiActivity, FiBox, FiDatabase, FiMail, FiSettings } from "react-icons/fi";
import { LabmonitorPermissions } from "./domains/permissions";
import { IModuleMeta } from "../../src/modules/config/domains/entities/module.meta";
import LabMonitorRoutes from "./ui/backoffice/routes";

/**
 * Metadata for the Lab Monitor module.
 * Centralizes configuration for registry and UI.
 */
export const LabMonitorMeta: IModuleMeta = {
    key: 'labmonitor',
    name: 'Lab Monitor',
    description: 'Track device status, sensor data, and manage automated alerts.',
    version: '1.0.0',
    author: 'System',
    icon: FiActivity,
    permissions: LabmonitorPermissions,
    menu: () => ({
        key: 'labmonitor',
        name: 'Lab Monitor',
        description: 'Track device status, sensor data, and manage automated alerts.',
        color: 'blue',
        icon: FiActivity,
        children: [
            {
                key: 'dashboard',
                name: 'Dashboard',
                icon: FiActivity,
                route: '/backoffice/labmonitor'
            },
            {
                key: 'overview',
                name: 'Overview',
                icon: FiActivity,
                route: '/backoffice/labmonitor/overview'
            },
            {
                key: 'devices',
                name: 'Devices',
                icon: FiBox,
                route: '/backoffice/labmonitor/devices'
            },
            {
                key: 'sensor-data-raw',
                name: 'Raw Sensor Data',
                icon: FiDatabase,
                route: '/backoffice/labmonitor/sensor-data-raw'
            },
            {
                key: 'sensor-data',
                name: 'Sensor Data',
                icon: FiActivity,
                route: '/backoffice/labmonitor/sensor-data'
            },
            {
                key: 'email',
                name: 'Email Alerts',
                icon: FiMail,
                children: [
                    {
                        key: 'email-alert-config',
                        name: 'Configuration',
                        icon: FiSettings,
                        route: '/backoffice/labmonitor/email-alert-config'
                    },
                    {
                        key: 'email-alert-settings',
                        name: 'Settings',
                        icon: FiDatabase,
                        route: '/backoffice/labmonitor/email-alert-settings'
                    },
                    {
                        key: 'email-alert-logs',
                        name: 'History',
                        icon: FiActivity,
                        route: '/backoffice/labmonitor/email-alert-logs'
                    }
                ]
            }
        ]
    }),
    routes: LabMonitorRoutes
};
