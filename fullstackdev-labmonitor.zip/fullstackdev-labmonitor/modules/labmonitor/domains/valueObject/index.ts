export enum DEVICE_CONNECTION_STATUS {
    ONLINE = 'online',
    OFFLINE = 'offline'
}
export enum DEVICE_STATUS {
    ACTIVE = 'active',
    INACTIVE = 'inactive'
}

export enum DEVICE_DANGER_STATUS {
    NORMAL = 'normal',
    WARNING = 'warning',
    DANGER = 'danger'
}

export enum DEVICE_METADATA_TYPE {
    TEXT = 'text',
    NUMBER = 'number',
    BOOLEAN = 'boolean'
}

export enum DEVICE_SENSOR_TYPE {
    TEMP = 'temp',
    HUMID = 'humid',
    SOUND = 'sound',
    AMMONIA = 'ammonia',
    LIGHT = 'light',
    AQI = 'aqi',
    AQL_PPM = 'aqi_ppm',
    RAW = "RAW",
    V_BATT = "v_batt",
    WATER_LEVEL = "water_level",
}


export const DeviceSensorTypeMap = {
    [DEVICE_SENSOR_TYPE.TEMP]: 'Temperature (C)',
    [DEVICE_SENSOR_TYPE.HUMID]: 'Humidity (%)',
    [DEVICE_SENSOR_TYPE.SOUND]: 'Sound (dB)',
    [DEVICE_SENSOR_TYPE.AMMONIA]: 'Ammonia (ppm)',
    [DEVICE_SENSOR_TYPE.LIGHT]: 'Light (lux)',
    [DEVICE_SENSOR_TYPE.AQI]: 'AQI Level',
    [DEVICE_SENSOR_TYPE.AQL_PPM]: 'AQI (ppm)',
    [DEVICE_SENSOR_TYPE.RAW]: 'Raw Sensor',
    [DEVICE_SENSOR_TYPE.V_BATT]: 'Battery Voltage',
    [DEVICE_SENSOR_TYPE.WATER_LEVEL]: 'Water Level'
}

export enum AQI_STATUS {
    GOOD = 'good',
    MODERATE = 'moderate',
    UNHEALTHY = 'unhealthy',
    UNHEALTHY_SENSITIVE = 'unhealthy_sensitive',
    VERY_UNHEALTHY = 'very_unhealthy',
    HAZARDOUS = 'hazardous'
}

export enum PROCESS_STATUS {
    PENDING = 'pending',
    COMPLETED = 'completed',
    PARTIAL_SUCCESS = 'partial_success',
    FAILED = 'failed'
}