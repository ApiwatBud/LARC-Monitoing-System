import { BaseEntity } from "../../../../src/common/domains/baseEntity";

export type EmailAlertSetting = BaseEntity & {
    recipientEmail: string;
}

