import { DeviceEntity } from "./device.entity";
import { DeviceEnvEntity } from "./device_env.entity";
import { DeviceSensorEntity } from "./device_sensor.entity";
import { DeviceSensorDataEntity } from "./device_sensor_data.entity";

export type DeviceWithSensorAndEnv = DeviceEntity & {
    sensors: DeviceSensorEntity[];
    latest_sensor_data?: DeviceSensorDataEntity[];
    envs: DeviceEnvEntity[];
}