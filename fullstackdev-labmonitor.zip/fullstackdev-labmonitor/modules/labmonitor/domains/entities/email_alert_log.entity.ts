import { BaseEntity } from "../../../../src/common/domains/baseEntity";

export type EmailAlertLogEntity = {
    id: number;
    device_id: number;
    device_name: string;
    alert_type: string; // 'device_warning', 'summary_warning'
    recipients: string;
    subject: string;
    content: string | null;
    message_id: string | null;
    sent_at: Date;
} & BaseEntity;
