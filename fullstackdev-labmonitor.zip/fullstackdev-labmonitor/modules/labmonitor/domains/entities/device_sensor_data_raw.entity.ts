import { AuditEntity, BaseEntity, JustEntity, TimestampEntity } from "../../../../src/common/domains/baseEntity";
import { PROCESS_STATUS } from "../valueObject";

export type DeviceSensorDataRawEntity = JustEntity & {
    id: number;
    device_id: number;
    device_name: string;
    process_status: PROCESS_STATUS;
    values: any;
    process_log: string;
} & BaseEntity & TimestampEntity & AuditEntity

