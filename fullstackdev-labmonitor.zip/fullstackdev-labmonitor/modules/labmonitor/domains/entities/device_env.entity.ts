import { BaseEntity, JustEntity, TimestampEntity, AuditEntity } from "../../../../src/common/domains/baseEntity";
import { DEVICE_METADATA_TYPE } from "../valueObject";

export type DeviceEnvEntity = JustEntity & {
    id: number;
    device_id: number;
    key: string;
    type: DEVICE_METADATA_TYPE;
    value: string;
} & BaseEntity & TimestampEntity & AuditEntity