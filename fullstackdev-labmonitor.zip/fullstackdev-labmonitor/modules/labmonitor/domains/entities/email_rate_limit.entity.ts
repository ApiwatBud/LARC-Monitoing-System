import { JustEntity, BaseEntity, TimestampEntity, SoftDeleteEntity } from "../../../../src/common/domains/baseEntity";

export type EmailRateLimitEntity = JustEntity & {
    device_id: number;
    last_sent_at: Date;
    sent_count: number;
    warning_fingerprint?: string | null;
} & BaseEntity & TimestampEntity & SoftDeleteEntity;
