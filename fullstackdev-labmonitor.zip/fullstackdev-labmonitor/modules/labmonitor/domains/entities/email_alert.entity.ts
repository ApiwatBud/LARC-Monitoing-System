import { BaseEntity } from "../../../../src/common/domains/baseEntity";

export type EmailAlert = BaseEntity & {
    recipientEmail: string;
    message: string;
    triggerValue: string;
    alertLevel: string;
    status: string;
    sentAt: Date;
    errorMessage: string;
}