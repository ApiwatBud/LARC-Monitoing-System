import { JustEntity, BaseEntity, TimestampEntity, AuditEntity, SoftDeleteEntity } from "../../../../src/common/domains/baseEntity";
import { DEVICE_CONNECTION_STATUS, DEVICE_DANGER_STATUS, DEVICE_STATUS } from "../valueObject";

export type DeviceEntity = JustEntity & {
    id: number;
    name: string;
    description: string | null;
    connection_status: DEVICE_CONNECTION_STATUS;
    danger_status: DEVICE_DANGER_STATUS;
    status: DEVICE_STATUS;
    last_seen?: Date | null;
    raw_id?: number | null;
    token?: string | null;
} & BaseEntity & TimestampEntity & AuditEntity & SoftDeleteEntity


