import { AuditEntity, BaseEntity, JustEntity, TimestampEntity } from "../../../../src/common/domains/baseEntity";
import { DEVICE_DANGER_STATUS, DEVICE_SENSOR_TYPE } from "../valueObject";

export type DeviceSensorEntity = JustEntity & {
    id: number;
    sensor_id: string;
    device_id: number;
    sensor_type: DEVICE_SENSOR_TYPE;
    danger_status: DEVICE_DANGER_STATUS;
    normalMin?: number;
    normalMax?: number;
    dangerMin?: number;
    dangerMax?: number;
} & BaseEntity & TimestampEntity & AuditEntity