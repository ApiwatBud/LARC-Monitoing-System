import { AuditEntity, BaseEntity, JustEntity, TimestampEntity } from "../../../../src/common/domains/baseEntity";
import { DEVICE_DANGER_STATUS, DEVICE_SENSOR_TYPE } from "../valueObject";

export type DeviceSensorDataEntity = JustEntity & {
    id: number;
    sensor_id: string;
    device_id: number;
    device_name: string;
    sensor_type: DEVICE_SENSOR_TYPE;
    sensor_timestamp: Date;
    raw_value: string;
    process_value_number?: number;
    process_value_text?: string;
    raw_id?: number;
    dangerStatus: DEVICE_DANGER_STATUS;
} & BaseEntity & TimestampEntity & AuditEntity
