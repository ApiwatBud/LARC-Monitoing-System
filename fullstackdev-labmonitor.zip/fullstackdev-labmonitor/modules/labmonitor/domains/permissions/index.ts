export const LabmonitorPermissions = {
    Read: 'labmonitor:read',
    Write: 'labmonitor:write',
    Delete: 'labmonitor:delete',
    Edit: 'labmonitor:edit',
    Ingest: 'labmonitor:ingest',
    Create: 'labmonitor:create',
    Update: 'labmonitor:update',
    EmailAlertSettingRead: 'labmonitor:email-alert-setting:read',
    EmailAlertSettingWrite: 'labmonitor:email-alert-setting:write'
}

export default LabmonitorPermissions