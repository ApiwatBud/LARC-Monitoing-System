import { ITransactionalChildTableRepository } from "../../../../src/common/repositories/repository.interface";
import { DeviceEnvEntity } from "../entities/device_env.entity";

export interface IDeviceEnvRepository extends ITransactionalChildTableRepository<DeviceEnvEntity> {

}