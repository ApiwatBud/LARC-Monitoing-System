import { ITransactionalRepository } from "../../../../src/common/repositories/repository.interface";
import { EmailRateLimitEntity } from "../entities/email_rate_limit.entity";
import { AnyTransaction } from "../../../../src/common/persistents/types";

export interface IEmailRateLimitRepository extends ITransactionalRepository<EmailRateLimitEntity> {
    findByDeviceId(props: { deviceId: number, transaction?: AnyTransaction }): Promise<EmailRateLimitEntity | null>;
    upsert(props: { entity: Partial<EmailRateLimitEntity>, transaction?: AnyTransaction }): Promise<EmailRateLimitEntity>;
    deleteByDeviceId(props: { deviceId: number, transaction?: AnyTransaction }): Promise<void>;
}
