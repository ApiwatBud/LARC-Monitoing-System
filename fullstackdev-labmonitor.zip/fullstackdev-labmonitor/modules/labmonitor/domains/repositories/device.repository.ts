import { AnyTransaction } from "../../../../src/common/persistents/types";
import { ITransactionalRepository } from "../../../../src/common/repositories/repository.interface";
import { DeviceWithSensorAndEnv } from "../entities/device.aggs";
import { DeviceEntity } from "../entities/device.entity";

export interface IDeviceRepository extends ITransactionalRepository<DeviceEntity> {
    findAllWithAggs(): Promise<DeviceWithSensorAndEnv[]>;
    healthCheck({ minutes }: { minutes: number }): unknown;
    findByName({ name, transaction }: { name: string, transaction?: AnyTransaction }): Promise<DeviceEntity>;
    findByToken({ token, transaction }: { token: string, transaction?: AnyTransaction }): Promise<DeviceEntity | null>;
    getWithLatestData(): Promise<DeviceWithSensorAndEnv[]>;
}