import { ITransactionalRepository } from "../../../../src/common/repositories/repository.interface";
import { DeviceSensorDataFilterDTO } from "../../applications/dtos/device_sensor_data.dto";
import { DeviceSensorDataEntity } from "../entities/device_sensor_data.entity";





export interface IDeviceSensorDataRepository extends ITransactionalRepository<DeviceSensorDataEntity> {

    loadData(body: DeviceSensorDataFilterDTO): Promise<DeviceSensorDataEntity[]>
}

