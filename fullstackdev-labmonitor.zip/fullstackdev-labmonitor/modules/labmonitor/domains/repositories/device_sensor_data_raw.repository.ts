import { ITransactionalRepository } from "../../../../src/common/repositories/repository.interface";
import { DeviceSensorDataRawEntity } from "../entities/device_sensor_data_raw.entity";

export interface IDeviceSensorDataRawRepository extends ITransactionalRepository<DeviceSensorDataRawEntity> {

}
