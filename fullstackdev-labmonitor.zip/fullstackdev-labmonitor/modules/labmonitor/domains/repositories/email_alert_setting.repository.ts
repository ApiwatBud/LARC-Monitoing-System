import { ITransactionalRepository } from "../../../../src/common/repositories/repository.interface";
import { EmailAlertSetting } from "../entities/email_alert_setting.entity";

export interface IEmailAlertSettingRepository extends ITransactionalRepository<EmailAlertSetting> {
}
