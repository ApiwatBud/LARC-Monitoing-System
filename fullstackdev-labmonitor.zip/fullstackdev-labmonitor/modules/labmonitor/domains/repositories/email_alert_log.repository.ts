import { ITransactionalRepository } from "../../../../src/common/repositories/repository.interface";
import { EmailAlertLogEntity } from "../entities/email_alert_log.entity";
import { AnyTransaction } from "../../../../src/common/persistents/types";

export interface IEmailAlertLogRepository extends ITransactionalRepository<EmailAlertLogEntity> {
    logAlert(props: {
        device_id: number,
        device_name: string,
        alert_type: string,
        recipients: string,
        subject: string,
        content?: string,
        message_id?: string,
        transaction?: AnyTransaction
    }): Promise<void>;
}
