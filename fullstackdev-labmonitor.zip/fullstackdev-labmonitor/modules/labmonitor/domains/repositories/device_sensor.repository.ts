import { ITransactionalChildTableRepository } from "../../../../src/common/repositories/repository.interface";
import { DeviceSensorEntity } from "../entities/device_sensor.entity";
import { AnyTransaction } from "../../../../src/common/persistents/types";

export interface IDeviceSensorRepository extends ITransactionalChildTableRepository<DeviceSensorEntity> {
    findBySensorId(props: {
        parentId: number;
        sensorId: string;
        transaction?: AnyTransaction
    }): Promise<DeviceSensorEntity | null>;
}
