# SOSBox Backoffice Requirement

## Introduction

1. SOSBox is an IoT box connected to the lora network
2. SOSBox can share wifi network.
3. Client that connect to wifi network can open a simple website to create sos request
4. SOSBox will send the sos request to the backend server via lora network


## Requirement

1. Operator can register and setup the box before deploythem
2. Operator can retrive status of sosbox such as connection status, battery level, power status, location, name, uuid, type
3. Operator can view all sos request from the box in list view, detail view and map view
4. Operator can received / view sos message from the box
5. Operator can send message to the box
6. Operator can plan the location for deploy the box
7. Operator can view all planned location for deploy the box in list view, detail view and map view
