export enum POWER_STATUS_ENUM {
    POWER_ON = "power_on",
    POWER_OFF = "power_off",
}

export enum CONNECTION_STATUS_ENUM {
    ONLINE = "online",
    OFFLINE = "offline",

}

export enum SOS_BOX_TYPE_ENUM {
    GATEWAY = "gateway",
    NODE = "node",
}