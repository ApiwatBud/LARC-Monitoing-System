import { BaseEntity } from "../../../../src/common/domains/baseEntity";
import { CONNECTION_STATUS_ENUM, POWER_STATUS_ENUM, SOS_BOX_TYPE_ENUM } from "../valueObject/sosboxtype";

export type SOSBox = BaseEntity & {
    name: string
    uuid: string //unique
    location: string
    lat: number
    lng: number

    power_status: POWER_STATUS_ENUM
    battery_level: number
    connection_status: CONNECTION_STATUS_ENUM
    type: SOS_BOX_TYPE_ENUM

}