import { FiMessageSquare } from "react-icons/fi";
import { IModuleMeta } from "../../src/modules/config/domains/entities/module.meta";
import ChatRoutes from "./ui/chat/routes";

export const AIMeta: IModuleMeta = {
    key: "chat",
    name: "AI Chat",
    description: "Chat with AI Assistant",
    version: "1.0.0",
    icon: FiMessageSquare,
    menu: () => ({
        key: "chat",
        name: "AI Chat",
        icon: FiMessageSquare,
        description: "Chat with AI Assistant",
        children: [
            {
                key: "simple-chat",
                name: "Chat",
                icon: FiMessageSquare,
                route: "/backoffice/chat",
                description: "Chat with AI Assistant"
            }
        ]
    }),
    routes: ChatRoutes
};
