import { Route } from "react-router";
import ChatPage from "./index";

export default function ChatRoutes() {
    return (
        <Route path="chat" element={<ChatPage />} />
    );
}
