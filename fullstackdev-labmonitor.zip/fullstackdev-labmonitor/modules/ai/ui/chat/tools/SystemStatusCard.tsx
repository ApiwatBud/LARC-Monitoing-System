// SystemStatusCard.tsx
export const SystemStatusCard = ({ data }: { data: any }) => {
    console.log("data", data);
    if (!data) {
        return null;
    }
    const memUsage = ((data.memory.used / data.memory.total) * 100).toFixed(2);
    const isHighLoad = parseFloat(memUsage) > 90;

    return (
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 my-2 text-white shadow-lg w-full max-w-lg">
            <div className="flex justify-between items-center mb-3">
                <h3 className="font-bold text-blue-400 mr-3">🖥️ {data.os.hostname}</h3>
                <span className={`px-2 py-1 rounded text-xs ${isHighLoad ? 'bg-red-500' : 'bg-green-500'}`}>
                    {isHighLoad ? 'High Load' : 'Normal'}
                </span>
            </div>

            <div className="space-y-3 text-sm">
                {/* Memory Progress Bar */}
                <div>
                    <div className="flex justify-between mb-1">
                        <span>Memory Usage</span>
                        <span className={isHighLoad ? 'text-red-400 font-bold' : ''}>{memUsage}%</span>
                    </div>
                    <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                        <div
                            className={`h-full ${isHighLoad ? 'bg-red-500' : 'bg-blue-500'}`}
                            style={{ width: `${memUsage}%` }}
                        />
                    </div>
                </div>

                {/* CPU & OS Info */}
                <div className="grid grid-cols-2 gap-2 text-slate-300">
                    <div className="bg-slate-800 p-2 rounded">
                        <p className="text-[10px] uppercase text-slate-500">CPU Cores</p>
                        <p className="font-mono">{data.cpu.cores}</p>
                    </div>
                    <div className="bg-slate-800 p-2 rounded">
                        <p className="text-[10px] uppercase text-slate-500">Uptime</p>
                        <p className="font-mono">{Math.floor(data.os.uptime / 3600)}h {Math.floor((data.os.uptime % 3600) / 60)}m</p>
                    </div>
                </div>
            </div>
        </div>
    );
};