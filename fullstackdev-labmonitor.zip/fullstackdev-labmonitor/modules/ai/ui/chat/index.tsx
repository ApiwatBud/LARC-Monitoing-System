import { ChatBubbleLeftRightIcon, PaperAirplaneIcon } from "@heroicons/react/24/solid";
import { useChat } from '@ai-sdk/react'
import { useEffect, useRef, useState } from "react";
import { DefaultChatTransport } from "ai";
import { SystemStatusCard } from "./tools/SystemStatusCard";

export const MessagePartType = ['text', 'tool-get_system_status']

export default function ChatPage() {

    const { messages, sendMessage, status } = useChat({

        transport: new DefaultChatTransport({
            api: '/api/ai/chat',
        }),
    });

    const [input, setInput] = useState('');

    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
        console.log('messages', messages)
    }, [messages]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim()) return;

        await sendMessage({ text: input });
        setInput('');
    };

    return (
        <div className="flex flex-col h-[calc(100vh-100px)] bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 text-white flex justify-between items-center shrink-0 shadow-md">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/20 rounded-full backdrop-blur-sm">
                        <ChatBubbleLeftRightIcon className="w-6 h-6" />
                    </div>
                    <div>
                        <h1 className="font-bold text-lg leading-tight">AI Assistant</h1>
                        <p className="text-xs text-indigo-100 font-medium opacity-90">Always here to help</p>
                    </div>
                </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-gray-50 dark:bg-gray-900/50 scroll-smooth">
                {messages.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-4 opacity-60">
                        <ChatBubbleLeftRightIcon className="w-20 h-20 text-gray-300 dark:text-gray-600" />
                        <p className="text-lg font-medium">Start a conversation...</p>
                    </div>
                )}

                {messages.map((message) => {
                    return message.parts.filter((part) => MessagePartType.includes(part.type)).map((part, index) => {
                        return (
                            <div
                                key={`${message.id}-${index}`}
                                className={`flex w-full  ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                                <div className={`flex flex max-w-[80%] md:max-w-[70%] gap-2 ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                                    <div className={`flex max-w-[80%] md:max-w-[70%] gap-2`}>
                                        {/* Avatar */}
                                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${message.role === 'user'
                                            ? 'bg-indigo-100 text-indigo-600 border border-indigo-200'
                                            : 'bg-emerald-100 text-emerald-600 border border-emerald-200'
                                            }`}>
                                            <span className="text-xs font-bold">{message.role === 'user' ? 'U' : 'AI'}</span>
                                        </div>
                                    </div>

                                    <div
                                        className={`p-3.5 px-5 rounded-2xl shadow-sm text-sm leading-relaxed ${message.role === 'user'
                                            ? 'bg-indigo-600 text-white rounded-tr-none'
                                            : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-700 rounded-tl-none'
                                            }`}>
                                        {part.type == 'text' && <span>{part.text}</span>}
                                        {part.type == 'tool-get_system_status' && <SystemStatusCard data={part.output} />}
                                    </div>
                                </div>
                            </div>
                        )
                    })
                })}

                {
                    (status === 'submitted' || status === 'streaming') && (
                        <div className="flex justify-start w-full animate-fade-in">
                            <div className="flex max-w-[80%] gap-2 items-end">
                                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0 mb-1">
                                    <span className="text-xs font-bold">AI</span>
                                </div>
                                <div className="bg-white dark:bg-gray-800 p-3 px-4 rounded-2xl rounded-tl-none border border-gray-200 dark:border-gray-700 shadow-sm flex items-center gap-3">
                                    <div className="flex gap-1">
                                        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                                        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                                        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce"></div>
                                    </div>
                                    <span className="text-xs text-gray-500 font-medium">AI is thinking...</span>
                                </div>
                            </div>
                        </div>
                    )
                }
                <div ref={messagesEndRef} />
            </div >

            {/* Input Area */}
            < form
                onSubmit={handleSubmit}
                className="p-4 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 flex gap-3 shrink-0 items-end"
            >
                <div className="relative flex-1">
                    <input
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        placeholder="Type to chat..."
                        className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl pl-4 pr-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all text-gray-700 dark:text-gray-200 placeholder:text-gray-400"
                    />
                </div>
                <button
                    type="submit"
                    disabled={status !== 'ready' || !input.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3.5 rounded-xl transition-all duration-200 shadow-md hover:shadow-lg active:scale-95 flex items-center justify-center aspect-square"
                >
                    <PaperAirplaneIcon className="w-5 h-5 -ml-0.5" />
                </button>
            </form >
        </div >
    );
}
