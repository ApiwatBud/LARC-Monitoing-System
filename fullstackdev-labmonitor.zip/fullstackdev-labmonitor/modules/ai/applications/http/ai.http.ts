import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { Elysia, status } from "elysia";
import z from "zod";
import { AIIoC } from "../../ioc";
import { AuthMiddleware } from "../../../../src/modules/core/applications/http/middlewares/auth.middleware";


export const AIMoudle = new Elysia({ prefix: "/ai" })
    .use(AIIoC)
    .use(AuthMiddleware)
    .post("/chat", async ({ aiService, body, user, permissions }) => {
        if (process.env.AI_ENABLED !== 'true') {
            return status(400, "AI is not enabled")
        }
        const { messages } = body;


        const result = await aiService.streamChat(messages, { user, permissions: permissions as any || [] });
        return result.toUIMessageStreamResponse();
    }, {
        body: z.object({
            id: z.string(),
            trigger: z.string(),
            messages: z.array(z.any())
        })

    });
