import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { ToolLoopAgent, convertToModelMessages, stepCountIs, streamText } from "ai";
import { createSystemTools } from "../tools/system.tools";
import { createCoreTools } from "../tools/core.tools";
import { createDeviceTools } from "../tools/device.tools";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { UsecaseContext } from "../../../../src/common/utils/guard";
import { IDeviceRepository } from "../../../labmonitor/domains/repositories/device.repository";
import { CreateDevice } from "../../../labmonitor/applications/usecases/devices/createDevice";
import { UpdateDevice } from "../../../labmonitor/applications/usecases/devices/updateDevice";
import { GetAllDevices } from "../../../labmonitor/applications/usecases/devices/getAllDevices";


const loadModels = () => {
    // Normalize provider name to handle case sensitivity and variations (e.g. LM_STUDIO -> lmstudio)
    const provider = process.env.AI_PROVIDER

    if (provider === 'google') {
        const google = createGoogleGenerativeAI({
            apiKey: process.env.GOOGLE_GENERATIVE_AI_API_KEY,
        });

        return google(process.env.AI_MODEL!)
    }
    if (provider === 'LM_STUDIO') {
        const lmstudio = createOpenAICompatible({
            name: 'lmstudio',
            baseURL: process.env.AI_PROVIDER_BASE_URL!,
        });

        return lmstudio(process.env.AI_MODEL!)
    }

    throw new Error(`Unsupported AI_PROVIDER: ${process.env.AI_PROVIDER}`);
}

const systemPrompt = `คุณคือผู้ช่วย AI อัจฉริยะ (AI Agent) สำหรับระบบ ZZBY Lab Monitor
หน้าที่ของคุณคือช่วยตอบคำถามเกี่ยวกับข้อมูลในระบบ และวิเคราะห์สถานะของเซิร์ฟเวอร์
- ใช้เครื่องมือ (Tools) ที่มีให้เพื่อดึงข้อมูลจริงจากระบบ
- ตอบเป็นภาษาไทยที่สุภาพและเข้าใจง่าย
- หากข้อมูลมีจำนวนมาก ให้สรุปประเด็นสำคัญ
- หากคุณไม่มั่นใจ ให้บอกว่าขอไปตรวจสอบข้อมูลก่อน หรือแจ้งว่าไม่มีเครื่องมือสำหรับข้อมูลนั้น`;

interface AIServiceDeps {
    deviceRepository: IDeviceRepository;
    createDeviceUseCase: ReturnType<typeof CreateDevice>;
    updateDeviceUseCase: ReturnType<typeof UpdateDevice>;
    getAllDevicesUseCase: ReturnType<typeof GetAllDevices>;
}

class AIServiceClass {
    private model = loadModels();
    private systemPrompt = systemPrompt;



    constructor(private readonly deps: AIServiceDeps) { }

    async streamChat(messages: any[], context: UsecaseContext) {

        const result = await streamText({
            model: this.model,
            system: this.systemPrompt,
            messages: await convertToModelMessages(messages),
            stopWhen: stepCountIs(10),
            tools: {
                ...createSystemTools({}, context),
                ...createCoreTools({}, context),
                ...createDeviceTools({
                    deviceRepository: this.deps.deviceRepository,
                    createDeviceUseCase: this.deps.createDeviceUseCase,
                    updateDeviceUseCase: this.deps.updateDeviceUseCase,
                    getAllDevicesUseCase: this.deps.getAllDevicesUseCase,
                }, context),
            },
            onStepFinish: ({ text, toolCalls, toolResults }) => {
                console.log('Agent step logic:', text, toolCalls, toolResults);
            }
        });

        return result;
    }
}
export const AIService = (deps: AIServiceDeps) => new AIServiceClass(deps);
