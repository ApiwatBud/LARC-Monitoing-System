import { z } from "zod";
import { IDeviceRepository } from "../../../labmonitor/domains/repositories/device.repository";
import { CreateDevice } from "../../../labmonitor/applications/usecases/devices/createDevice";
import { UpdateDevice } from "../../../labmonitor/applications/usecases/devices/updateDevice";
import { GetAllDevices } from "../../../labmonitor/applications/usecases/devices/getAllDevices";
import { UsecaseContext } from "../../../../src/common/utils/guard";
import { createTool } from "./tool.helper";
import { logger } from "../../../../src/common/utils/logger";
import { DeviceAggsCreateDTO, DeviceAggsUpdateDTO } from "../../../labmonitor/applications/dtos/device.dto.aggs";




export interface IDeviceTools {
    deviceRepository: IDeviceRepository;
    createDeviceUseCase: ReturnType<typeof CreateDevice>;
    updateDeviceUseCase: ReturnType<typeof UpdateDevice>;
    getAllDevicesUseCase: ReturnType<typeof GetAllDevices>;
}

export const createDeviceTools = (deps: IDeviceTools, context: UsecaseContext) => {
    const deviceRepository = deps.deviceRepository;

    return {
        list_devices: createTool({
            description: "ดึงรายชื่ออุปกรณ์ (Device) ทั้งหมดในระบบ เพื่อตรวจสอบสถานะ",
            parameters: z.object({}),
            execute: async () => {
                const devices = await deps.getAllDevicesUseCase({ context });
                return devices;
            },
        }),
        create_device: createTool({
            description: "สร้างอุปกรณ์ใหม่ในระบบ (Create Device)",
            parameters: z.object({
                dto: DeviceAggsCreateDTO
            }),
            execute: async (props) => {
                logger.info({
                    msg: "AI creating device",
                    userId: context.user?.id,
                    device: props.dto.name
                })
                const device = await deps.createDeviceUseCase({
                    dto: props.dto,
                    context: context
                })
                logger.info({
                    msg: "AI created device success",
                    userId: context.user?.id,
                    deviceId: device.id
                })
                return device;
            }
        }),
        update_device: createTool({
            description: "อัปเดตข้อมูลอุปกรณ์ในระบบ (Update Device)",
            parameters: z.object({
                id: z.number().describe("รหัสอุปกรณ์ (Device ID)"),
                dto: DeviceAggsUpdateDTO
            }),
            execute: async (props) => {
                logger.info({
                    msg: "AI updating device",
                    userId: context.user?.id,
                    deviceId: props.id
                })
                const device = await deps.updateDeviceUseCase({
                    id: props.id,
                    dto: props.dto,
                    context: context
                })
                logger.info({
                    msg: "AI updated device success",
                    userId: context.user?.id,
                    deviceId: device.id
                })
                return device;
            }
        }),
    };
};
