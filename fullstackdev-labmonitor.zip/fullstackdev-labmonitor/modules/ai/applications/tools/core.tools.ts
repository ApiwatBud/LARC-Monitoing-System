import { z } from "zod";
import { createTool } from "./tool.helper";
import { UserPgRepository } from "../../../../src/modules/core/persistents/pg/repositories/user.pg.repository";
import { UsecaseContext } from "../../../../src/common/utils/guard";
import pgClient from "../../../../src/common/persistents/pgClient";

export const createCoreTools = (deps: {}, context: UsecaseContext) => {
    const userRepository = new UserPgRepository(pgClient);

    return {
        list_users: createTool({
            description: "ดึงรายชื่อผู้ใช้งานทั้งหมดในระบบ",
            parameters: z.object({}),
            execute: async () => {
                const users = await userRepository.findAll();
                return users.map((u: any) => ({
                    id: u.id,
                    username: u.username,
                    email: u.email,
                    created_at: u.createdAt
                }));
            },
        }),
    };
};
