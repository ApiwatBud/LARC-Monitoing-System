import { z } from "zod";
import { createTool } from "./tool.helper";
import { UsecaseContext } from "../../../../src/common/utils/guard";
import { GetSystemStatus } from "../../../../src/modules/core/applications/usecases/system/getSystemStatus";

export const createSystemTools = (deps: {}, context: UsecaseContext) => {
    return {
        get_system_status: createTool({
            description: "ดึงข้อมูลสถานะของระบบ เช่น ข้อมูล CPU, Memory, OS และ Uptime ของเซิร์ฟเวอร์",
            parameters: z.object({}),
            execute: async () => {
                const run = GetSystemStatus({});
                return await run({});
            },
        }),
    };
};
