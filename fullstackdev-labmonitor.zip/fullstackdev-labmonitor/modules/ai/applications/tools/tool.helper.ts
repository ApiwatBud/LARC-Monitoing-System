import { tool as aiTool } from "ai";
import { z } from "zod";

export interface AgentTool<T extends z.ZodType<any, any>> {
    description: string;
    parameters: T;
    execute: (args: z.infer<T>) => Promise<any>;
}

export const createTool = <T extends z.ZodType<any, any>>(tool: AgentTool<T>) => {
    return aiTool({
        description: tool.description,
        inputSchema: tool.parameters, // Use inputSchema instead of parameters
        execute: tool.execute,
    } as any); // Use any as a fallback for complex union types if still failing
};
