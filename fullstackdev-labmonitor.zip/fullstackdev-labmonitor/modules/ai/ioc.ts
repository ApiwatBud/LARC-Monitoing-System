import Elysia from "elysia";
import { AIService } from "./applications/services/ai.service";
import { ConfigIoC } from "../../src/modules/config/ioc";
import { LabMonitorIoC } from "../labmonitor/ioc";
import { DeviceUseCase } from "../labmonitor/applications/http/device.usecase.http";


export const AIIoC = new Elysia({ name: "AIIoC" })
    .use(ConfigIoC)
    .use(LabMonitorIoC)
    .decorate("aiService", AIService({
        deviceRepository: LabMonitorIoC.decorator.deviceRepository,
        createDeviceUseCase: DeviceUseCase.decorator.createDevice,
        updateDeviceUseCase: DeviceUseCase.decorator.updateDevice,
        getAllDevicesUseCase: DeviceUseCase.decorator.getAllDevices,
    }));
