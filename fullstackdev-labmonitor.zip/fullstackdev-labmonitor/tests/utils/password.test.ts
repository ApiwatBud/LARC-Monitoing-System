import { describe, expect, it } from "bun:test";
import { hashPassword, verifyPassword } from "../../src/common/utils/password";

describe("Password", () => {
    it("should hash and verify password", async () => {
        const password = "password"
        const hash = await hashPassword(password)
        const verified = await verifyPassword(password, hash)
        expect(verified).toBe(true)
    })

    it("should not verify wrong password", async () => {
        const password = "password"
        const hash = await hashPassword(password)
        const verified = await verifyPassword("wrongpassword", hash)
        expect(verified).toBe(false)
    })

    it("should hash password with same algorithm", async () => {
        const password = "password"
        const hash = await hashPassword(password)
        expect(hash).toContain("$argon2id$")
    })
})  