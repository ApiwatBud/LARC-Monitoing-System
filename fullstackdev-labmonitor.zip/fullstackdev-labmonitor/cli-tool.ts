//this file scan all the cli tool in the src/modules/*/applications/cli 
//generate menu for user to select
//run the selected cli tool

import * as p from '@clack/prompts';
import fs from 'fs';
import path from 'path';

async function main() {
    const cliTools = fs.readdirSync(path.join(__dirname, 'src', 'modules'))
        .filter(module => fs.existsSync(path.join(__dirname, 'src', 'modules', module, 'applications', 'cli')))
        .map(module => {
            const cliTools = fs.readdirSync(path.join(__dirname, 'src', 'modules', module, 'applications', 'cli'))
                .filter(cliTool => cliTool.endsWith('.ts'))
                .map(cliTool => {
                    return {
                        module,
                        cliTool: cliTool.replace('.ts', '')
                    }
                })
            return {
                module,
                cliTools
            }
        })


    const selectedModule = await p.select({
        message: 'Select a module',
        options: cliTools.filter(cliTool => cliTool.cliTools.length > 0).map(cliTool => {
            return {
                value: cliTool.module,
                label: cliTool.module
            }
        })
    })

    if (p.isCancel(selectedModule)) {
        p.cancel('Operation cancelled');
        process.exit(0);
    }

    const selectedCliTool = await p.select({
        message: 'Select a cli tool',
        options: cliTools.find(cliTool => cliTool.module === selectedModule)?.cliTools.map(cliTool => {
            return {
                value: cliTool.cliTool,
                label: cliTool.cliTool
            }
        }) ?? []
    })

    if (p.isCancel(selectedCliTool)) {
        p.cancel('Operation cancelled');
        process.exit(0);
    }

    const cliTool = await import(path.join(__dirname, 'src', 'modules', selectedModule as string, 'applications', 'cli', `${selectedCliTool}.ts`))
    await cliTool.main()
    process.exit(0);
}

main().catch(error => {
    console.error(error);
    process.exit(1);
})