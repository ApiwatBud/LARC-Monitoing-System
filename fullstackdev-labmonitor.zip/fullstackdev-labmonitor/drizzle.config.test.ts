import { defineConfig } from 'drizzle-kit';
import * as dotenv from 'dotenv';

// Load .env.test file
dotenv.config({ path: '.env.test' });

export default defineConfig({
    out: './drizzle/pg',
    schema: './src/**/*.pg.schema.ts',
    dialect: 'postgresql',
    dbCredentials: {
        url: process.env.DATABASE_URL!,
    },
});
