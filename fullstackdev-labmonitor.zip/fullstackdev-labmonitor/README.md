# Objectives

Typesafe and Compile time checked ERP system

## Tech Stack

- Bun
- Elysia
- PostgreSQL
- TypeScript

## Architecture

- Domain Driven Design
- Clean Architecture
- Repository Pattern
- Unit of Work Pattern
- Dependency Injection
- Controller Pattern
- Service Pattern

## Features

- 
